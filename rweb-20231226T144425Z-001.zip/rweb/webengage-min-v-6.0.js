var webengage = window.webengage || {};
!(function (Z, K, X, $) {
  var a, r;
  (a = {}),
    (r = {}),
    X.__loaded ||
      ((X.__loaded = !0),
      (X.require = function (t) {
        if (!a[t]) {
          if (!r[t]) throw new Error('Cannot find module "' + t + '"');
          var e = (a[t] = { exports: {} });
          r[t][0].call(
            e.exports,
            function (e) {
              return X.require(r[t][1][e] || e);
            },
            e,
            e.exports
          );
        }
        return a[t].exports;
      }),
      (X.modules = function (e, t, n) {
        for (var i in e)
          e.hasOwnProperty(i) && !r.hasOwnProperty(i) && (r[i] = e[i]);
        for (var o = 0; o < n.length; o++)
          a.hasOwnProperty(n[o]) || X.require(n[o]);
      })),
    X.modules(
      {
        "webengage/animate": [
          function (e, t, n) {
            "use strict";
            var o = e("webengage/morpheus"),
              i =
                (e("webengage/easings"),
                {
                  fadeIn: function (e, t) {
                    o(e, {
                      "-ms-filter":
                        "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)",
                      filter: "alpha(opacity=100)",
                      "-moz-opacity": 1,
                      "-khtml-opacity": 1,
                      opacity: 1,
                      duration: _weq[
                        "webengage.webPersonalization.animate.duration"
                      ]
                        ? _weq["webengage.webPersonalization.animate.duration"]
                        : 1e3,
                      complete: t,
                    });
                  },
                  fadeOut: function (e, t) {
                    o(e, {
                      "-ms-filter":
                        "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)",
                      filter: "alpha(opacity=0)",
                      "-moz-opacity": 0,
                      "-khtml-opacity": 0,
                      opacity: 0,
                      duration: _weq[
                        "webengage.webPersonalization.animate.duration"
                      ]
                        ? _weq["webengage.webPersonalization.animate.duration"]
                        : 1e3,
                      complete: t,
                    });
                  },
                  slideInTop: function (e, t, n) {
                    o(e, { top: (t = t || "0"), duration: 400, complete: n });
                  },
                  slideOutTop: function (e, t, n) {
                    o(e, { top: (t = t || "-35"), duration: 400, complete: n });
                  },
                  slideInBottom: function (e, t, n) {
                    o(e, {
                      bottom: (t = t || "0"),
                      duration: 400,
                      complete: n,
                    });
                  },
                  slideOutBottom: function (e, t, n) {
                    o(e, {
                      bottom: (t = t || "-100%"),
                      duration: 400,
                      complete: n,
                    });
                  },
                  slideInTopHeight: function (e, t, n, i) {
                    o(e, {
                      height: t || "35px",
                      duration: n || 400,
                      complete: i,
                    });
                  },
                  slideOutTopHeight: function (e, t, n, i) {
                    o(e, {
                      height: t || "0px",
                      duration: n || 400,
                      complete: i,
                    });
                  },
                  slideInRight: function (e, t, n, i) {
                    o(e, {
                      left: (t = t || "0px"),
                      duration: (n = n || 600),
                      complete: i,
                    });
                  },
                  slideOutRight: function (e, t, n, i) {
                    o(e, {
                      left: (t = t || "100px"),
                      duration: (n = n || 600),
                      complete: i,
                    });
                  },
                });
            t.exports = i;
          },
          {},
        ],
        "webengage/app-store": [
          function (e, t, n) {
            "use strict";
            var i = {
              getConfig: function (e) {
                if (
                  !(
                    e &&
                    "undefined" == typeof webengage_fs_configurationMap &&
                    webengage_fs_configurationMap.apps instanceof Array
                  )
                )
                  return null;
                for (
                  var t = 0, n = webengage_fs_configurationMap.apps;
                  t < n.length;
                  t++
                )
                  if (n[t].appId === e) return n[t].widgetConfig || null;
                return null;
              },
            };
            t.exports = i;
          },
          {},
        ],
        "webengage/async": [
          function (e, t, n) {
            "use strict";
            function l(e, t) {
              "[object Function]" === Object.prototype.toString.call(e) &&
                e.apply(null, t);
            }
            function i(e, t, i) {
              var o = [],
                a = e && e.length;
              function n(n) {
                return function (e, t) {
                  if (a && !o.hasOwnProperty(n)) {
                    if (e) return (a = 0), l(i, [e]);
                    (o[n] = t), (a -= 1) || l(i, [null, o]);
                  }
                };
              }
              if (!a) return l(i, [null, o]);
              for (var r = 0; r < e.length; r++) t(e[r], n(r));
            }
            function o(o, a, r) {
              var s = [],
                c = o && o.length;
              c
                ? l(a, [
                    o[0],
                    (function n(i) {
                      return function (e, t) {
                        if (c && !s.hasOwnProperty(i)) {
                          if (e) return l(r, [e]);
                          (s[i] = t),
                            (c -= 1)
                              ? l(a, [o[i + 1], n(i + 1), t])
                              : l(r, [null, s]);
                        }
                      };
                    })(0),
                  ])
                : l(r, [null, s]);
            }
            t.exports = {
              mapParallel: i,
              mapSeries: o,
              parallel: function (e, t) {
                i(
                  e,
                  function (e, t) {
                    e(t);
                  },
                  t
                );
              },
              series: function (e, t) {
                o(
                  e,
                  function (e, t, n) {
                    e(t, n);
                  },
                  t
                );
              },
            };
          },
          {},
        ],
        "webengage/backpatch": [
          function (a, e, t) {
            "use strict";
            var g =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  };
            e.exports = function () {
              var r = a("webengage/util"),
                t = a("webengage/state"),
                e = a("webengage/rules"),
                s = a("webengage/load"),
                c = a("webengage/dom"),
                n = a("webengage/weq"),
                i = a("webengage/ua"),
                o = a("webengage/dependency"),
                l = a("webengage/events");
              (Z._weq = n._weq),
                (X.getLicenseCode = function () {
                  return n.get("webengage.licenseCode");
                }),
                (X.getWidgetVersion = function () {
                  return n.get("webengage.widgetVersion");
                }),
                (X.eLog = function (e, t, n, i, o, a) {
                  X.log.error({
                    msg: String(e),
                    ctx: {
                      error: e,
                      type: t,
                      data: n,
                      event: i,
                      et: o,
                      eid: a,
                    },
                  }),
                    l.publish("error", e, t, n, i, o, a);
                }),
                (r.getSessionCookie = function () {
                  return t.getSession();
                }),
                (r.getWebengageCookie = function () {
                  return t.getForever();
                }),
                (r.setSessionCookie = function (e) {
                  return t.setSession(e);
                }),
                (r.setWebengageCookie = function (e) {
                  return t.setForever(e);
                }),
                (r.getCookie = function (e) {
                  return c.cookie.getCookie(e);
                }),
                (r.setCookie = function (e, t, n, i, o, a) {
                  return c.cookie.setCookie(e, t, n, i, o, a);
                }),
                (r.isSmallScreen = function () {
                  return Z.screen.availWidth <= 480;
                }),
                (r.onReady = function (e) {
                  X.onReady(e);
                }),
                (r.onSessionStarted = function (e) {
                  X.onSessionStarted(e);
                }),
                (r.loadScript = function (e, t, n, i) {
                  var o,
                    a =
                      ((o = this),
                      (
                        "object" ===
                        ("undefined" == typeof HTMLElement
                          ? "undefined"
                          : g(HTMLElement))
                          ? o instanceof HTMLElement
                          : o &&
                            "object" === (void 0 === o ? "undefined" : g(o)) &&
                            null !== o &&
                            1 === o.nodeType &&
                            "string" == typeof o.nodeName
                      )
                        ? this
                        : null);
                  s.script(
                    e,
                    a
                  )(function (e) {
                    if (e) return "function" === r.type(i) && i(e);
                    "function" === r.type(t) && r.guard(t).apply(null, n || []);
                  });
                }),
                (r.withWeJquery = function (e) {
                  o.load("jquery", null, e);
                }),
                (X.GEO = {
                  load: function (e) {
                    o.load("geo", null, e);
                  },
                }),
                (X.BrowserDetect = {
                  browser: function () {
                    return i.browser;
                  },
                  version: function () {
                    return i.version;
                  },
                  os: function () {
                    return i.os;
                  },
                  device: function () {
                    return i.device;
                  },
                  ie: function () {
                    return "Explorer" === i.browser;
                  },
                  isMobile: function () {
                    return (
                      -1 !==
                      r.indexOfArray(
                        ["iOS", "Android", "Windows Phone", "Mobile"],
                        i.os
                      )
                    );
                  },
                }),
                (X.ruleExecutor = e),
                o.register("jquery", function (e, t) {
                  s.script(
                    ("http:" == location.protocol ? "http:" : "https:") +
                      "//ssl.widgets.webengage.com/js/jquery/jquery-1.3.2.min.js"
                  )(function () {
                    (Z.$weJQuery = Z.jQuery.noConflict(!0)), t();
                  });
                });
            };
          },
          {},
        ],
        "webengage/callback-frame": [
          function (e, t, n) {
            "use strict";
            var o,
              a = e("webengage/events"),
              i = (e("webengage/util"), e("webengage/dom")),
              r = e("webengage/ua"),
              s = "webengage-engagement-callback-frame",
              c = {},
              l = {
                init: function (e, n) {
                  (s = e || s),
                    i.iframe.create({
                      name: s,
                      onload: function (e) {
                        var t = i.iframe.getDoc(e);
                        "Chrome" !== r.browser &&
                          (t.write("<!DOCTYPE html><html></html>"), t.close()),
                          (o = e),
                          n();
                      },
                    });
                },
                onMessage: function (t, e, n) {
                  function i(e) {
                    ("*" === t ||
                      e.origin.toLowerCase() === t ||
                      (0 === t.indexOf("//") &&
                        e.origin.toLowerCase() === Z.location.protocol + t)) &&
                      n(e.data);
                  }
                  (t = t.toLowerCase()),
                    o &&
                      (e &&
                        (c[e] && a.unbind(o.contentWindow, "message", c[e]),
                        (c[e] = i)),
                      a.bind(o.contentWindow, "message", i, !1));
                },
                get: function () {
                  return o;
                },
                getName: function () {
                  return s;
                },
              };
            t.exports = l;
          },
          {},
        ],
        "webengage/colors": [
          function (e, t, n) {
            "use strict";
            var i = {
              addHash: function (e) {
                for (var t in e)
                  e.hasOwnProperty(t) &&
                    e[t] &&
                    t.match(/^.*Color$/) &&
                    (e[t] =
                      e[t].toString().search("#") < 0 ? "#" + e[t] : e[t]);
                return e;
              },
              isColorTooLight: function (e) {
                return e
                  ? ((e = 0 === e.indexOf("#") ? e.substr(1, e.length) : e),
                    128 <=
                      (299 * parseInt(e.substr(0, 2), 16) +
                        299 * parseInt(e.substr(2, 2), 16) +
                        299 * parseInt(e.substr(4, 2), 16)) /
                        1e3)
                  : e;
              },
              padColor: function (e, t) {
                for (e += ""; e.length < t; ) e = "0" + e;
                return e;
              },
              changeColor: function (e, t, n) {
                e = (e = e.replace(/^\s*|\s*$/, "")).replace(
                  /^#?([a-f0-9])([a-f0-9])([a-f0-9])$/i,
                  "#$1$1$2$2$3$3"
                );
                var i = Math.round(256 * t) * (n ? -1 : 1),
                  o = e.match(
                    new RegExp(
                      "^rgba?\\(\\s*(\\d|[1-9]\\d|1\\d{2}|2[0-4][0-9]|25[0-5])\\s*,\\s*(\\d|[1-9]\\d|1\\d{2}|2[0-4][0-9]|25[0-5])\\s*,\\s*(\\d|[1-9]\\d|1\\d{2}|2[0-4][0-9]|25[0-5])(?:\\s*,\\s*(0|1|0?\\.\\d+))?\\s*\\)$",
                      "i"
                    )
                  ),
                  a = o && null != o[4] ? o[4] : null,
                  r = o
                    ? [o[1], o[2], o[3]]
                    : e
                        .replace(
                          /^#?([a-f0-9][a-f0-9])([a-f0-9][a-f0-9])([a-f0-9][a-f0-9])/i,
                          function () {
                            return (
                              parseInt(arguments[1], 16) +
                              "," +
                              parseInt(arguments[2], 16) +
                              "," +
                              parseInt(arguments[3], 16)
                            );
                          }
                        )
                        .split(/,/);
                return o
                  ? "rgb" +
                      (null !== a ? "a" : "") +
                      "(" +
                      Math[n ? "max" : "min"](
                        parseInt(r[0], 10) + i,
                        n ? 0 : 255
                      ) +
                      ", " +
                      Math[n ? "max" : "min"](
                        parseInt(r[1], 10) + i,
                        n ? 0 : 255
                      ) +
                      ", " +
                      Math[n ? "max" : "min"](
                        parseInt(r[2], 10) + i,
                        n ? 0 : 255
                      ) +
                      (null !== a ? ", " + a : "") +
                      ")"
                  : [
                      "#",
                      this.padColor(
                        Math[n ? "max" : "min"](
                          parseInt(r[0], 10) + i,
                          n ? 0 : 255
                        ).toString(16),
                        2
                      ),
                      this.padColor(
                        Math[n ? "max" : "min"](
                          parseInt(r[1], 10) + i,
                          n ? 0 : 255
                        ).toString(16),
                        2
                      ),
                      this.padColor(
                        Math[n ? "max" : "min"](
                          parseInt(r[2], 10) + i,
                          n ? 0 : 255
                        ).toString(16),
                        2
                      ),
                    ].join("");
              },
              lighterColor: function (e, t) {
                return this.changeColor(e, t, !1);
              },
              darkerColor: function (e, t) {
                return this.changeColor(e, t, !0);
              },
            };
            t.exports = i;
          },
          {},
        ],
        "webengage/comm": [
          function (e, t, n) {
            "use strict";
            var d = e("webengage/ua"),
              u = e("webengage/dom"),
              a = e("webengage/util"),
              r = e("webengage/load"),
              p = e("webengage/weq"),
              f = e("webengage/fetch-helper"),
              i = {
                xhr: function (t, n, i) {
                  try {
                    if (d.ie && d.version < 10)
                      throw new Error(
                        "IE before version 10 did not support XMLHttpRequest with CORS"
                      );
                    var e = Z.XMLHttpRequest;
                    if (void 0 === e)
                      throw new Error(
                        "This browser does not support XMLHttpRequest"
                      );
                    var o = new e();
                    if (!("withCredentials" in o))
                      throw new Error(
                        "This browser does not support XMLHttpRequest with CORS"
                      );
                    var a = n ? "POST" : "GET";
                    if (
                      (o.open(a, t, !0),
                      (o.onreadystatechange = function () {
                        4 == o.readyState &&
                          200 <= o.status &&
                          o.status < 300 &&
                          "function" == typeof i &&
                          i(o.responseText);
                      }),
                      o.setRequestHeader(
                        "Content-Type",
                        "application/x-www-form-urlencoded"
                      ),
                      p.get("webengage.httpFetch"))
                    )
                      f.initHeaders().headers.forEach(function (e, t) {
                        o.setRequestHeader(t, e);
                      });
                    var r = [];
                    for (var s in n)
                      n.hasOwnProperty(s) &&
                        r.push(
                          encodeURIComponent(s) + "=" + encodeURIComponent(n[s])
                        );
                    o.send(r.join("&"));
                  } catch (e) {
                    try {
                      var c = K.createElement("form"),
                        l = u.iframe.create({
                          name: "WE_XHR_POST_IFRM_" + new Date().getTime(),
                          onload: function (e) {
                            u.iframe.remove(e),
                              c &&
                                c.parentElement &&
                                c.parentElement.removeChild(c),
                              "function" == typeof i && i();
                          },
                        });
                      for (var s in ((c.target = l.name),
                      (c.action = t),
                      (c.method = "POST"),
                      n)) {
                        var g = K.createElement("input");
                        (g.type = "hidden"),
                          (g.name = s),
                          (g.value = n[s]),
                          c.appendChild(g);
                      }
                      l.parentElement.appendChild(c), c.submit();
                    } catch (e) {}
                  }
                },
                raw: function (e, t, n) {
                  if (d.ie && d.version < 10)
                    throw new Error(
                      "IE before version 10 did not support XMLHttpRequest with CORS"
                    );
                  var i = Z.XMLHttpRequest;
                  if (void 0 === i)
                    throw new Error(
                      "This browser does not support XMLHttpRequest"
                    );
                  var o = new i();
                  if (!("withCredentials" in o))
                    throw new Error(
                      "This browser does not support XMLHttpRequest with CORS"
                    );
                  (o.open("POST", e, !0),
                  (o.onreadystatechange = function () {
                    4 == o.readyState &&
                      200 == o.status &&
                      "function" == typeof n &&
                      n(o.responseText);
                  }),
                  p.get("webengage.httpFetch")) &&
                    f.initHeaders().headers.forEach(function (e, t) {
                      o.setRequestHeader(t, e);
                    });
                  o.setRequestHeader("Content-Type", "application/json"),
                    o.send(t);
                },
                jsonp: function (e, t, n) {
                  if (p.get("webengage.httpFetch")) f.jsonp(e, t, n);
                  else {
                    var i = {},
                      o = (i[(n = n || "callback")] =
                        "_we_jsonp_global_cb_" + new Date().getTime());
                    (Z[o] = function (e) {
                      t(e);
                    }),
                      (e = a.addParamsToURL(e, i)),
                      r.script(e)(function (e) {
                        try {
                          delete Z[o];
                        } catch (e) {
                          Z[o] = $;
                        }
                      });
                  }
                },
              };
            t.exports = i;
          },
          {},
        ],
        "webengage/css": [
          function (e, t, n) {
            "use strict";
            var a = e("webengage/util/bare");
            function r(e) {
              return 0 === e.indexOf("-")
                ? e
                : e.replace(/\-(\w)/g, function (e, t) {
                    return t.toUpperCase();
                  });
            }
            function o(e) {
              return Z.getComputedStyle
                ? Z.getComputedStyle(e, null)
                : e.currentStyle;
            }
            function s(e) {
              switch (e) {
                case "thin":
                  return 2;
                case "medium":
                  return 4;
                case "thick":
                  return 6;
                default:
                  return e || 0;
              }
            }
            var i = {
              applyCss: function (e, t) {
                try {
                  if (a.isArray(e))
                    for (var n = 0, i = e.length; n < i; n++)
                      for (var o in t)
                        "function" == typeof t[o]
                          ? (e[n].style[r(o)] = t[o]())
                          : (e[n].style[r(o)] = t[o]);
                  else
                    for (var o in t)
                      "function" == typeof t[o]
                        ? (e.style[r(o)] = t[o]())
                        : (e.style[r(o)] = t[o]);
                } catch (e) {}
                return e;
              },
              getHeight: function (e) {
                var t = o(e),
                  n = e.offsetHeight,
                  i = parseFloat(s(t.borderTopWidth));
                return (
                  n -
                  parseFloat(s(t.borderBottomWidth)) -
                  i -
                  parseFloat(t.paddingTop) -
                  parseFloat(t.paddingBottom)
                );
              },
              getWidth: function (e) {
                var t = o(e);
                return (
                  e.offsetWidth -
                  parseFloat(s(t.borderLeftWidth)) -
                  parseFloat(s(t.borderRightWidth)) -
                  parseFloat(t.paddingLeft) -
                  parseFloat(t.paddingRight)
                );
              },
              getMaxZIndex: function () {
                return (
                  this.maxZIndex === $ && (this.maxZIndex = 16776271),
                  this.maxZIndex++
                );
              },
              alignCenter: function (e, t, n) {
                var i = "left" == n ? "right" : "left";
                (e.style.top =
                  (parseInt(this.getElementHeight(t), 10) -
                    parseInt(this.getElementHeight(e), 10)) /
                    2 -
                  (/Firefox/i.test(navigator.userAgent) ? 7 : 0) +
                  "px"),
                  (e.style[i] =
                    (parseInt(this.getElementWidth(t), 10) -
                      parseInt(this.getElementWidth(e), 10)) /
                      2 +
                    10 +
                    "px");
              },
              getElementWidth: function (e) {
                return e.clip !== $
                  ? e.clip.width
                  : e.style.pixelWidth
                  ? e.style.pixelWidth
                  : e.offsetWidth;
              },
              getElementHeight: function (e) {
                return e.clip !== $
                  ? e.clip.height
                  : e.style.pixelHeight
                  ? e.style.pixelHeight
                  : e.offsetHeight;
              },
              getDocumentHeight: function () {
                var e = K.body,
                  t = K.documentElement;
                return Math.max(
                  e.scrollHeight,
                  e.offsetHeight,
                  t.clientHeight,
                  t.scrollHeight,
                  t.offsetHeight
                );
              },
              getDocumentWidth: function () {
                var e = K.body,
                  t = K.documentElement;
                return Math.max(
                  e.scrollWidth,
                  e.offsetWidth,
                  t.clientWidth,
                  t.scrollWidth,
                  t.offsetWidth
                );
              },
              getWindowHeight: function () {
                return "innerHeight" in Z
                  ? Z.innerHeight
                  : K.documentElement.offsetHeight;
              },
              getWindowWidth: function () {
                return "innerWidth" in Z
                  ? Z.innerWidth
                  : K.documentElement.offsetWidth;
              },
              isSmallScreen: function () {
                return Z.screen.availWidth <= 480;
              },
              isColorTooLight: function (e) {
                return (
                  (e = 0 === e.indexOf("#") ? e.substr(1, e.length) : e),
                  128 <=
                    (299 * parseInt(e.substr(0, 2), 16) +
                      299 * parseInt(e.substr(2, 2), 16) +
                      299 * parseInt(e.substr(4, 2), 16)) /
                      1e3
                );
              },
              createStyleNode: function (e, t, n) {
                var i =
                    (n = n || K.getElementsByTagName("head")[0])
                      .ownerDocument || K,
                  o = i.createElement("style");
                return (
                  (o.type = "text/css"),
                  n.appendChild(o),
                  t && t.id && (o.id = t.id),
                  o.styleSheet
                    ? (o.styleSheet.cssText = e)
                    : o.appendChild(i.createTextNode(e)),
                  o
                );
              },
              getScrollTop: function () {
                return (Z.pageYOffset || K.scrollTop) - (K.clientTop || 0) || 0;
              },
              getScrollLeft: function () {
                return (
                  (Z.pageXOffset || K.scrollLeft) - (K.clientLeft || 0) || 0
                );
              },
            };
            t.exports = i;
          },
          {},
        ],
        "webengage/dependency": [
          function (e, t, n) {
            "use strict";
            var a = e("webengage/events"),
              r = (e("webengage/util/type"), {}),
              s = {},
              i = {
                register: function (e, t) {
                  s[e] = t;
                },
                load: function (t, e, n) {
                  var i = r[t];
                  if (1 === i) a.subscribe("dependency." + t + ".load", n);
                  else if (2 === i) n(null);
                  else {
                    var o = s[t];
                    "function" == typeof o &&
                      (o(e, function (e) {
                        if (e)
                          return a.publish(
                            "error",
                            new Error("Failed to load dependency " + t)
                          );
                        (r[t] = 2), n(), a.publish("dependency." + t + ".load");
                      }),
                      (r[t] = 1));
                  }
                },
              };
            t.exports = i;
          },
          {},
        ],
        "webengage/dom": [
          function (e, t, n) {
            "use strict";
            var u = e("webengage/properties"),
              p = e("webengage/util/bare"),
              f = e("webengage/events"),
              b = e("webengage/css"),
              w = e("webengage/ua");
            function i(g) {
              var e = {
                  setCookie: function (e, t, n, i, o, a) {
                    var r = new Date();
                    n &&
                      ((n = 1e3 * n * 60 * 60 * 24),
                      (n = new Date(r.getTime() + n))),
                      (g.cookie =
                        e +
                        "=" +
                        encodeURIComponent(t) +
                        (n ? ";expires=" + n.toGMTString() : "") +
                        (i ? ";path=" + i : "") +
                        (o ? ";domain=" + o : "") +
                        (a ? ";secure" : ""));
                  },
                  getCookie: function (e) {
                    for (
                      var t = g.cookie.split(";"),
                        n = "",
                        i = "",
                        o = !1,
                        a = 0;
                      a < t.length;
                      a++
                    ) {
                      if (
                        (n = t[a].split("="))[0].replace(/^\s+|\s+$/g, "") == e
                      )
                        return (
                          (o = !0),
                          1 < n.length &&
                            (i = decodeURIComponent(
                              n[1].replace(/^\s+|\s+$/g, "")
                            )),
                          null === i ? "" : i
                        );
                      (n = null), "";
                    }
                    if (!o) return null;
                  },
                  deleteCookie: function (e, t) {
                    g.cookie =
                      e +
                      "=; path= " +
                      t +
                      ";expires=Thu, 01 Jan 1970 00:00:01 GMT;";
                  },
                },
                t = (function () {
                  var r = {},
                    a = {
                      attributes: {
                        frameBorder: "0",
                        marginHeight: "0",
                        marginWidth: "0",
                        allowTransparency: "true",
                      },
                      css: {
                        position: "absolute",
                        backgroundColor: "transparent",
                        bottom: "0px",
                        right: "0px",
                        border: "none",
                        overflow: "hidden",
                        visibility: "hidden",
                        display: "none",
                      },
                    };
                  function s(e) {
                    e = p.clone(a, e);
                    var t,
                      n = !1;
                    try {
                      t = g.createElement('<iframe name="' + e.name + '">');
                    } catch (e) {
                      t = g.createElement("iframe");
                    }
                    for (var i in ((t.id = t.name = t.title = e.name),
                    e.attributes))
                      t[i] = e.attributes[i];
                    b.applyCss(t, e.css);
                    var o = e.frameContainer || u.widgetContainer;
                    if (
                      (e.src && (t.src = e.src),
                      "function" == typeof e.onload &&
                        f.bind(t, "load", function () {
                          n || ((n = !0), e.onload(t));
                        }),
                      o.appendChild(t),
                      !e.src)
                    )
                      try {
                        t.contentWindow.name;
                      } catch (e) {
                        t.src =
                          'javascript:(function () {document.open();document.domain="' +
                          g.domain +
                          '";document.close();})();';
                      }
                    return t;
                  }
                  function c(e) {
                    var t = null;
                    return (
                      e
                        ? (t = e.contentDocument)
                        : e.contentWindow
                        ? (t = e.contentWindow.document)
                        : e.document && (t = e.document),
                      t
                    );
                  }
                  function l(e) {
                    return e + "_cb";
                  }
                  return {
                    create: function (e) {
                      var t = e.name,
                        n = e.src,
                        i = e.onMessage;
                      if (!t)
                        throw new Error("frame name should not be empty ");
                      if (r.hasOwnProperty(t)) {
                        if ("aa131c7a" !== X.getLicenseCode())
                          throw new Error(
                            "frame with name " +
                              t +
                              " exists in the dom, chose another name"
                          );
                        d.remove(t);
                      }
                      var o,
                        a = {};
                      return (
                        (a.ifrm = s(e)),
                        !(!n || !i) &&
                          (a.cIfrm =
                            ((o = t),
                            s({
                              name: e.cbfName || l(o),
                              onload: function (e) {
                                var t = c(e),
                                  n = e.contentWindow;
                                "Chrome" !== w.browser &&
                                  (t.write("<!DOCTYPE html><html></html>"),
                                  t.close()),
                                  n.attachEvent
                                    ? n.attachEvent(
                                        "onmessage",
                                        function (e) {
                                          X.dom.iframe.sendMessage(o, e.data);
                                        },
                                        !1
                                      )
                                    : n.addEventListener(
                                        "message",
                                        function (e) {
                                          X.dom.iframe.sendMessage(o, e.data);
                                        },
                                        !1
                                      );
                              },
                            }))),
                        "function" == typeof e.onMessage &&
                          (a.onMessage = e.onMessage),
                        (r[t] = a).ifrm
                      );
                    },
                    get: function (e) {
                      return r[e] && r[e].ifrm;
                    },
                    remove: function (e) {
                      var t = "string" == typeof e ? e : e.name;
                      if (r[t]) {
                        try {
                          var n = r[t].ifrm;
                          n.parentNode && n.parentNode.removeChild(n);
                          var i = r[t].cIfrm;
                          i && i.parentNode && i.parentNode.removeChild(i);
                        } catch (e) {}
                        delete r[t];
                      }
                    },
                    sendMessage: function (e, t) {
                      var n = r[e];
                      if (n && "function" == typeof n.onMessage)
                        return n.onMessage(t);
                    },
                    postMessage: function (e, t) {
                      r.hasOwnProperty(e) &&
                        r[e].ifrm.contentWindow.postMessage(t, "*");
                    },
                    getCallbackFrameName: function (e) {
                      return l(e);
                    },
                    reload: function () {
                      r = {};
                    },
                    getDoc: c,
                  };
                })(),
                d = {
                  onDocReady: function (n) {
                    function e(t) {
                      return function e() {
                        t(e);
                      };
                    }
                    if ("function" == typeof (n = p.guard(n))) {
                      if (g.body) return n();
                      g.addEventListener
                        ? g.addEventListener(
                            "DOMContentLoaded",
                            e(function (e) {
                              g.removeEventListener("DOMContentLoaded", e, !1),
                                n();
                            }),
                            !1
                          )
                        : g.attachEvent &&
                          (g.attachEvent(
                            "onreadystatechange",
                            e(function (e) {
                              "complete" === g.readyState &&
                                (g.detachEvent("onreadystatechange", e), n());
                            })
                          ),
                          g.documentElement.doScroll &&
                            Z == Z.top &&
                            e(function (t) {
                              try {
                                g.documentElement.doScroll("left");
                              } catch (e) {
                                return void setTimeout(t, 0);
                              }
                              n();
                            })());
                    }
                  },
                  getDoc: function () {
                    return g;
                  },
                  isElementExists: function (e) {
                    var t = e;
                    return (
                      t &&
                        e.nodeType &&
                        1 === e.nodeType &&
                        (t = !(
                          e.style &&
                          ((e.style.display && "none" === e.style.display) ||
                            (e.style.visibility &&
                              "hidden" === e.style.visibility))
                        )),
                      t
                    );
                  },
                  hasSVG: function () {
                    return (
                      !!g.createElementNS &&
                      !!g.createElementNS("http://www.w3.org/2000/svg", "svg")
                        .createSVGRect
                    );
                  },
                  createElement: function (e, t, n) {
                    var i = (n = n || g).createElement(e);
                    return t && (i.innerHTML = t), i;
                  },
                  query: function (e, t) {
                    return i.query(e, t || g);
                  },
                  queryOne: function (e, t) {
                    return i.queryOne(e, t || g);
                  },
                  addClass: function (e, t) {
                    if (e && t) {
                      var n = (e.className || "").split(" ");
                      -1 === p.indexOfArray(n, t) &&
                        (n.push(t), (e.className = n.join(" ")));
                    }
                  },
                  removeClass: function (e, t) {
                    if (e && t) {
                      var n = e.className,
                        i = new RegExp("(^|\\s)" + t + "(?=\\s|$)", "i"),
                        o = n.replace(i, "");
                      e.className = p.trim(o);
                    }
                  },
                  traverse: function (e, t, n) {
                    for (
                      var i = [], o = n !== $;
                      (e = e[t]) && 9 !== e.nodeType;

                    )
                      if (1 === e.nodeType) {
                        if (o && e === n) break;
                        i.push(e);
                      }
                    return i;
                  },
                  parents: function (e, t) {
                    return d.traverse(e, "parentNode", t);
                  },
                  within: function (e, t) {
                    var n = d.parents(t, e.parentNode);
                    return -1 < p.indexOf(n, e);
                  },
                  contains: function (e, t) {
                    if (null == e) return !1;
                    if (e === t) return !0;
                    var n = d.parents(t, e.parentNode);
                    return -1 < p.indexOfArray(n, e);
                  },
                  remove: function (e) {
                    e && e.parentElement && e.parentElement.removeChild(e);
                  },
                  getQuerySelector: function (e) {
                    if (e instanceof Element)
                      for (
                        var r,
                          s = [
                            "name",
                            "value",
                            "title",
                            "placeholder",
                            "data-*",
                          ],
                          c = [],
                          t = function (e) {
                            if (e.id) return c.unshift("#" + e.id), !0;
                            if (
                              (c.unshift((r = e.nodeName.toLowerCase())),
                              e.className &&
                                ((c[0] = r +=
                                  "." + e.className.trim().replace(/ +/g, ".")),
                                l()))
                            )
                              return !0;
                            for (var t = 0; t < s.length; ++t)
                              if ("data-*" === s[t]) {
                                for (
                                  var n = [].filter.call(
                                      e.attributes,
                                      function (e) {
                                        return 0 === e.name.indexOf("data-");
                                      }
                                    ),
                                    i = 0;
                                  i < n.length;
                                  ++i
                                )
                                  if (
                                    ((c[0] = r +=
                                      "[" +
                                      n[i].name +
                                      '="' +
                                      n[i].value +
                                      '"]'),
                                    l())
                                  )
                                    return !0;
                              } else if (
                                e[s[t]] &&
                                ((c[0] = r +=
                                  "[" + s[t] + '="' + e[s[t]] + '"]'),
                                l())
                              )
                                return !0;
                            for (
                              var o = e, a = 1;
                              (o = o.previousElementSibling);

                            )
                              o.nodeName === e.nodeName && ++a;
                            if (((c[0] = r += ":nth-of-type(" + a + ")"), l()))
                              return !0;
                            for (o = e, a = 1; (o = o.previousElementSibling); )
                              ++a;
                            return (
                              (c[0] = r =
                                r.replace(
                                  /:nth-of-type\(\d+\)/,
                                  1 < a
                                    ? ":nth-child(" + a + ")"
                                    : ":first-child"
                                )),
                              !!l()
                            );
                          },
                          l = function () {
                            return (
                              1 ===
                              g.querySelectorAll(c.join(">") || null).length
                            );
                          };
                        e.parentNode;

                      ) {
                        if (t(e)) return c.join(" > ");
                        e = e.parentNode;
                      }
                  },
                  elementsShareFamily: function (e, t) {
                    return e.tagName === t.tagName && (!e.id || e.id === t.id);
                  },
                  getElementIndex: function (e) {
                    var t,
                      n = 1;
                    for (t = e.previousSibling; t; t = t.previousSibling)
                      1 === t.nodeType && d.elementsShareFamily(e, t) && n++;
                    if (1 < n) return n;
                    for (t = e.nextSibling; t; t = t.nextSibling)
                      if (1 === t.nodeType && d.elementsShareFamily(e, t))
                        return 1;
                    return 0;
                  },
                  getElementPath: function (e) {
                    for (
                      var t, n, i, o = "", a = "";
                      e && 1 === e.nodeType;
                      e = e.parentNode
                    ) {
                      if (((t = e.id), (n = e.tagName.toLowerCase()), t)) {
                        (o = "//*[@id='" + t + "']" + o),
                          (a = n.toUpperCase() + "[id='" + t + "']" + a);
                        break;
                      }
                      1 <= (i = d.getElementIndex(e)) && (n += "[" + i + "]"),
                        (o = "/" + n + o),
                        (a = n.toUpperCase() + (a ? " > " + a : ""));
                    }
                    return { xpath: o, display: (a = "SELECTION â†’ " + a) };
                  },
                  getElementPathCp: function (e) {
                    for (
                      var t, n, i, o = "", a = "";
                      e && 1 === e.nodeType;
                      e = e.parentNode
                    ) {
                      if (((t = e.id), (n = e.tagName.toLowerCase()), t)) {
                        (o = "//*[@id='" + t + "']" + o),
                          (a = n.toUpperCase() + "[id='" + t + "']" + a);
                        break;
                      }
                      1 <= (i = d.getElementIndex(e)) && (n += "[" + i + "]"),
                        (o = "/" + n + o),
                        (a = n.toUpperCase() + (a ? " > " + a : ""));
                    }
                    return (a = "SELECTION â†’ " + a);
                  },
                  getElementDetails: function (e) {
                    var t = location.href,
                      n = new RegExp("[\\?&]libraryScript=([^&#]*)"),
                      i = n.exec(location.search);
                    i && 0 < i.length && (t = t.replace(i[0], "")),
                      (i = (n = new RegExp("[\\?&]frameUrl=([^&#]*)")).exec(
                        location.search
                      )) &&
                        0 < i.length &&
                        (t = t.replace(i[0], ""));
                    for (
                      var o, a = {}, r = 0, s = e.attributes, c = s.length;
                      r < c;
                      r++
                    )
                      "" != (o = s.item(r)).nodeValue &&
                        -1 == p.inArray(o.nodeValue, a) &&
                        (a[o.nodeName] = o.nodeValue);
                    return {
                      textContent: e.textContent,
                      tagName: e.tagName,
                      url: t,
                      isNodeType: 1 === e.nodeType,
                      attributes: a,
                      xPath: d.getElementPath(e).xpath,
                    };
                  },
                  css: b,
                  iframe: t,
                  cookie: e,
                  doc: i,
                };
              return d;
            }
            (i.query = function (e, t) {
              return t.querySelectorAll(e);
            }),
              (i.queryOne = function (e, t) {
                return t.querySelector(e);
              }),
              (t.exports = i(K));
          },
          {},
        ],
        "webengage/easings": [
          function (e, t, n) {
            "use strict";
            var i = {
              easeOut: function (e) {
                return Math.sin((e * Math.PI) / 2);
              },
              easeOutStrong: function (e) {
                return 1 == e ? 1 : 1 - Math.pow(2, -10 * e);
              },
              easeIn: function (e) {
                return e * e;
              },
              easeInStrong: function (e) {
                return 0 == e ? 0 : Math.pow(2, 10 * (e - 1));
              },
              easeOutBounce: function (e) {
                return e < 1 / 2.75
                  ? 7.5625 * e * e
                  : e < 2 / 2.75
                  ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75
                  : e < 2.5 / 2.75
                  ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375
                  : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
              },
              easeInBack: function (e) {
                return e * e * (2.70158 * e - 1.70158);
              },
              easeOutBack: function (e) {
                return (e -= 1) * e * (2.70158 * e + 1.70158) + 1;
              },
              bounce: function (e) {
                return e < 1 / 2.75
                  ? 7.5625 * e * e
                  : e < 2 / 2.75
                  ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75
                  : e < 2.5 / 2.75
                  ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375
                  : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375;
              },
              bouncePast: function (e) {
                return e < 1 / 2.75
                  ? 7.5625 * e * e
                  : e < 2 / 2.75
                  ? 2 - (7.5625 * (e -= 1.5 / 2.75) * e + 0.75)
                  : e < 2.5 / 2.75
                  ? 2 - (7.5625 * (e -= 2.25 / 2.75) * e + 0.9375)
                  : 2 - (7.5625 * (e -= 2.625 / 2.75) * e + 0.984375);
              },
              swingTo: function (e) {
                return (e -= 1) * e * (2.70158 * e + 1.70158) + 1;
              },
              swingFrom: function (e) {
                return e * e * (2.70158 * e - 1.70158);
              },
              elastic: function (e) {
                return (
                  -1 *
                    Math.pow(4, -8 * e) *
                    Math.sin(((6 * e - 1) * (2 * Math.PI)) / 2) +
                  1
                );
              },
              spring: function (e) {
                return 1 - Math.cos(4.5 * e * Math.PI) * Math.exp(6 * -e);
              },
              blink: function (e, t) {
                return Math.round(e * (t || 5)) % 2;
              },
              pulse: function (e, t) {
                return -Math.cos(e * ((t || 5) - 0.5) * 2 * Math.PI) / 2 + 0.5;
              },
              wobble: function (e) {
                return -Math.cos(e * Math.PI * (9 * e)) / 2 + 0.5;
              },
              sinusoidal: function (e) {
                return -Math.cos(e * Math.PI) / 2 + 0.5;
              },
              flicker: function (e) {
                return (
                  (e += (Math.random() - 0.5) / 5),
                  i.sinusoidal(e < 0 ? 0 : 1 < e ? 1 : e)
                );
              },
              mirror: function (e) {
                return e < 0.5
                  ? i.sinusoidal(2 * e)
                  : i.sinusoidal(1 - 2 * (e - 0.5));
              },
            };
            t.exports = i;
          },
          {},
        ],
        "webengage/engagement": [
          function (f, e, t) {
            "use strict";
            var s =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  };
            var y = f("webengage/logger"),
              x = f("webengage/properties"),
              E = f("webengage/events"),
              R = f("webengage/util"),
              L = f("webengage/state"),
              _ = f("webengage/instance"),
              M = f("webengage/rules"),
              z = f("webengage/load"),
              W = f("webengage/async"),
              F = f("webengage/dom"),
              U = f("webengage/journey-cxr"),
              q = f("webengage/weq"),
              j = X.require("webengage/xpath"),
              B = f("webengage/logger"),
              V = f("webengage/comm"),
              H = "maxTimesPerUser",
              G = {
                feedback: "isFQ",
                survey: "isSRQ",
                notification: "isNQ",
                webPersonalization: "isWPQ",
              },
              Y = {
                feedback: "enableFeedback",
                survey: "enableSurvey",
                notification: "enableNotification",
                webPersonalization: "enableWebPersonalization",
                notificationInbox: "enableInboxNotification",
              };
            function n(S, e) {
              var C = this,
                I = "webengage." + S,
                o = null,
                T = {};
              (T.type = S),
                (T.key = I),
                (T.licenseCode = ""),
                (T.frameId = e.frameId),
                (T.methods = e.methods),
                (T.entities = []),
                (C.options = function (e, t) {
                  q.set(e, t, T.key);
                });
              var d = {},
                k = {},
                t = x.instanceCallbacks;
              "webPersonalization" === S &&
                (t = [].concat(
                  (function (e) {
                    if (Array.isArray(e)) {
                      for (var t = 0, n = Array(e.length); t < e.length; t++)
                        n[t] = e[t];
                      return n;
                    }
                    return Array.from(e);
                  })(t),
                  ["render", "prepare"]
                ));
              for (var n = 0; n < t.length; n++) {
                var i = t[n],
                  a = "on" + R.capitalize(i);
                (C[a] = (function (t) {
                  return function (e) {
                    "function" == typeof e &&
                      E.subscribe(T.type + "." + t, R.guard(e, !0));
                  };
                })(i)),
                  (k[a] = (function (t) {
                    return function (e) {
                      "function" == typeof e &&
                        (d[t] && 0 < d[t].length ? d[t].push(e) : (d[t] = [e]));
                    };
                  })(i));
              }
              function A(e) {
                return "notification" === S
                  ? e.notificationEncId
                  : "webPersonalization" === S
                  ? e.webPersonalizationEncId
                  : "survey" === S
                  ? e.surveyEncId
                  : "notificationInbox" === S
                  ? e.childVariationId
                    ? e.childVariationId
                    : e.variationId
                  : void 0;
              }
              function b(e) {
                return "notification" === S
                  ? e.notificationEncId
                  : "webPersonalization" === S
                  ? e.experimentEncId
                  : "survey" === S
                  ? e.surveyEncId
                  : void 0;
              }
              function r(t, n) {
                T.methods.getData
                  ? T.methods.getData(t, T.licenseCode, function (e) {
                      n(e, t);
                    })
                  : n(null, t);
              }
              function u(e) {
                (e.instance.preparing = !0),
                  (e = T.methods.prepare(e, T.licenseCode, T.config));
              }
              function O(e) {
                return !!e.journeyId;
              }
              function w(e) {
                var t = e.instance;
                t.abortRender && e.clearEntity(),
                  (!R.isEmptyObject(e.instance) && e.instance.preparing) ||
                    (u(e), (t = e.instance)),
                  t.frame && (t.frame.id = T.frameId);
                for (var n = 0; n < x.instanceCallbacks.length; n++) {
                  var i = "on" + R.capitalize(x.instanceCallbacks[n]),
                    o = "webengage." + T.type + "." + i;
                  "function" == typeof q.get(o) && k[i](q.get(o));
                }
                for (var a in d)
                  if (d.hasOwnProperty(a)) {
                    var r = d[a];
                    if (r && r.length)
                      for (var s = 0; s < r.length; s++) {
                        var c = T.type + "." + a;
                        E.subscribe(c, R.guard(r[s], !0));
                      }
                  }
                if (
                  (e.instance.id &&
                    (delete e.instance.preparing,
                    L.getMinimizedState(S, e.instance.id)
                      ? e.instance.minimize()
                      : e.instance.show(),
                    (k.entity = e)),
                  "webPersonalization" !== S)
                )
                  for (var l = 0; l < T.entities.length; l++) {
                    var g = T.entities[l];
                    e.instance.id !== g.instance.id &&
                      g.instance.preparing &&
                      g.clearEntity();
                  }
              }
              function N(e, t, o, n, i) {
                if (n) return i(e);
                var a = [];
                W.mapParallel(
                  e,
                  function (n, i) {
                    var e = n.dynamicElementDataFetch
                      ? n[t].replace(
                          /operands\['we_wk_cssProperty'\]\('[^']*'\) != null/g,
                          "'true'"
                        )
                      : n[t];
                    M.evaluate(
                      A(n),
                      e,
                      o
                    )(function (e, t) {
                      t && a.push(n), i(e);
                    });
                  },
                  function (e) {
                    i(a);
                  }
                );
              }
              function m(n, e, i) {
                if ("webPersonalization" === S) {
                  if (X.hideDom && "function" != typeof X.hideDom.abort)
                    return i();
                  (
                    q.has(I + ".isPreviewMode")
                      ? q.get(I + ".isPreviewMode")
                      : q.get("webengage.isPreviewMode") || !1
                  )
                    ? y.debug({ msg: "PREVIEW MODE SKIP P13 CALLS", ctx: n })
                    : r(n, function (e) {
                        for (var t = 0; t < e.length; t++)
                          (n[t].instance.layoutId =
                            n[t].layout || (n[t].la && n[t].la.id)),
                            (n[t].instance.data = e[t]),
                            (n[t].instance.preparing = !0),
                            u(n[t]),
                            i(n[t]);
                      });
                } else
                  W.mapSeries(
                    n,
                    function (t, n) {
                      if (
                        (e && !t.pf) ||
                        t.instance.preparing ||
                        ("webPersonalization" === S &&
                          X.hideDom &&
                          "function" != typeof X.hideDom.abort)
                      )
                        return n();
                      (t.instance.preparing = !0),
                        r(t, function (e) {
                          (t.instance.layoutId = t.layout || (t.la && t.la.id)),
                            (t.instance.data = e),
                            u(t),
                            n();
                        });
                    },
                    function () {
                      i();
                    }
                  );
              }
              function P(e, t) {
                if ("boolean" === R.type(e))
                  return !0 === e && (t.forcedRender = !0), e;
                if ("array" === R.type(e))
                  return (
                    -1 < R.indexOfArray(e, t.experimentEncId) &&
                    (t.forcedRender = !0)
                  );
                if ("function" === R.type(e)) {
                  var n = e(t);
                  return (n = !0 === n) && (t.forcedRender = !0), n;
                }
              }
              function s(e, t) {
                for (var n = [], i = 0; i < e.length; i++) {
                  var o = e[i];
                  if (O(o)) {
                    var a = f("webengage/profile").getProfileJourneyContext(
                      o.journeyId
                    );
                    if (
                      a &&
                      a.id &&
                      ((o.scope = a.id || ""),
                      (o.scopeType = ""),
                      (o.scopedId = A(o)),
                      o.scope &&
                        (o.scopedId += "[" + R.escapeScopeChars(o.scope) + "]"),
                      (o.instance.scopedId = o.scopedId),
                      !P(t, o))
                    ) {
                      if (L.ifClosed(S, o.scopedId) || L.ifTaken(S, o.scopedId))
                        continue;
                      if (
                        "number" === R.type(o[H]) &&
                        o[H] <= L.getTimesShown(S, o.scopedId)
                      )
                        continue;
                    }
                  }
                  n.push(o);
                }
                return n;
              }
              function D(t, n, i) {
                N(t, "ruleCodeR2", null, n, function (e) {
                  if (((e = s(e, i)), "webPersonalization" === S)) {
                    if (0 < e.length) return c(e);
                    X.hideDom &&
                      "function" == typeof X.hideDom.abort &&
                      X.hideDom.abort();
                  } else {
                    if (0 < e.length)
                      return O(t[0]) && (U.follow(S), U.unfollow(S)), c(e);
                    m(t, !0, function () {}),
                      O(t[0]) && U.follow(S),
                      o && E.unsubscribe(x.CHANNEL_PROFILE_UPDATED, o),
                      (o = function () {
                        o &&
                          N(t, "ruleCodeR2", null, n, function (e) {
                            0 < (e = s(e, i)).length &&
                              (E.unsubscribe(x.CHANNEL_PROFILE_UPDATED, o),
                              (o = null),
                              c(e),
                              O(t[0]) && U.unfollow(S));
                          });
                      }),
                      E.subscribe(x.CHANNEL_PROFILE_UPDATED, o);
                  }
                });
              }
              function h(e) {
                var t = Z.webengage_fs_configurationMap,
                  n = M.util.sampling(),
                  i = null,
                  o = !1;
                if (
                  t.cgDetails &&
                  e.hasOwnProperty("excludeUCG") &&
                  !e.excludeUCG
                ) {
                  var a = t.cgDetails.UNIVERSAL,
                    r = a && Object.keys(a).length ? Object.keys(a)[0] : null,
                    s =
                      a && Object.values(a).length
                        ? JSON.parse(Object.values(a)[0].range)
                        : [];
                  if (!s.length) return !1;
                  for (var c = 0; c < s.length; c++) {
                    var l = s[c];
                    if (l[0] === n || (l[0] < n && l[1] > n)) {
                      (i = { cg_id: r }), (o = !0);
                      break;
                    }
                  }
                }
                if (e.cgId && !o) {
                  var g = t.cgDetails.CUSTOM,
                    d = e.cgId,
                    u = g[d] ? JSON.parse(g[d].range) : [];
                  if (!u.length) return !1;
                  for (var p = 0; p < u.length; p++) {
                    var f = u[p];
                    if (f[0] === n || (f[0] < n && f[1] > n)) {
                      i = { cg_id: d };
                      break;
                    }
                  }
                }
                return (
                  i &&
                    ((e.bucketValue = n),
                    (e = Object.assign(e, i)).instance.events.abs_view(i),
                    (O(e) || "webPersonalization" === S) &&
                      e.instance.events.control_group(i)),
                  !!i
                );
              }
              function v(e, t, n) {
                var i =
                    _weq[
                      "webengage.webPersonalization.multipleCampaignsOnSelector"
                    ],
                  o = e && e.propertyVal;
                if (i) {
                  var a = e && e.selector && e.selector.op;
                  return "replace" !== a || !t.includes(o) || !n[o].includes(a);
                }
                return !t.includes(o);
              }
              function c(e) {
                if ("webPersonalization" === S) {
                  for (
                    var t = [], n = 0, i = [], o = {}, a = 0;
                    n < e.length;
                    n++
                  )
                    if (a < 5 && v(e[n], i, o)) {
                      var r = e[n] && e[n].selector && e[n].selector.op,
                        s = e[n] && e[n].propertyVal;
                      if (
                        (r && (o[s] || (o[s] = []), o[s].push(r)),
                        i.push(s),
                        a++,
                        h(e[n]))
                      )
                        continue;
                      if (e[n].isControl && e[n].controlGroup)
                        X.hideDom &&
                          "function" == typeof X.hideDom.abort &&
                          X.hideDom.abort(),
                          e[n].instance.events.abs_view(),
                          e[n].instance.events.control_group();
                      else {
                        var c = e[n];
                        (e[n].bucketValue = c.userSamplingValue), t.push(c);
                      }
                    }
                  var l = (function (e) {
                    function o(e) {
                      switch (e) {
                        case "before":
                          return -1;
                        case "after":
                          return 0;
                        case "replace":
                          return 1;
                        default:
                          return 0;
                      }
                    }
                    return e.sort(function (e, t) {
                      var n = e.selector && e.selector.op,
                        i = t.selector && t.selector.op;
                      return o(n) - o(i);
                    });
                  })(t);
                  (f = l.map(function (e) {
                    return e.experimentEncId;
                  })),
                    _weq[
                      "webengage.webPersonalization.currentlyActiveWebPersonalization"
                    ] ||
                      (_weq[
                        "webengage.webPersonalization.currentlyActiveWebPersonalization"
                      ] = f),
                    m(l, !1, function (e) {
                      w(e);
                    });
                } else
                  for (var g, d = 0; d < e.length; d++)
                    if (!h(e[d])) {
                      var u = e[d].sampling || 100;
                      if (O(e[d])) {
                        u = 100 - (e[d].controlGroup || 0);
                        var p = M.util.sampling(b(e[d]), e[d].journeyId);
                        e[d].bucketValue = p;
                      } else p = M.util.sampling(b(e[d]));
                      if (p <= u)
                        return (
                          m([(g = e[d])], !1, function (e) {
                            w(g);
                          }),
                          A(g)
                        );
                      O(e[d]) && e[d].controlGroup
                        ? (e[d].instance.events.abs_view(),
                          e[d].instance.events.control_group())
                        : e[d].instance.events.abs_view();
                    }
                var f;
              }
              function p(e) {
                var t = e.variations,
                  n = M.util.sampling(b(e)),
                  i = void 0,
                  o = 0;
                if (t && t.length)
                  for (var a = 0; a < t.length; a++)
                    if (n <= (o += t[a].sampling))
                      return ((i = t[a]).userSamplingValue = n), i;
                return i;
              }
              if (
                ((C.init = R.guard(function (e, t) {
                  (T.licenseCode = e),
                    (T.config = t.config[S + "Config"]),
                    (T.entities =
                      "webPersonalization" === S
                        ? t[[S + "RuleList"]] || {}
                        : R.mapArray(t[S + "RuleList"] || [], function (e) {
                            return R.copy({}, e);
                          }));
                  var n = q.has(I + ".isDemoMode")
                      ? q.get(I + ".isDemoMode")
                      : q.get("webengage.isDemoMode") || !1,
                    i = q.has(I + ".isPreviewMode")
                      ? q.get(I + ".isPreviewMode")
                      : q.get("webengage.isPreviewMode") || !1;
                  if (
                    ("feedback" === S && (T.entities = [{}]),
                    (t.config[Y[T.type]] && !t[G[T.type]]) ||
                      n ||
                      i ||
                      (T.entities = []),
                    "webPersonalization" === S)
                  ) {
                    var s = {},
                      c = [],
                      l = [];
                    Object.keys(T.entities).forEach(function (e) {
                      if (!R.isEmptyObject(T.entities[e])) {
                        var t =
                          ((o = T.entities[e]),
                          (a = e),
                          (r = {
                            filteredEntities: [],
                            activeProperties: [],
                            dynamicEntities: [],
                          }),
                          Object.keys(o).forEach(function (i) {
                            if (0 < o[i].length) {
                              var e =
                                "id" === a
                                  ? "(((( operands['we_wk_cssProperty']('" +
                                    i +
                                    "') != null ))))"
                                  : "(((( operands['we_wk_contentXPathNode']('" +
                                    i +
                                    "') != null ))))";
                              M.evaluate(
                                null,
                                e,
                                null
                              )(function (e, t) {
                                (r.filteredEntities = r.filteredEntities.concat(
                                  o[i]
                                )),
                                  r.activeProperties.push(i);
                                for (var n = 0; n < o[i].length; n++)
                                  (o[i][n].propertyVal = i),
                                    (o[i][n].propertyType = a),
                                    t ||
                                      ((o[i][n].isDynamicElement = !0),
                                      (o[i][n].dynamicElementDataFetch = !0));
                                t ||
                                  (r.dynamicEntities = r.dynamicEntities.concat(
                                    o[i]
                                  ));
                              });
                            }
                          }),
                          r);
                        (c = c.concat(t.filteredEntities)),
                          (s[e] = t.activeProperties),
                          t.dynamicEntities &&
                            (l = l.concat(t.dynamicEntities));
                      }
                      var o, a, r;
                    }),
                      (T.entities = c);
                    for (
                      var o = setInterval(function () {
                          if (l.length) {
                            var d = [],
                              e =
                                _weq[
                                  "webengage.webPersonalization.currentlyActiveWebPersonalization"
                                ];
                            l.forEach(function (l) {
                              if (
                                !e ||
                                !e.length ||
                                e.includes(l.experimentEncId)
                              ) {
                                var g = q.has(
                                  "webengage.webPersonalization.skipRules"
                                )
                                  ? q.has(
                                      "webengage.webPersonalization.skipRules"
                                    )
                                  : q.get("webengage.skipRules") || !1;
                                M.evaluate(
                                  null,
                                  l.ruleCodeR1,
                                  q.get("webengage.ruleData") || {}
                                )(function (e, t) {
                                  g || t
                                    ? M.evaluate(
                                        null,
                                        l.ruleCodeR2,
                                        q.get("webengage.ruleData") || {}
                                      )(function (e, t) {
                                        if (g || t) {
                                          var n =
                                              l.instance.data &&
                                              l.instance.data.id,
                                            i =
                                              l.instance.data &&
                                              l.instance.data.experimentId;
                                          if (
                                            _weq[
                                              "webengage.webPersonalization.reTryWebPersonalization"
                                            ] &&
                                            _weq[
                                              "webengage.webPersonalization.reTryWebPersonalization"
                                            ].includes(i)
                                          ) {
                                            var o =
                                                l.instance.data &&
                                                l.instance.data
                                                  .layoutAttributes,
                                              a =
                                                o && o.dom_id && o.dom_id.value,
                                              r =
                                                o && o.dom_id && o.dom_id.type,
                                              s =
                                                (o &&
                                                  o.dom_id &&
                                                  o.dom_id.op) ||
                                                "replace",
                                              c = void 0;
                                            "xpath" == r && "" != a
                                              ? (c = j.getXPathElement(a))
                                              : "" != a && (c = F.queryOne(a)),
                                              (c &&
                                                R.isPropertyPersonalized(
                                                  c,
                                                  s,
                                                  l.instance.data
                                                )) ||
                                                X.webPersonalization.render({
                                                  webPersonalizationId: n,
                                                  isDynamicElement: !0,
                                                }),
                                              d.push(l);
                                          } else
                                            i
                                              ? X.webPersonalization.render({
                                                  webPersonalizationId: n,
                                                  isDynamicElement: !0,
                                                })
                                              : d.push(l);
                                        } else d.push(l);
                                      })
                                    : d.push(l);
                                });
                              }
                            }),
                              d.length ? (l = d) : clearInterval(o);
                          } else clearInterval(o);
                        }, 5e3),
                        a = 0;
                      a < T.entities.length;
                      a++
                    ) {
                      var r = p(T.entities[a]);
                      r
                        ? ((T.entities[a].webPersonalizationEncId = r.id),
                          (T.entities[a].layout = r.layout),
                          (T.entities[a].actionLinks = r.actionLinks),
                          (T.entities[a].sampling = r.sampling),
                          (T.entities[a].userSamplingValue =
                            r.userSamplingValue))
                        : ((T.entities[a].isControl = !0),
                          (T.entities[a].webPersonalizationEncId =
                            T.entities[a].experimentEncId));
                    }
                  }
                  for (var g = 0; g < T.entities.length; g++) {
                    var d = T.entities[g];
                    "webPersonalization" === S
                      ? (d.instance = new _(T, d, b(d)))
                      : "notificationInbox" === S
                      ? (T.entities[g].instance = new _(T, d, A(d)))
                      : (d.instance = new _(T, d, A(d))),
                      T.methods.clearEntity &&
                        (d.clearEntity = (function (e) {
                          return function () {
                            (e.instance.preparing = null),
                              (e.instance.abortRender = null),
                              T.methods.clearEntity(e);
                          };
                        })(d)),
                      (d.ruleCodeR1 = d.pageRuleCode || "true"),
                      (d.ruleCodeR2 = d.eventRuleCode || "true"),
                      d.sessionRuleCode &&
                        (d.ecp || O(d)
                          ? (d.ruleCodeR2 += " && " + d.sessionRuleCode)
                          : (d.ruleCodeR1 += " && " + d.sessionRuleCode));
                  }
                })),
                (C.abort = function () {
                  C.clear();
                }),
                (C.clear = R.guard(function () {
                  var e = T.entities;
                  for (var t in d)
                    if (d.hasOwnProperty(t)) {
                      var n = d[t];
                      if (n && n.length)
                        for (var i = 0; i < n.length; i++) {
                          var o = T.type + "." + t;
                          E.unsubscribe(o, n[i]);
                        }
                    }
                  d = {};
                  for (var a = 0; a < e.length; a++)
                    e[a].clearEntity && e[a].clearEntity();
                  T.methods.clear(e);
                })),
                (C.render = R.guard(function (s) {
                  (s = s || {}).isDynamicElement || C.clear();
                  var e,
                    t,
                    n,
                    c,
                    i,
                    o = T.entities;
                  for (var a in s)
                    s.hasOwnProperty(a) &&
                      s[a] &&
                      "function" == typeof k[a] &&
                      k[a](s[a]);
                  var l =
                      "feedback" === S ||
                      (s.hasOwnProperty("forcedRender")
                        ? s.forcedRender
                        : q.has(I + ".forcedRender")
                        ? q.get(I + ".forcedRender")
                        : q.get("webengage.forcedRender") || !1),
                    g =
                      "feedback" === S ||
                      (s.hasOwnProperty("skipRules")
                        ? s.skipRules
                        : q.has(I + ".skipRules")
                        ? q.get(I + ".skipRules")
                        : q.get("webengage.skipRules") || !1),
                    r =
                      s.hasOwnProperty("isDemoMode") || s.hasOwnProperty("demo")
                        ? s.isDemoMode || s.demo
                        : q.has(I + ".isDemoMode")
                        ? q.get(I + ".isDemoMode")
                        : q.get("webengage.isDemoMode") || !1,
                    d = s.isDynamicElement || !1;
                  s.hasOwnProperty("skipRuleExecution") &&
                    (g = !0 === s.skipRuleExecution),
                    s.hasOwnProperty("showAllClosedAndTakenSurveys") &&
                      (l = !0 === s.showAllClosedAndTakenSurveys);
                  var u = R.clone(
                      s.customData || s.data || {},
                      q.get(I + ".customData") ||
                        q.get("webengage.customData") ||
                        {}
                    ),
                    p = R.clone(
                      s.tokens || {},
                      q.get(I + ".tokens") || q.get("webengage.tokens") || {}
                    ),
                    f = R.clone(
                      s.ruleData || {},
                      q.get(I + ".ruleData") ||
                        q.get("webengage.ruleData") ||
                        {}
                    ),
                    b = L.getServerTimestamp(),
                    w = -1 < "Mobile|Tablet".indexOf(M.util.getDevice());
                  if ((n = s[S + "Id"])) {
                    for (c = 0, e = []; c < o.length; c++)
                      if (n === A(o[c])) {
                        d &&
                          o[c].isDynamicElement &&
                          delete o[c].isDynamicElement,
                          e.push(o[c]);
                        break;
                      }
                    o = e;
                  }
                  if ("survey" === S) {
                    var m =
                        s.scope ||
                        q.get("webengage.survey.scope") ||
                        q.get("webengage.scope") ||
                        "",
                      h =
                        s.scopeType ||
                        q.get("webengage.survey.scopeType") ||
                        q.get("webengage.scopeType") ||
                        "";
                    if (l) {
                      var v = [];
                      for (c = 0; c < o.length; c++) {
                        (t = o[c]), P(l, t) && v.push(t.surveyEncId);
                      }
                      v.length &&
                        (m
                          ? "object" === R.type(m)
                            ? (m = [m])
                            : "array" !== R.type(m) &&
                              (m = [{ scope: String(m), scopeType: h }])
                          : (m = []),
                        m.push({
                          scope: new Date().getTime(),
                          scopeType: "session",
                          surveyIds: v,
                        }));
                    }
                    var y,
                      x = {};
                    if (m) {
                      for (
                        "object" === R.type(m)
                          ? (m = [m])
                          : "array" !== R.type(m) &&
                            (m = [{ scope: String(m), scopeType: h }]),
                          c = 0;
                        c < m.length;
                        c++
                      )
                        if (
                          "array" === R.type(m[c].surveyIds) &&
                          0 < m[c].surveyIds.length
                        )
                          for (i = 0; i < m[c].surveyIds.length; i++)
                            x[m[c].surveyIds[i]] = {
                              scope: m[c].scope,
                              scopeType: m[c].scopeType || "",
                            };
                        else
                          x.all = {
                            scope: m[c].scope,
                            scopeType: m[c].scopeType || "",
                          };
                      for (c = 0; c < o.length; c++)
                        (t = o[c]),
                          (y = x[t.surveyEncId] || x.all || {}),
                          (t.scope = y.scope || ""),
                          (t.scopeType = y.scopeType || ""),
                          (t.scopedId = o[c].surveyEncId),
                          t.scope &&
                            (t.scopedId +=
                              "[" + R.escapeScopeChars(t.scope) + "]"),
                          (t.instance.scopedId = t.scopedId);
                    }
                  }
                  if (!r) {
                    for (c = 0, e = []; c < o.length; c++) {
                      if (
                        ((n = (t = o[c]).scopedId || t.instance.id),
                        !P(l, t) && !O(t))
                      ) {
                        if (
                          (L.ifClosed(S, n) || L.ifTaken(S, n)) &&
                          "webPersonalization" !== S
                        )
                          continue;
                        if (
                          "number" === R.type(t[H]) &&
                          t[H] <= L.getTimesShown(S, n)
                        )
                          continue;
                      }
                      if (!(t.endTimestamp < b || b < t.startTimestamp)) {
                        if (t.mobile && !w)
                          if (
                            !(
                              t.layout &&
                              ("~483819h" === t.layout ||
                                "~fg00aad" == t.layout)
                            )
                          )
                            continue;
                        if (
                          ("notification" === S ||
                            "webPersonalization" === S) &&
                          t.skipTargetPage &&
                          t.actionLinks
                        ) {
                          var E = t.actionLinks.slice();
                          for (i = 0; i < E.length; i++) {
                            var _ = K.createElement("a");
                            (_.href = E[i]),
                              (E[i] = "^" + R.escapeForRegExp(_.href) + "$"),
                              (_ = null);
                          }
                          if (M.util.isMatches(Z.location.href, E)) continue;
                        }
                        e.push(t);
                      }
                    }
                    o = e;
                  }
                  return (
                    N(o, "ruleCodeR1", f, g, function (i) {
                      if (0 !== i.length) {
                        for (c = 0; c < i.length; c++) {
                          var e = i[c];
                          if (
                            ((e.instance.customData = u),
                            (e.instance.tokens = p),
                            (e.instance.ruleData = f),
                            (e.instance.scope = m),
                            (e.instance.scopeType = h),
                            "feedback" === T.type)
                          ) {
                            var t =
                              "boolean" == typeof s.showAllCategories
                                ? s.showAllCategories
                                : q.get("webengage.feedback.showAllCategories");
                            s.feedbackButtonAlignment &&
                              (s.alignment = s.feedbackButtonAlignment),
                              s.feedbackButtonAlignment &&
                                (s.alignment = s.feedbackButtonAlignment),
                              s.feedbackButtonBorderColor &&
                                (s.borderColor = s.feedbackButtonBorderColor),
                              s.feedbackButtonBackgroundColor &&
                                (s.backgroundColor =
                                  s.feedbackButtonBackgroundColor),
                              s.defaultFeedbackCategory &&
                                (s.defaultCategory = s.defaultFeedbackCategory),
                              s.showAllFeedbackCategories &&
                                (t = s.showAllFeedbackCategories),
                              (e.instance.showAllCategories = t),
                              (e.instance.alignment =
                                s.alignment ||
                                q.get("webengage.feedback.alignment")),
                              (e.instance.borderColor =
                                s.borderColor ||
                                q.get("webengage.feedback.borderColor")),
                              (e.instance.backgroundColor =
                                s.backgroundColor ||
                                q.get("webengage.feedback.backgroundColor")),
                              (e.instance.defaultCategory =
                                s.defaultCategory ||
                                q.get("webengage.feedback.defaultCategory")),
                              (e.instance.showForm =
                                s.showForm ||
                                q.get("webengage.feedback.showForm")),
                              (e.instance.formData =
                                s.formData ||
                                q.get("webengage.feedback.formData")),
                              (e.instance.isMobile = w);
                          }
                        }
                        if ("webPersonalization" === S) {
                          for (var n = [], o = 0, a = []; o < i.length; o++)
                            (a.includes(i[o].propertyVal) &&
                              i[o - 1].order !== i[o].order) ||
                              (a.push(i[o].propertyVal), n.push(i[o]));
                          i = n;
                        } else
                          for (c = 0; c < i.length - 1; c++)
                            if (!O(i[c]) && i[c].order !== i[c + 1].order) {
                              i.splice(c + 1, i.length - c - 1);
                              break;
                            }
                        if ("survey" !== S || l) 0 < i.length && D(i, g, l);
                        else {
                          var r =
                            ("http:" == location.protocol
                              ? "http:"
                              : "https:") +
                            "//survey.webengage.com/publisher-widget-loader.html?action=findAllTakenSurveys&licenseCode=" +
                            q.get("webengage.licenseCode") +
                            "&url=" +
                            encodeURIComponent(Z.location.href) +
                            "&" +
                            R.mapArray(i, function (e) {
                              return "surveyIds=" + e.surveyEncId;
                            }).join("&") +
                            (x
                              ? "&scope=" + encodeURIComponent(R.stringify(x))
                              : "");
                          z.script(r)(function () {
                            if (
                              "undefined" != typeof we_notToExecuteSurveyIdsMap
                            ) {
                              var e,
                                t,
                                n = we_notToExecuteSurveyIdsMap;
                              if (
                                n.takenSurveyIds !== $ &&
                                0 < n.takenSurveyIds.length
                              )
                                for (e = 0; e < n.takenSurveyIds.length; e++)
                                  for (t = 0; t < i.length; t++)
                                    if (
                                      n.takenSurveyIds[e] === i[t].surveyEncId
                                    ) {
                                      L.markAsTaken("survey", i[t].scopedId),
                                        i.splice(t, 1);
                                      break;
                                    }
                              if (
                                n.inactiveSurveyIds !== $ &&
                                0 < n.inactiveSurveyIds.length
                              )
                                for (e = 0; e < n.inactiveSurveyIds.length; e++)
                                  for (t = 0; t < i.length; t++)
                                    if (
                                      n.inactiveSurveyIds[e] ===
                                      i[t].surveyEncId
                                    ) {
                                      i.splice(t, 1);
                                      break;
                                    }
                            }
                            0 < i.length && D(i, g, l);
                          });
                        }
                      } else
                        "webPersonalization" === S &&
                          X.hideDom &&
                          "function" == typeof X.hideDom.abort &&
                          X.hideDom.abort();
                    }),
                    k
                  );
                })),
                "notificationInbox" === S)
              ) {
                var l = ["view", "read", "unread"],
                  g =
                    ("http:" == location.protocol ? "http:" : "https:") +
                    "https://c.webengage.com:443/inbox/v1/userNotificationsCount/" +
                    X.getLicenseCode() +
                    "/" +
                    (X.state.getForever().cuid
                      ? X.state.getForever().cuid
                      : X.state.getForever().luid);
                (C.getUserNotificationCount = R.guard(function (t) {
                  try {
                    V.xhr(g, null, function (e) {
                      (e = JSON.parse(e)) &&
                      e.response &&
                      e.response.data &&
                      e.response.data.count
                        ? t(e.response.data.count)
                        : t("");
                    });
                  } catch (e) {
                    B.debug({
                      msg: "Notification Inbox Count API Incorrect Status",
                      err: e,
                    });
                  }
                })),
                  (C.onNotificationIconClick = R.guard(function () {
                    E.publish("event.system", "inbox_notification_reset_count");
                  })),
                  (C.getNotificationList = R.guard(function (e, t) {
                    if (!e) return "function" == typeof t ? t([]) : [];
                    0 === Object.keys(e).length && (e = null),
                      T.methods.notificationInboxInit(
                        X.getLicenseCode(),
                        e,
                        function () {
                          T.entities.forEach(function (o) {
                            E.subscribe(
                              "notificationInbox.click." + o.instance.id,
                              function (e) {
                                var t = e.actionTarget,
                                  n = e.actionLink;
                                "_blank" !== t
                                  ? (Z.location.href = n)
                                  : Z.open(n, t);
                              }
                            ),
                              (o.view = R.guard(function () {
                                o &&
                                  o.instance &&
                                  ("function" == typeof o.instance.open &&
                                    o.instance.open(),
                                  o.instance.events &&
                                    "function" ==
                                      typeof o.instance.events.open &&
                                    o.instance.events.open());
                              })),
                              (o.click = R.guard(function (e, t, n, i) {
                                e &&
                                  t &&
                                  o &&
                                  o.instance &&
                                  ("function" == typeof o.instance.click &&
                                    o.instance.click(e, t, n),
                                  o.instance.events &&
                                    "function" ==
                                      typeof o.instance.events.click &&
                                    o.instance.events.click(e, t, n, i));
                              })),
                              (o.read = R.guard(function () {
                                o &&
                                  o.instance &&
                                  ("function" == typeof o.instance.read &&
                                    o.instance.read(),
                                  o.instance.events &&
                                    "function" ==
                                      typeof o.instance.events.read &&
                                    o.instance.events.read(),
                                  (o.state = "READ"));
                              })),
                              (o.unread = R.guard(function () {
                                o &&
                                  o.instance &&
                                  ("function" == typeof o.instance.unread &&
                                    o.instance.unread(),
                                  o.instance.events &&
                                    "function" ==
                                      typeof o.instance.events.unread &&
                                    o.instance.events.unread(),
                                  (o.state = "UNREAD"));
                              })),
                              (o.delete = R.guard(function () {
                                o &&
                                  o.instance &&
                                  ("function" == typeof o.instance.delete &&
                                    o.instance.delete(),
                                  o.instance.events &&
                                    "function" ==
                                      typeof o.instance.events.delete &&
                                    o.instance.events.delete());
                              })),
                              (o.getCTADetails = R.guard(function () {
                                return o.message &&
                                  o.message.androidDetails &&
                                  o.message.androidDetails.cta
                                  ? o.message.androidDetails.cta
                                  : o.message.iosDetails &&
                                    o.message.iosDetails.cta
                                  ? o.message.iosDetails.cta
                                  : "";
                              })),
                              (o.getMessage = R.guard(function (e) {
                                return e && !0 === e
                                  ? o.message &&
                                    o.message.customizations &&
                                    o.message.customizations.richMessage
                                    ? o.message.customizations.richMessage
                                    : ""
                                  : o.message && o.message.message
                                  ? o.message.message
                                  : "";
                              })),
                              (o.getTitle = R.guard(function (e) {
                                return e && !0 === e
                                  ? o.message &&
                                    o.message.customizations &&
                                    o.message.customizations.richTitle
                                    ? o.message.customizations.richTitle
                                    : ""
                                  : o.message && o.message.title
                                  ? o.message.title
                                  : "";
                              }));
                          }),
                            "function" == typeof t && t(T.entities);
                        }
                      );
                  })),
                  (C.markStatus = R.guard(function (e, t, n) {
                    if (
                      (t >= l.length
                        ? B.debug({
                            msg: "Notification Inbox Incorrect Status",
                          })
                        : e.forEach(function (e) {
                            "function" == typeof e[l[t]] &&
                              e.status !== l[t].toUpperCase() &&
                              e[l[t]]();
                          }),
                      "function" == typeof n)
                    )
                      return n(e);
                  })),
                  (C.delete = R.guard(function (e, t) {
                    if (
                      (e.forEach(function (e) {
                        "function" == typeof e.delete && e.delete();
                      }),
                      "function" == typeof t)
                    )
                      return t(e);
                  }));
              }
              return C;
            }
            (n.util = {
              getClientDataString: function (e) {
                var t = {};
                function n(e) {
                  if ("function" === R.type(e))
                    try {
                      e = e();
                    } catch (e) {}
                  return R.inArray(
                    ["string", "number", "boolean", "date"],
                    R.type(e)
                  ) &&
                    (t = e) == t &&
                    Math.abs(t) !== 1 / 0
                    ? e
                    : null;
                  var t;
                }
                if ("object" === (void 0 === e ? "undefined" : s(e)))
                  for (var i in e) {
                    var o = e[i];
                    if (o instanceof Array) {
                      for (var a = [], r = 0; r < o.length; r++)
                        (o[r] = n(o[r])), o[r] != $ && a.push(o[r]);
                      0 < a.length && (t[i] = a);
                    } else (o = n(o)) != $ && (t[i] = [o]);
                  }
                return R.stringify(t);
              },
              loadFrame: function (a, r, e, s) {
                return (
                  ((e = e || {}).onload = function (t) {
                    var e = F.iframe.getDoc(t),
                      n = e.createElement("form");
                    for (var i in ((n.method = "POST"), (n.action = a), r))
                      if (r.hasOwnProperty(i)) {
                        var o = K.createElement("input");
                        (o.type = "hidden"),
                          (o.name = i),
                          (o.value = r[i]),
                          n.appendChild(o);
                      }
                    if (
                      (F.queryOne("body", e).appendChild(n),
                      n.submit(),
                      "function" == typeof s)
                    ) {
                      E.bind(t, "load", function e() {
                        s(function () {
                          E.unbind(t, "load", e);
                        });
                      });
                    }
                  }),
                  F.iframe.create(e)
                );
              },
              getActivity: function () {
                var e = L.getSession();
                return {
                  pageUrl: Z.location.href,
                  pageTitle: K.title,
                  referrer: K.referrer || "",
                  browser: M.util.getBrowser(),
                  browserVersion: M.util.getBrowserVersion(),
                  platform: M.util.getOS(),
                  ip: e ? e.ip : "",
                  city: e ? e.we_city : "",
                  region: e ? e.we_region : "",
                  country: e ? e.we_country : "",
                };
              },
            }),
              (e.exports = n);
          },
          {},
        ],
        "webengage/events": [
          function (e, t, n) {
            "use strict";
            var o = e("webengage/util/bare"),
              c = {},
              l = {},
              g = Array.prototype.slice,
              i = {
                bind: function (e, t, n, i) {
                  if ("function" != typeof n)
                    throw new Error(
                      'Third argument "callback" is not a function'
                    );
                  "function" != typeof n.guard_ && (n.guard_ = o.guard(n)),
                    e.addEventListener
                      ? e.addEventListener(t, n.guard_, i)
                      : e.attachEvent && e.attachEvent("on" + t, n.guard_);
                },
                unbind: function (e, t, n) {
                  if ("function" != typeof n)
                    throw new Error(
                      'Third argument "callback" is not a function or has not been previously binded'
                    );
                  "function" == typeof n.guard_ &&
                    (e.removeEventListener
                      ? e.removeEventListener(t, n.guard_)
                      : e.detachEvent && e.detachEvent("on" + t, n.guard_));
                },
                subscribe: function (e, t) {
                  if (
                    (c[e] || (c[e] = { subscribers: [] }),
                    "function" != typeof t)
                  )
                    throw new Error(
                      'Second argument "callback" is not a function'
                    );
                  return (
                    "function" != typeof t.guard_ && (t.guard_ = o.guard(t)),
                    c[e].subscribers.push(t),
                    [e, t]
                  );
                },
                unsubscribe: function (e) {
                  var t, n;
                  if (1 === arguments.length) {
                    if (!(e instanceof Array))
                      throw new Error(
                        "events.unsubscribe() expects either a subscriber handle (array) or channel & callback as arguments"
                      );
                    (t = e[0]), (n = e[1]);
                  } else (t = e), (n = arguments[1]);
                  if ("function" != typeof n)
                    throw new Error(
                      '"callback" is not a function or has not previously subscribed'
                    );
                  if (c[t] && "function" == typeof n.guard_) {
                    var i = o.indexOfArray(c[t].subscribers || [], n);
                    if (-1 === i) return;
                    c[t].subscribers.splice(i, 1);
                  }
                },
                publish: function (e) {
                  for (
                    var t,
                      n = e.split("."),
                      i = g.call(arguments, 1),
                      o = n.length - 1;
                    0 <= o;
                    o--
                  ) {
                    if (
                      ((t = n.slice(0, o + 1).join(".")),
                      c.hasOwnProperty(t) && c[t])
                    )
                      for (
                        var a = c[t].subscribers.slice(), r = 0, s = a.length;
                        r < s;
                        r++
                      )
                        a[r].guard_.apply(null, i);
                    l[t] = !0;
                  }
                },
                happened: function (e) {
                  return l[e] || !1;
                },
                desubscribe: function (e) {
                  c[e] = null;
                },
                reload: function () {
                  (c = {}), (l = {});
                },
              };
            t.exports = i;
          },
          {},
        ],
        "webengage/feedback": [
          function (e, t, n) {
            "use strict";
            function p(e, t, n) {
              return (
                t in e
                  ? Object.defineProperty(e, t, {
                      value: n,
                      enumerable: !0,
                      configurable: !0,
                      writable: !0,
                    })
                  : (e[t] = n),
                e
              );
            }
            var f = e("webengage/util"),
              b = e("webengage/weq"),
              w = e("webengage/events"),
              m = e("webengage/engagement"),
              h = e("webengage/properties"),
              v = e("webengage/state"),
              y = e("webengage/dom"),
              d = e("webengage/colors"),
              u = e("webengage/ua"),
              x = e("webengage/rules"),
              E = (e("webengage/events"), e("webengage/logger")),
              _ = e("webengage/callback-frame"),
              S = "webklipper-publisher-widget-container-content",
              C = "webklipper-publisher-widget-container-close-div",
              I =
                "webklipper-publisher-widget-container-content-expand-collapse",
              T =
                "webklipper-publisher-widget-container-content-expand-collapse-wrapper",
              k = "webklipper-publisher-widget-container-frame-container",
              A = "webklipper-publisher-widget-container-frame-wrapper",
              O = "webklipper-publisher-widget-container-frame",
              o = "webklipper-publisher-widget-container-base",
              a = "webklipper-publisher-widget-container-light-box-container",
              N = "webklipper-publisher-widget-container-light-box-loader",
              r = "webklipper-publisher-widget-container-light-box-content",
              P = "webklipper-publisher-widget-container-mob-close-div",
              D =
                ("http:" == location.protocol ? "http:" : "https:") +
                "//feedback.webengage.com/publisher-feedback-frame-loader",
              R = function (e, t) {
                return "Mobile" === e || "Tablet" === e
                  ? '<div id="' +
                      C +
                      '"></div>' +
                      (t
                        ? "<div id=" +
                          T +
                          '>\n                        <div id="' +
                          I +
                          '">\n                            <div>\n                            </div>\n                        </div>\n                    </div>'
                        : '<div id="' +
                          I +
                          '">\n                        <div>\n                        </div>\n                    </div>') +
                      '<div id="' +
                      o +
                      '" style="display: none; margin: 0px; padding: 0px; z-index: 16776287; position: fixed; overflow: hidden; top: 0px; left: 0px; height: 100%; width: 100%; background-color: rgba(0, 0, 0, 0.85098);"></div><div id="' +
                      a +
                      '" style="display: none; top: 0px; left: 0px; width: 100%; position: fixed; backface-visibility: hidden; margin: 0px; padding: 0px; z-index: 16776288;"><div id="' +
                      N +
                      '" style="background-color: #ffffff; padding: 20px; display: block; width: 300px; position: fixed; top: 50%; margin-top: -29px;text-align: center;left:50%;margin-left:-170px">Loading...</div><div id="' +
                      r +
                      '" style="display: none; text-align: center; position: absolute; width: 100%; height: 100%; left: 0px; top: 0px; box-sizing: border-box; padding: 0px 8px; margin: 0px; overflow-y: auto; overflow-x: hidden;"><div id="' +
                      k +
                      '" style="position: relative; vertical-align: middle; text-align: left; margin: 0px auto; max-width: 900px; width: 90%; overflow: visible; box-sizing: content-box; font-size: 100%; line-height: 1em; font-weight: normal; font-family: Arial, sans-serif; border: 6px solid rgb(102, 102, 102); height: 388px; display: block; border-radius: 4px; box-shadow: rgba(0, 0, 0, 0.298039) 0px 0px 15px 15px; background: transparent; -moz-opacity : 0; -khtml-opacity  : 0;opacity : 0;"><div id="' +
                      A +
                      '" style="height: 100%; width: 100%; overflow: auto; -webkit-overflow-scrolling: touch;"></div><div id="' +
                      P +
                      '" style="height: 2.31em; width: 2.31em; cursor: pointer; position: absolute; top: -1.15em; right: -1.15em; z-index: 16776293; font-family: Arial, sans-serif; font-size: 1.23em; line-height: 1.5em; color: rgb(255, 255, 255); text-shadow: rgb(0, 0, 0) 0.08em 0.08em; border-radius: 1.54em; border: 0.08em solid rgb(187, 187, 187); background-color: rgb(102, 102, 102); background-position: 0px 0px; background-repeat: no-repeat;"><span style="display: inline-block;width: 1.23em;margin-left: 0.65em;margin-top: 0.25em;font-size: 1.23em;line-height: 1.23em;">X</span></div></div></div></div>'
                  : '<div id="' +
                      N +
                      '" style="display: none; width: 100%; text-align: center; position: absolute; top: 50%; margin-top: -10px;">Loading...</div><div id="' +
                      C +
                      '"></div><div id="' +
                      I +
                      '"><div></div></div><div id="' +
                      k +
                      '" style="height : 0; -moz-opacity : 0; -khtml-opacity  : 0;opacity : 0;"></div>';
              };
            var L = y.queryOne,
              M = y.query;
            function z(e, t) {
              var n = X.feedback.getContainer();
              if (e && !t.snapshotDone) {
                var i = S + "-snapshot-frame",
                  o = y.iframe.create({
                    name: i,
                    frameContainer: X.feedback.getContainer(),
                    css: { height: "0px", width: "0px", borderWidth: 0 },
                  });
                o.id = i;
                var a = "IE" !== u.device,
                  r = (function () {
                    L("head"), L("body");
                    var e = !1,
                      t = M("base");
                    if (t.length)
                      for (var n = 0; n < t.length; n++)
                        if (t[n].href) {
                          e = !0;
                          break;
                        }
                    var i = K.characterSet || K.charSet || !1,
                      o = L("html").outerHTML;
                    if (!e) {
                      var a = '<base href="' + K.location.href + '"/>';
                      o = o.replace(/(<head[^>]*>)/im, "$1" + a);
                    }
                    (o = (o = (o = o.replace(
                      /<webengagedata[\s\S]*<\/webengagedata>/gim,
                      ""
                    )).replace(
                      /<webengage[\s\S]*<\/webengage>/gim,
                      ""
                    )).replace(
                      /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gim,
                      ""
                    )),
                      i &&
                        (o = o.replace(
                          "<head>",
                          "<head><meta charset='" + i + "'>"
                        ));
                    var r,
                      s = new RegExp(
                        "((href|src)=[\"'])(//[^'\"]*)([\"'])",
                        "g"
                      );
                    return (
                      (o = o.replace(s, function (e, t, n, i, o) {
                        return t + Z.location.protocol + i + o;
                      })),
                      ((r = K.doctype)
                        ? "<!DOCTYPE " +
                          r.name +
                          (r.publicId ? ' PUBLIC "' + r.publicId + '"' : "") +
                          (!r.publicId && r.systemId ? " SYSTEM" : "") +
                          (r.systemId ? ' "' + r.systemId + '"' : "") +
                          ">"
                        : "<!DOCTYPE html>") + o
                    );
                  })();
                !0 === a &&
                  (r = (function (e) {
                    function t(e) {
                      for (
                        var t = 256,
                          n = [],
                          i = 8,
                          o = 0,
                          a = 0,
                          r = 0,
                          s = e.length;
                        r < s;
                        r++
                      )
                        for (
                          o = (o << i) + e[r], a += i, ++t >> i && i++;
                          7 < a;

                        )
                          (a -= 8), n.push(o >> a), (o &= (1 << a) - 1);
                      return n.push(a ? o << (8 - a) : ""), n;
                    }
                    function n(e) {
                      for (
                        var t = [], n = 0, i = 0, o = "", a = 0, r = e.length;
                        a < r;
                        a++
                      ) {
                        var s = e[a];
                        127 < s && ((s -= 128), (i += Math.pow(2, n))),
                          0 == s ||
                          34 == s ||
                          37 == s ||
                          38 == s ||
                          39 == s ||
                          43 == s ||
                          61 == s ||
                          92 == s
                            ? t.push("=" + String.fromCharCode(s + 16))
                            : t.push(String.fromCharCode(s)),
                          6 < ++n &&
                            ((o +=
                              0 == i ||
                              34 == i ||
                              37 == i ||
                              38 == i ||
                              39 == i ||
                              43 == i ||
                              61 == i ||
                              92 == i
                                ? "=" + String.fromCharCode(i + 16) + t.join("")
                                : String.fromCharCode(i) + t.join("")),
                            (t = []),
                            (n = i = 0));
                      }
                      return (o +=
                        0 == i ||
                        34 == i ||
                        37 == i ||
                        38 == i ||
                        39 == i ||
                        43 == i ||
                        61 == i ||
                        92 == i
                          ? "=" + String.fromCharCode(i + 16) + t.join("")
                          : String.fromCharCode(i) + t.join(""));
                    }
                    e = String.fromCharCode(74) + e;
                    for (var i = "", o = 0, a = 0, r = 0; r < 256; r++)
                      i += String.fromCharCode(224);
                    var s = 256,
                      c = {};
                    for (r = 0; r < 256; r++) c[String.fromCharCode(r)] = r;
                    var l = [],
                      g = "",
                      d = "";
                    r = 0;
                    for (var u = e.length; r < u; r++) {
                      var p = e.charAt(r),
                        f = p.charCodeAt(0);
                      if (255 < f) {
                        var b = f;
                        switch (f) {
                          case 8364:
                            f = 128;
                            break;
                          case 8218:
                            f = 130;
                            break;
                          case 402:
                            f = 131;
                            break;
                          case 8222:
                            f = 132;
                            break;
                          case 8230:
                            f = 133;
                            break;
                          case 8224:
                            f = 134;
                            break;
                          case 8225:
                            f = 135;
                            break;
                          case 710:
                            f = 136;
                            break;
                          case 8240:
                            f = 137;
                            break;
                          case 352:
                            f = 138;
                            break;
                          case 8249:
                            f = 139;
                            break;
                          case 338:
                            f = 140;
                            break;
                          case 381:
                            f = 142;
                            break;
                          case 8216:
                            f = 145;
                            break;
                          case 8217:
                            f = 146;
                            break;
                          case 8220:
                            f = 147;
                            break;
                          case 8221:
                            f = 148;
                            break;
                          case 8226:
                            f = 149;
                            break;
                          case 8211:
                            f = 150;
                            break;
                          case 8212:
                            f = 151;
                            break;
                          case 732:
                            f = 152;
                            break;
                          case 8482:
                            f = 153;
                            break;
                          case 353:
                            f = 154;
                            break;
                          case 8250:
                            f = 155;
                            break;
                          case 339:
                            f = 156;
                            break;
                          case 382:
                            f = 158;
                            break;
                          case 376:
                            f = 159;
                        }
                        b != f
                          ? ((p = String.fromCharCode(f)),
                            a++,
                            256 <= ++o && ((g += i), (o = 0)))
                          : (0 < o && ((g += i.substr(0, o)), (o = 0)),
                            (g += String.fromCharCode(parseInt(f / 256))));
                      } else a++, 256 <= ++o && ((g += i), (o = 0));
                      d = c[(b = d + p)]
                        ? b
                        : (255 < f && (p = String.fromCharCode(f % 256)),
                          l.push(c[d]),
                          (c[b] = s++),
                          "" + p);
                    }
                    return (
                      "" != d && l.push(c[d]),
                      0 < o && (g += i.substr(0, o)),
                      (i = n(t(l))),
                      e.length != a
                        ? i +
                          "==" +
                          (e = n(
                            t(
                              (function (e) {
                                for (
                                  var t = [], n = 256, i = {}, o = 0;
                                  o < 256;
                                  o++
                                )
                                  i[String.fromCharCode(o)] = o;
                                var a = "";
                                o = 0;
                                for (var r = e.length; o < r; o++) {
                                  var s = e.charAt(o),
                                    c = a + s;
                                  a = i[c]
                                    ? c
                                    : (t.push(i[a]), (i[c] = n++), "" + s);
                                }
                                return "" != a && t.push(i[a]), t;
                              })(g)
                            )
                          ))
                        : i
                    );
                  })(r));
                var s = y.createElement("form", "");
                n.appendChild(s),
                  (s.className = "webengage-snapshot-form"),
                  (s.target = i),
                  (s.method = "post"),
                  (s.enctype = "multipart/form-data"),
                  (s["accept-charset"] = "utf-8"),
                  (s.action =
                    ("http:" == location.protocol ? "http:" : "https:") +
                    "//snapservice.webengage.com/fileService/?action=savepage");
                var c = {
                  html: encodeURIComponent(r),
                  enc: K.characterSet || K.charSet,
                  folder: "feedback/" + b.get("webengage.licenseCode"),
                  fileName: t.snapshotFileName,
                  zip: a,
                  docHeight: y.css.getDocumentHeight(),
                  docWidth: y.css.getDocumentWidth(),
                };
                for (var l in c) {
                  var g = y.createElement("input", "");
                  (g.name = l),
                    (g.value = c[l]),
                    (g.type = "hidden"),
                    s.appendChild(g);
                }
                s.submit(),
                  (t.snapshotDone = !0),
                  E.debug({ msg: "FEEDBACK SNAPSHOT START", ctx: c }),
                  (o.onload = function () {
                    y.iframe.remove(o),
                      y.remove(s),
                      E.debug({ msg: "FEEDBACK SNAPSHOT DONE", ctx: c });
                  });
              }
            }
            function i(e, t, n) {
              var i =
                  "Mobile" === x.util.getDevice() ||
                  "Tablet" === x.util.getDevice()
                    ? "mobile"
                    : "web",
                o = e.instance,
                a = X.feedback.layout[i],
                r = X.feedback.getContainer(),
                s = b.get("webengage.feedback.custom"),
                c =
                  (b.get("webengage.feedback.custom.css"),
                  b.get("webengage.feedback.tab")),
                l = "mobile" === i && "tab" === c;
              (n.alignment = e.instance.alignment || n.alignment),
                (n.borderColor = e.instance.borderColor || n.borderColor),
                (n.borderColor = e.instance.borderColor || n.borderColor),
                (n.backgroundColor =
                  e.instance.backgroundColor || n.backgroundColor),
                r ||
                  (((r = y.createElement("div", R(x.util.getDevice(), l))).id =
                    S),
                  h.widgetContainer.appendChild(r)),
                s ||
                  ("tab" === c
                    ? X.feedback.layout.web.alignTab(n, l)
                    : a.alignTab(n));
              var g = y.queryOne("#" + I, r);
              f.inArray(n.launchType, "externalLink") &&
                (n.externalLinkId
                  ? f.mapArray(n.externalLinkId.split(/\s*,\s*/), function (e) {
                      var t = y.queryOne("#" + e);
                      t
                        ? w.bind(t, "click", function () {
                            g.click();
                          })
                        : E.debug({
                            msg: "FEEDBACK EXTERNAL LAUNCHTYPE ELEMENT NOT PRESENT",
                            ctx: { launchType: n.launchType, externalId: e },
                          });
                    })
                  : E.warn({
                      msg: "FEEDBACK LAUNCHTYPE NOT SPECIFIED",
                      ctx: {
                        launchType: n.launchType,
                        externalId: n.externalLinkId,
                      },
                    }));
              var d =
                "Mobile" === x.util.getDevice() ||
                "Tablet" === x.util.getDevice()
                  ? y.queryOne("#" + P, r)
                  : y.queryOne("#" + C, r);
              function u() {
                w.unbind(g, "click", o.hide),
                  w.bind(g, "click", o.show),
                  w.unbind(d, "click", o.hide);
              }
              return (
                (o.show = function () {
                  a.show(),
                    (function (e, c, l) {
                      var t =
                          "Mobile" === x.util.getDevice() ||
                          "Tablet" === x.util.getDevice()
                            ? "mobile"
                            : "web",
                        g = X.feedback.layout[t],
                        n = v.getForever(),
                        i = m.util.getActivity();
                      c.snapshotFileName = n.luid + "-" + new Date().getTime();
                      var o = {
                        licenseCode: e,
                        widgetVersion: "4",
                        event: "open",
                        url: Z.location.href,
                        title: K.title,
                        luid: v.getForever().luid,
                        enableCallbacks: !0,
                        docHeight: y.css.getDocumentHeight(),
                        docWidth: y.css.getDocumentWidth(),
                        cbFrame: _.getName(),
                      };
                      (o = f.copy(
                        o,
                        {
                          formDataString: c.formData
                            ? f.stringify(c.formData)
                            : null,
                          clientDataString: c.customData
                            ? m.util.getClientDataString(c.customData)
                            : null,
                          showMobile: c.isMobile,
                          wflt: l.wflt,
                          demo: b.get("webengage.isDemoMode"),
                          language: b.get("webengage.language"),
                          defaultFeedbackCategory: c.defaultCategory,
                          showAllFeedbackCategories: c.showAllCategories,
                          snapshotEnabled: l.snapshotEnabled,
                          snapshotFileName: c.snapshotFileName,
                          buttonAlignment: c.alignment || l.alignment,
                          showBorder: !0,
                          borderColor: c.borderColor,
                          country: i.country,
                          region: i.region,
                          city: i.city,
                          browser: i.browser,
                          version: i.browserVersion,
                          platform: i.platform,
                        },
                        !0,
                        !0
                      )),
                        !0 === b.get("webengage.aip") && (o.aip = 1),
                        n.cuid && (o.cuid = n.cuid);
                      var a =
                        "mobile" === t
                          ? y.queryOne("#" + A, X.feedback.getContainer())
                          : y.queryOne("#" + k, X.feedback.getContainer());
                      (c.frame = m.util.loadFrame(D, o, {
                        name: O,
                        frameContainer: a,
                        css: {
                          height: "100%",
                          width: "100%",
                          display: "block",
                        },
                      })),
                        _.onMessage(
                          ("http:" == location.protocol ? "http:" : "https:") +
                            "//feedback.webengage.com",
                          "feedback",
                          function (e) {
                            if (
                              "feedback" === (e = f.parseJSON(e)).engagement
                            ) {
                              var t = e.eventName,
                                n = b.get("webengage.feedback.custom"),
                                i = b.get("webengage.feedback.custom.css");
                              switch (t) {
                                case "load":
                                case "resize":
                                  g.resize(e.data.height);
                                  break;
                                case "open":
                                  if (n) {
                                    if (g.applyCustomCSS) {
                                      var o,
                                        a = X.feedback.getContainer(),
                                        r = y.queryOne("#" + N, a),
                                        s =
                                          (p(
                                            (o = {
                                              opacity: "1",
                                              "-khtml-opacity": 1,
                                            }),
                                            "opacity",
                                            "1"
                                          ),
                                          p(o, "position", "fixed"),
                                          p(o, "display", "block"),
                                          p(o, "min-height", "130px"),
                                          o);
                                      X.util.copy(s, i, !0),
                                        g.applyCustomCSS(s),
                                        y.css.applyCss(r, { display: "none" }),
                                        y.css.applyCss(a, { display: "block" });
                                    }
                                  } else g.alignLayout();
                                  c.events && c.events.open(e.data),
                                    g.resize(e.data.height);
                                  break;
                                case "submit":
                                  c.events && c.events.submit(e.data);
                                  break;
                                case "close":
                                  c.events && c.events.close(e.data), c.hide();
                                  break;
                                case "snapshot":
                                  z(l.snapshotEnabled, c),
                                    g.resize(e.data.height);
                              }
                            }
                          }
                        );
                    })(t, o, n),
                    w.unbind(g, "click", o.show),
                    w.bind(g, "click", o.hide),
                    w.bind(d, "click", o.hide);
                }),
                (o.hide = function () {
                  a.hide(),
                    (o.snapshotDone = !1),
                    y.iframe.remove(o.frame),
                    (o.frame = null);
                  var e = y.queryOne("#" + k, X.feedback.getContainer());
                  y.css.applyCss(e, { opacity: "0" }), u();
                }),
                o.showForm ? o.show() : u(),
                E.debug({ msg: "FEEDBACK PREPARED" }),
                e
              );
            }
            function s(e, t) {
              return (t = t || {}).response || {};
            }
            function c(e) {
              if (e && e.instance) {
                var t = e.instance;
                t.frame && (y.iframe.remove(t.frame), (t.frame = null)),
                  (t.snapshotDone = !1),
                  t.reset();
              }
            }
            function l() {
              var e = X.feedback.getContainer();
              y.remove(e);
            }
            t.exports = function () {
              var g = new m("feedback", {
                methods: {
                  prepare: i,
                  getCallbackData: s,
                  clear: l,
                  clearEntity: c,
                },
                frameId: "webklipper-publisher-widget-container-frame",
              });
              return (
                (g.getContainer = function () {
                  return y.queryOne("#" + S);
                }),
                (g.layout = {
                  web: {
                    padding: "3",
                    paddingTop: "7",
                    paddingBottom: "33",
                    config: {},
                    widthWhenClosed: 0,
                    show: function () {
                      var e = g.getContainer(),
                        t = y.queryOne("#" + C, e),
                        n = y.queryOne("#" + N, e);
                      y.css.applyCss(e, { width: "450px" }),
                        y.css.applyCss(t, { display: "block" }),
                        setTimeout(function () {
                          y.css.applyCss(n, { display: "block" });
                        }, 500);
                    },
                    hide: function () {
                      var e = g.getContainer(),
                        t = y.queryOne("#" + C, e),
                        n = y.queryOne("#" + N, e);
                      y.css.applyCss(e, { width: this.widthWhenClosed }),
                        y.css.applyCss(t, { display: "none" }),
                        y.css.applyCss(n, { display: "none" });
                    },
                    alignTab: function (e, t) {
                      var n = g.getContainer(),
                        i = y.queryOne("#" + C, n),
                        o = y.queryOne("#" + I, n),
                        a = y.queryOne("div", o);
                      (e = d.addHash(e)),
                        (this.config = e),
                        (this.widthWhenClosed =
                          !f.inArray(
                            this.config.launchType,
                            "feedbackButton"
                          ) && f.inArray(this.config.launchType, "externalLink")
                            ? "0"
                            : parseInt(this.config.imgWidth) +
                              parseInt(2 * this.padding) +
                              "px");
                      var r = {
                        "border-color": "rgb(204, 204, 204)",
                        margin: "0px",
                        padding: "0px",
                        position: "fixed",
                        "border-width": "1px 0px 1px 1px",
                        "border-style": "solid",
                        top: "50%",
                        "margin-top":
                          "-" +
                          (
                            (parseInt(this.paddingTop, 10) +
                              parseInt(this.paddingBottom, 10) +
                              parseInt(e.imgHeight, 10)) /
                            2
                          ).toString() +
                          "px",
                        "z-index": y.css.getMaxZIndex() + 1,
                        "background-color": "rgb(249, 249, 249)",
                        "-webkit-transition": "width 0.5s",
                        transition: "width 0.5s",
                        overflow: "visible",
                        "-webkit-box-sizing": "content-box",
                        "-moz-box-sizing": "content-box",
                        "box-sizing": "content-box",
                      };
                      if (
                        ((r.width = this.widthWhenClosed),
                        "left" === e.alignment
                          ? (r.left = "0px")
                          : (r.right = "0px"),
                        t)
                      ) {
                        var s = y.queryOne("#" + T, n);
                        y.css.applyCss(s, r);
                      } else y.css.applyCss(n, r);
                      var c = {
                        height: "22px",
                        width: "22px",
                        cursor: "pointer",
                        position: "absolute",
                        top: "-14px",
                        display: "none",
                        "z-index": y.css.getMaxZIndex() + 1,
                        "background-image": e.closeImg
                          ? 'url("https://afiles.webengage.com' +
                            e.closeImg +
                            '")'
                          : 'url("https://ssl.widgets.webengage.com/images/icons/feedback-widget-close.png")',
                        "background-size": "22px 22px",
                        "background-color": "transparent",
                        "background-position": "0px 0px",
                        "background-repeat": "no-repeat",
                        overflow: "visible",
                        "-webkit-box-sizing": "content-box",
                        "-moz-box-sizing": "content-box",
                        "box-sizing": "content-box",
                      };
                      "left" === e.alignment
                        ? (c.right = "-14px")
                        : (c.left = "-14px"),
                        y.css.applyCss(i, c);
                      var l = {
                        margin: "0px",
                        padding:
                          this.paddingTop +
                          "px " +
                          this.padding +
                          "px " +
                          this.paddingBottom +
                          "px",
                        cursor: "pointer",
                        display: "block",
                        "background-position": e.showWeIcon
                          ? "50% 100%"
                          : "50% 0%",
                        "background-repeat": "no-repeat",
                        overflow: "visible",
                        border: "1px solid " + e.borderColor,
                        height:
                          parseInt(e.imgHeight) -
                          (e.showWeIcon ? 0 : 23) +
                          "px",
                        width: e.imgWidth + "px",
                        "background-color": e.backgroundColor,
                        "background-image": d.isColorTooLight(e.backgroundColor)
                          ? 'url("https://ssl.widgets.webengage.com/images/webengage/icons/feedback-tab-bg-light.png")'
                          : 'url("https://ssl.widgets.webengage.com/images/webengage/icons/feedback-tab-bg-dark.png")',
                        "z-index": y.css.getMaxZIndex(),
                        "-webkit-box-sizing": "content-box",
                        "-moz-box-sizing": "content-box",
                        "box-sizing": "content-box",
                      };
                      (l.float = "left" === e.alignment ? "right" : "left"),
                        y.css.applyCss(o, l),
                        y.css.applyCss(a, {
                          margin: "0px",
                          padding: "0px",
                          width: e.imgWidth + "px",
                          height: e.imgHeight + "px",
                          "background-image":
                            "url(" + h.feedbackImageBaseUrl + e.imgPath + ")",
                          overflow: "visible",
                          "-webkit-box-sizing": "content-box",
                          "-moz-box-sizing": "content-box",
                          "box-sizing": "content-box",
                        });
                    },
                    alignLayout: function () {
                      var e = this.config,
                        t = g.getContainer(),
                        n = y.queryOne("#" + k, t),
                        i = y.queryOne("#" + N, t);
                      y.css.applyCss(i, { display: "none" });
                      var o = {
                        "-moz-opacity": 1,
                        "-khtml-opacity": 1,
                        opacity: "1",
                        position: "absolute",
                        width: "424px",
                        outline: "transparent solid 1px",
                        "min-height": "130px",
                        border: "1px solid rgb(204, 204, 204)",
                        height: "341.7px",
                        display: "block",
                        "margin-top": "-170.85px",
                        top: "50%",
                        background: "none transparent",
                      };
                      "left" === e.alignment
                        ? (o.right =
                            parseInt(e.imgWidth) +
                            parseInt(2 * this.padding) +
                            "px")
                        : (o.left =
                            parseInt(e.imgWidth) +
                            parseInt(2 * this.padding) +
                            "px"),
                        y.css.applyCss(n, o);
                    },
                    applyCustomCSS: function (e) {
                      var t = y.queryOne("#" + k, g.getContainer());
                      y.css.applyCss(t, e);
                    },
                    resize: function (e) {
                      var t = y.queryOne("#" + k, g.getContainer()),
                        n = y.css.getWindowHeight(),
                        i = n < e ? -0.45 * n : -e / 2,
                        o = n < e ? 0.9 * n : e;
                      y.queryOne("#" + O, g.getContainer()),
                        y.css.applyCss(t, {
                          height: o + "px",
                          "margin-top": i + "px",
                          "max-height": 0.9 * n + "px",
                          scroll: "auto",
                        });
                    },
                  },
                  mobile: {
                    show: function () {
                      var e = g.getContainer(),
                        t = y.queryOne("#" + o, e),
                        n = y.queryOne("#" + a, e),
                        i = y.queryOne("#" + N, e);
                      y.css.applyCss(t, { display: "block" }),
                        y.css.applyCss(n, {
                          display: "block",
                          position: "absolute",
                        }),
                        y.css.applyCss(i, { display: "block" });
                    },
                    hide: function () {
                      var e = g.getContainer(),
                        t = y.queryOne("#" + o, e),
                        n = y.queryOne("#" + a, e),
                        i = y.queryOne("#" + N, e);
                      y.css.applyCss(t, { display: "none" }),
                        y.css.applyCss(n, { display: "none" }),
                        y.css.applyCss(i, { display: "none" });
                    },
                    alignTab: function (e) {
                      var t = g.getContainer(),
                        n = y.queryOne("#" + I, t);
                      y.queryOne("#" + N, t),
                        (n.innerHTML =
                          '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:sketch="http://www.bohemiancoding.com/sketch/ns" width="40px" height="40px" viewBox="0 0 180 180" style="padding:7px;" version="1.1"><title>180 - iPhone 6 Plus</title><desc>Created with Sketch.</desc><defs></defs><g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" sketch:type="MSPage"><g id="180---iPhone-6-Plus" sketch:type="MSArtboardGroup" fill="#1A1918"><g id="Imported-Layers" sketch:type="MSLayerGroup" transform="translate(11.000000, 17.000000)"><path d="M137.853,52.283 C135.333462,22.50325 102.805731,0.973875 65.1838846,4.134375 C27.5620385,7.319375 -0.917307692,34.012125 1.57776923,63.76125 C3.29619231,84.2065 19.1839615,100.7685 41.1687692,108.100125 C38.7042692,115.156125 34.185,122.518375 26.1555,129.24975 C26.1555,129.24975 55.5582692,128.2575 72.8892692,111.934375 C73.3418077,111.90375 73.7882308,111.916 74.253,111.87925 C111.880962,108.71875 140.348077,82.032125 137.853,52.283" id="Fill-1" sketch:type="MSShapeGroup"></path><path d="M157.373308,102.74075 C158.296731,90.993 152.621654,79.98025 143.136692,72.415875 C135.266192,96.10125 111.434538,114.457875 81.4875,119.308875 C88.5874615,127.932875 99.7235769,134.015 112.596462,135.20325 C118.491692,135.74225 124.172885,135.20325 129.407654,133.77 C139.400192,139.307 151.312962,145.19925 151.312962,145.19925 C147.215654,141.42625 143.864423,131.8835 142.213269,127.89 C150.799269,122.01 156.578308,113.12875 157.373308,102.74075" id="Fill-2" sketch:type="MSShapeGroup"></path></g></g></g></svg>');
                      var i = {
                        margin: "0px",
                        padding: "0px",
                        cursor: "pointer",
                        display: "block",
                        "border-radius": "75px",
                        border: "1px solid rgb(204, 204, 204)",
                        "box-shadow": "rgb(136, 136, 136) 1px 1px 8px",
                        "box-sizing": "border-box",
                        "text-align": "center",
                        "z-index": "16776274",
                        background: "rgb(255, 255, 255)",
                        float: "left" === e.alignment ? "right" : "left",
                        position: "fixed",
                        width: "58px",
                        height: "58px",
                        bottom: "15px",
                      };
                      "left" === e.alignment
                        ? (i.left = "15px")
                        : (i.right = "15px"),
                        y.css.applyCss(n, i),
                        (f.inArray(e.launchType, "feedbackButton") &&
                          !1 !== e.showMobile) ||
                          y.css.applyCss(n, { display: "none" });
                    },
                    alignLayout: function () {
                      var e = g.getContainer(),
                        t = y.queryOne("#" + a, e),
                        n = y.queryOne("#" + r, e),
                        i = y.queryOne("#" + k, e),
                        o = y.queryOne("#" + N, e);
                      y.css.applyCss(t, {
                        height: y.css.getDocumentHeight() + "px",
                      }),
                        y.css.applyCss(o, { display: "none" }),
                        y.css.applyCss(n, { display: "block" }),
                        y.css.applyCss(i, {
                          display: "block",
                          "-moz-opacity": 1,
                          "-khtml-opacity": 1,
                          opacity: "1",
                        });
                    },
                    resize: function (e) {
                      var t = y.queryOne("#" + k, g.getContainer()),
                        n =
                          (y.queryOne("#" + O, g.getContainer()),
                          y.css.getWindowHeight()),
                        i = n < e ? 0.05 * n : (n - e) / 2,
                        o = n < e ? 0.9 * n : e,
                        a =
                          Z.pageYOffset !== $
                            ? Z.pageYOffset
                            : (K.documentElement || K.body.parentNode || K.body)
                                .scrollTop;
                      y.css.applyCss(t, {
                        height: o + "px",
                        "max-height": 0.9 * n + "px",
                        top: a + i + "px",
                      });
                    },
                  },
                }),
                E.debug({ msg: "FEEDBACK INIT" }),
                g
              );
            };
          },
          {},
        ],
        "webengage/fetch-helper": [
          function (e, t, n) {
            "use strict";
            var o = e("webengage/weq"),
              i = e("webengage/state"),
              a = e("webengage/util"),
              r = e("webengage/logger"),
              s = e("webengage/properties");
            function c() {
              var e = new Headers(),
                t = globalThis ? globalThis.localStorage : Z.localStorage;
              t.getItem(s.WP_AUTH_TOKEN_KEY) &&
                e.append("authorization", t.getItem(s.WP_AUTH_TOKEN_KEY)),
                o.get("webengage.licenseCode") &&
                  e.append("lc", o.get("webengage.licenseCode"));
              var n = i.getForever();
              return (
                n && n.cuid && e.append("cuid", n.cuid),
                n && n.luid && e.append("luid", n.luid),
                { headers: e }
              );
            }
            function l(e) {
              r.error(e.message);
            }
            t.exports = {
              fetchKeepAlive: function (e, t, n) {
                var i = c().headers;
                (e = (e = e.replace("http:", "https:")).startsWith("https")
                  ? e
                  : "https://" + e),
                  fetch(e, {
                    headers: i,
                    body: t,
                    keepalive: !0,
                    method: "POST",
                  })
                    .then(function (e) {
                      if (401 === e.status) {
                        var t = o.get(
                          "webengage.auth.tokenInvalidatedCallback"
                        );
                        "function" == typeof t && a.guard(t, !0)(), r.error(e);
                      } else n();
                    })
                    .catch(l);
              },
              jsonp: function (e, t, n) {
                var i = c().headers;
                (n = n || "callback"),
                  (e = (e = e.replace("http:", "https:")).startsWith("https")
                    ? e
                    : "https://" + e),
                  (e = a.addParamsToURL(e, {})),
                  fetch(e, { headers: i })
                    .then(function (e) {
                      (e = e.text()), t(e);
                    })
                    .catch(l);
              },
              initHeaders: c,
            };
          },
          {},
        ],
        "webengage/geo": [
          function (e, t, n) {
            "use strict";
            var i = e("webengage/state"),
              o = e("webengage/weq"),
              a = e("webengage/util"),
              r = e("webengage/comm"),
              s = null,
              c = {
                get: function () {
                  if (!s) {
                    var e = i.getSession();
                    s = {
                      country: e.country || null,
                      region: e.region || null,
                      city: e.city || null,
                      we_country: e.we_country || null,
                      we_region: e.we_region || null,
                      we_city: e.we_city || null,
                      ip: e.ip || null,
                    };
                  }
                  return s;
                },
                set: function (e) {
                  var t = i.getSession();
                  a.copy(t, {
                    country: e.geoplugin_countryName || "",
                    region: e.geoplugin_region || "",
                    city: e.geoplugin_city || "",
                    we_country: e.country || "",
                    we_region: e.region || "",
                    we_city: e.city || "",
                    ip: e.clientIp || "",
                  }),
                    (s = null),
                    i.setSession(t);
                },
                load: function (t) {
                  if (c.isLoaded()) t();
                  else {
                    var e =
                      "//c.webengage.com/geoip.js?" +
                      (!0 === o.get("webengage.aip") ? "&aip=1" : "");
                    r.jsonp(
                      e,
                      function (e) {
                        c.set(e), t();
                      },
                      "jsoncallback"
                    );
                  }
                },
                isLoaded: function () {
                  return !!i.getSession().ip;
                },
              };
            e("webengage/dependency").register("geo", function (e, t) {
              c.load(t);
            }),
              (t.exports = c);
          },
          {},
        ],
        "webengage/indexedDB-helper": [
          function (e, t, n) {
            "use strict";
            var r = e("webengage/events"),
              s = globalThis || Z,
              i = {
                connection: function (e, t, n, i, o) {
                  var a = s.indexedDB.open(e, t);
                  (a.onupgradeneeded = function (e) {
                    var t = e.target.result;
                    t.objectStoreNames.contains(n) ||
                      t.createObjectStore(n, { keyPath: i });
                  }),
                    (a.onsuccess = function (e) {
                      var t = e.target.result;
                      (t.onerror = function (e) {
                        r.publish("error", e);
                      }),
                        "function" == typeof o && o(t);
                    });
                },
              };
            t.exports = i;
          },
          {},
        ],
        "webengage/instance": [
          function (e, t, n) {
            "use strict";
            var f = e("webengage/events"),
              b = e("webengage/util"),
              w = e("webengage/state"),
              s = e("webengage/properties"),
              c = e("webengage/logger"),
              m = {
                open: "view",
                close: "close",
                click: "click",
                submit: "submit",
                complete: "complete",
                abs_view: "abs_view",
                control_group: "control_group",
              };
            t.exports = function (i, g, d) {
              i.key;
              var u = i.type,
                p = this;
              function o(e, t) {
                var n = u;
                if (m.hasOwnProperty(e)) {
                  var i,
                    o,
                    a,
                    r = {
                      id: d,
                      layout_id: g.layout,
                      total_view_count: w.getEntity(
                        "open",
                        !0,
                        "forever",
                        u,
                        g.scopedId || g.instance.id,
                        "abs_view" === e || "control_group" === e
                      ),
                      total_view_count_session: w.getEntity(
                        "open",
                        !0,
                        "session",
                        u,
                        g.scopedId || g.instance.id,
                        "abs_view" === e || "control_group" === e
                      ),
                    },
                    s = {};
                  if (
                    ("notification" === u &&
                      g.journeyId &&
                      (r.total_view_count = w.getTotalViewsAcrossScope(
                        "notification",
                        g.instance.id
                      )),
                    g.experimentEncId && (r.experiment_id = g.experimentEncId),
                    g.journeyId && (r.journey_id = g.journeyId),
                    g.scope && (r.scope = g.scope),
                    b.isEmptyObject(p.tokens) ||
                      (r.tokens = b.copy({}, p.tokens)),
                    b.isEmptyObject(p.ruleData) || (r.ruleData = p.ruleData),
                    "click" === e && t && t[1] && (r.call_to_action = t[1]),
                    b.isEmptyObject(p.customData) || (s = p.customData),
                    ("open" === e ||
                      "abs_view" === e ||
                      "control_group" === e) &&
                      "undefined" != typeof webengage_fs_configurationMap &&
                      "array" === b.type(webengage_fs_configurationMap.goals))
                  )
                    for (
                      var c, l = 0;
                      l < webengage_fs_configurationMap.goals.length;
                      l++
                    )
                      "survey" === u
                        ? (c = webengage_fs_configurationMap.goals[l].sIds)
                        : "notification" === u &&
                          (c = webengage_fs_configurationMap.goals[l].nIds),
                        (c = c || []),
                        -1 !== b.indexOfArray(c, d) &&
                          ((r.goalIds = r.goalIds || []),
                          r.goalIds.push(
                            webengage_fs_configurationMap.goals[l].id
                          ));
                  ~["control_group", "abs_view"].indexOf(e) &&
                    ((s.bucket_value = g.bucketValue),
                    g.cg_id &&
                      ((s.cg_id = g.cg_id),
                      (r.attribution_type =
                        ((i = g.cg_id),
                        (o = Z.webengage_fs_configurationMap.cgDetails),
                        !!(a = o.UNIVERSAL[i] || o.CUSTOM[i]) &&
                          (a.name || "UNIVERSAL"))))),
                    "webPersonalization" === u
                      ? ((n = "web_personalization"),
                        (r.id = g.webPersonalizationEncId))
                      : "notificationInbox" === u &&
                        ((n = "inbox_notification"),
                        (r.experiment_id = g.experimentId),
                        (s.ict = g.creationTime),
                        (s.channel_type = g.channelType),
                        g.childExperimentId &&
                          ((r.experiment_id = g.childExperimentId),
                          (r.variation_id = g.childVariationId))),
                    f.publish("event.system", n + "_" + m[e], s, r);
                }
              }
              var e,
                t = s.instanceCallbacks;
              "webPersonalization" === u &&
                (t = [].concat(
                  (function (e) {
                    if (Array.isArray(e)) {
                      for (var t = 0, n = Array(e.length); t < e.length; t++)
                        n[t] = e[t];
                      return n;
                    }
                    return Array.from(e);
                  })(t),
                  ["render", "prepare"]
                )),
                "notificationInbox" === u &&
                  ((e = t).push.apply(e, ["read", "unread", "delete"]),
                  (m.read = "read"),
                  (m.unread = "unread"),
                  (m.delete = "delete")),
                (p.events = {});
              for (var n = 0; n < t.length; n++) {
                var a = t[n];
                p.events[a] = (function (n) {
                  return function () {
                    if (
                      (g.forcedRender ||
                        ("abs_view" === n || "control_group" === n
                          ? w.setEntity("open", u, p.scopedId || d, !0)
                          : w.setEntity(n, u, p.scopedId || d)),
                      "notificationInbox" !== u || g.status !== n.toUpperCase())
                    ) {
                      ("open" !== n && "maximize" !== n) ||
                        "notification" !== u ||
                        w.markAsNotMinimzed(u, p.scopedId || d);
                      var e = Array.prototype.slice.call(arguments);
                      e.splice(0, 0, p);
                      var t = u + "." + n;
                      d && (t += "." + d),
                        ("read" !== n && "unread" !== n) ||
                          (g.status = n.toUpperCase()),
                        o(n, e),
                        c.debug({
                          msg: (u + " " + n).toUpperCase(),
                          ctx: { id: g.instance.id, data: e },
                        }),
                        f.publish(t, i.methods.getCallbackData.apply(null, e));
                    }
                  };
                })(a);
              }
              p.id = d;
              var r = null;
              (p.reset = function () {
                (r = { show: !1, hide: !1, minimise: !1 }),
                  (p.show = function () {
                    r.show = !0;
                  }),
                  (p.hide = function () {
                    r.hide = !0;
                  }),
                  (p.minimize = function () {
                    r.minimize = !0;
                  }),
                  (p.getBuffer = function () {
                    return r;
                  });
              }),
                p.reset();
            };
          },
          {},
        ],
        "webengage/journey-cxr": [
          function (e, t, n) {
            "use strict";
            var o = e("webengage/properties"),
              a = e("webengage/util"),
              r = e("webengage/events"),
              s = e("webengage/state"),
              c = e("webengage/comm"),
              l = e("webengage/weq"),
              g = o.JOURNEY_CX_FETCH_INTERVAL,
              d = !1,
              u = null,
              p = null,
              i = [];
            function f() {
              var e, i;
              ((u = null), d) ||
                (!p || p + g <= new Date().getTime()
                  ? ((u = setTimeout(f, g)),
                    (e = s.getForever()),
                    (i = {
                      licenseCode: l.get("webengage.licenseCode"),
                      luid: e.luid,
                    }),
                    e.cuid && (i.cuid = e.cuid),
                    "undefined" != typeof webengage_fs_configurationMap &&
                      webengage_fs_configurationMap.upfc &&
                      ((i.upfc = a.compress.compressToBase64(
                        a.stringify(webengage_fs_configurationMap.upfc)
                      )),
                      c.jsonp(
                        a.addParamsToURL("https://c.webengage.com/jcx.js", i),
                        function (e) {
                          var t = s.getForever(),
                            n = s.getSession();
                          t.luid === i.luid &&
                            (e.journey &&
                              ((n.upf = n.upf || {}),
                              (n.upf.journey = a.transit.decode(e.journey)),
                              s.setSession(n)),
                            r.publish(o.CHANNEL_PROFILE_UPDATED),
                            (p = new Date().getTime()));
                        },
                        "jsonp"
                      )))
                  : (u = setTimeout(f, p + g - new Date().getTime())));
            }
            function b() {
              (d = !1), u && clearInterval(u), f();
            }
            function w() {
              d = !0;
            }
            function m() {
              r.unbind(Z, "blur", w), r.unbind(Z, "focus", b);
            }
            var h = {
              start: function () {
                m(), r.bind(Z, "blur", w), r.bind(Z, "focus", b), b();
              },
              stop: function (e) {
                m(), w(), e && (p = null), (i = []);
              },
              follow: function (e) {
                0 === i.length && h.start(),
                  -1 === a.indexOfArray(i, e) && i.push(e);
              },
              unfollow: function (e) {
                var t = a.indexOfArray(i, e);
                -1 !== t && i.splice(t, 1), 0 === i.length && h.stop();
              },
            };
            t.exports = h;
          },
          {},
        ],
        "webengage/load": [
          function (e, t, n) {
            "use strict";
            var a = e("webengage/properties"),
              o = e("webengage/ua"),
              i =
                (e("webengage/logger"),
                {
                  script: function (i, e) {
                    return function (n) {
                      var t = K.createElement("script");
                      (t.type = "text/javascript"),
                        (t.charset = "UTF-8"),
                        (t.async = !0),
                        (e =
                          e ||
                          a.widgetContainer ||
                          K.getElementsByTagName("body")[0]).appendChild(t),
                        o.ie && 8 === o.version
                          ? (t.onreadystatechange = function () {
                              var e = null;
                              "loaded" === t.readyState
                                ? ((t.onreadystatechange = null),
                                  clearTimeout(e),
                                  n())
                                : "complete" === t.readyState &&
                                  (e = setTimeout(function () {
                                    (t.onreadystatechange = null), n();
                                  }, 5e3));
                            })
                          : (t.onload = function () {
                              n();
                            }),
                        (t.onerror = function (e) {
                          var t = new Error("Failed to load script " + i);
                          (t.type = "error"), n(t);
                        }),
                        (t.src = i);
                    };
                  },
                  style: function (i, o) {
                    return function (t) {
                      var e = K.createElement("link");
                      (e.rel = "stylesheet"),
                        (o =
                          o ||
                          a.widgetContainer ||
                          K.getElementsByTagName("head")[0]).appendChild(e),
                        (e.href = i);
                      var n = K.createElement("img");
                      (n.onerror = function (e) {
                        t(null);
                      }),
                        (n.src = i);
                    };
                  },
                  module: function (t, n) {
                    try {
                      return (
                        X.require("webengage/" + t),
                        function (e) {
                          e();
                        }
                      );
                    } catch (e) {
                      return i.script(
                        n ||
                          ("http:" == location.protocol ? "http:" : "https:") +
                            "//ssl.widgets.webengage.com/js/" +
                            t +
                            ".js?v=277"
                      );
                    }
                  },
                });
            t.exports = i;
          },
          {},
        ],
        "webengage/logger": [
          function (e, t, n) {
            "use strict";
            var l = e("webengage/util/bare"),
              a = ["CRITICAL", "ERROR", "WARN", "INFO", "DEBUG"],
              g = {};
            function i() {}
            function o(e, t) {
              var n = Z.console,
                i = {
                  CRITICAL: ["FFFFFF", "FF0048"],
                  ERROR: ["FFFFFF", "FF0048"],
                  WARN: ["FFFFFF", "FF8A70"],
                  INFO: ["FFFFFF", "39D0F7"],
                  DEBUG: ["000000", "CCCCCC"],
                }[e];
              if (n && n.log && n.log) {
                var o = t.msg,
                  a = t.ctx || "";
                a && a.error instanceof Error && (a = a.error);
                var r = !!Z.StyleMedia,
                  s = !!Z.opera;
                r || s || (!n.table && !n.firebug)
                  ? n.log("WebEngage [" + e + "] ", o, a)
                  : n.log(
                      "%cWebEngage%c %c" + e,
                      "color: #FFFFFF; background-color: #533370; padding: 2px 4px 1px 4px; border-radius: 2px",
                      "",
                      "color: #" +
                        i[0] +
                        "; background-color: #" +
                        i[1] +
                        "; padding: 2px 4px 1px 4px; border-radius: 2px",
                      "",
                      o,
                      a
                    );
              }
            }
            function r(e, t, n) {
              var i = g[e];
              if (i && i.length) {
                var o;
                try {
                  throw new Error();
                } catch (e) {
                  var a,
                    r = /(.*)@|at?(.*)\(/g,
                    s = e.stack;
                  r.exec(s),
                    (o = ((a = r.exec(s)) && (a[1] || a[2])) || "unknown");
                }
                "object" !== l.type(t) &&
                  (t = { msg: String(t), ctx: n || null }),
                  (t.caller = o);
                for (var c = 0; c < i.length; c++) i[c].call(null, e, t);
              }
            }
            function s(e, t) {
              for (var n = 0; n < e.length; n++) if (t === e[n]) return n;
              return -1;
            }
            function c(e, t) {
              if (e && "function" == typeof t) {
                e = e.toUpperCase();
                for (var n = s(a, e), i = 0; i <= n; i++) {
                  var o = a[i];
                  g.hasOwnProperty(o) ||
                    ((g[o] = []), (d[o.toLowerCase()] = l.curry(r, o))),
                    -1 === s(g[o], t) && g[o].push(t);
                }
              }
            }
            var d = {
              critical: i,
              error: i,
              warn: i,
              info: i,
              debug: i,
              init: function (e) {
                c(e, o);
              },
              subscribe: c,
            };
            t.exports = d;
          },
          {},
        ],
        "webengage/mappings": [
          function (e, t, n) {
            "use strict";
            t.exports = {
              USER_SYSTEM_ATTRIBUTES: {
                we_email: "email",
                we_birth_date: "birth_date",
                we_phone: "phone",
                we_gender: "gender",
                we_first_name: "first_name",
                we_last_name: "last_name",
                we_hashed_email: "hashed_email",
                we_hashed_phone: "hashed_phone",
                we_email_opt_in: "email_opt_in",
                we_sms_opt_in: "sms_opt_in",
                we_whatsapp_opt_in: "whatsapp_opt_in",
                we_company: "company",
                we_locality: "locality",
                we_best_channel: "best_channel",
              },
              RESTRICTED_USER_SYS_ATTR: { we_best_channel: 1 },
              USER_GEO_ATTRIBUTES: {
                country: "we_country",
                region: "we_region",
                city: "we_city",
              },
              ACQUISITION_PROPS: {
                landing_page: "lp",
                referrer_url: "rf",
                referrer_host: "rfh",
                referrer_type: "type",
                referrer_query: "query",
                referrer_link: "link",
                referrer_network: "network",
                campaign_id: "id",
                campaign_source: "source",
                campaign_medium: "medium",
                campaign_term: "term",
                campaign_gclid: "gclid",
              },
              UA_BROWSER_TRANSLATIONS: {
                "Opera Mini": "Opera",
                "Opera Mobi": "Opera",
                "Opera Tablet": "Opera",
                "Mobile Safari": "Safari",
                IE: "Explorer",
                IEMobile: "Explorer",
              },
              UA_OS_TRANSLATIONS: {
                "Windows Mobile": "Windows Phone",
                "Mac OS": "Mac",
              },
              UA_DEVICE_TRANSLATIONS: {
                mobile: "Mobile",
                tablet: "Tablet",
                desktop: "Desktop",
              },
            };
          },
          {},
        ],
        "webengage/morpheus": [
          function (e, t, n) {
            "use strict";
            t.exports = (function () {
              var o = K,
                t = Z,
                e = t.performance,
                n = e && (e.now || e.webkitNow || e.msNow || e.mozNow),
                f = n
                  ? function () {
                      return n.call(e);
                    }
                  : function () {
                      return +new Date();
                    },
                i = !1,
                a = o.documentElement,
                b = 1e3,
                x = /^rgb\(|#/,
                r = /^([+\-])=([\d\.]+)/,
                E = /^(?:[\+\-]=?)?\d+(?:\.\d+)?(%|in|cm|mm|em|ex|pt|pc|px)$/,
                s = /rotate\(((?:[+\-]=)?([\-\d\.]+))deg\)/,
                c = /scale\(((?:[+\-]=)?([\d\.]+))\)/,
                l =
                  /skew\(((?:[+\-]=)?([\-\d\.]+))deg, ?((?:[+\-]=)?([\-\d\.]+))deg\)/,
                g =
                  /translate\(((?:[+\-]=)?([\-\d\.]+))px, ?((?:[+\-]=)?([\-\d\.]+))px\)/,
                d = {
                  lineHeight: 1,
                  zoom: 1,
                  zIndex: 1,
                  opacity: 1,
                  transform: 1,
                },
                _ = (function () {
                  var e,
                    t = o.createElement("a").style,
                    n = [
                      "webkitTransform",
                      "MozTransform",
                      "OTransform",
                      "msTransform",
                      "Transform",
                    ];
                  for (e = 0; e < n.length; e++) if (n[e] in t) return n[e];
                })(),
                S = void 0 !== o.createElement("a").style.opacity,
                C =
                  o.defaultView && o.defaultView.getComputedStyle
                    ? function (e, t) {
                        t = A((t = "transform" == t ? _ : t));
                        var n = null,
                          i = o.defaultView.getComputedStyle(e, "");
                        return i && (n = i[t]), e.style[t] || n;
                      }
                    : a.currentStyle
                    ? function (t, e) {
                        if ("opacity" == (e = A(e))) {
                          var n = 100;
                          try {
                            n =
                              t.filters["DXImageTransform.Microsoft.Alpha"]
                                .opacity;
                          } catch (e) {
                            try {
                              n = t.filters("alpha").opacity;
                            } catch (e) {}
                          }
                          return n / 100;
                        }
                        var i = t.currentStyle ? t.currentStyle[e] : null;
                        return t.style[e] || i;
                      }
                    : function (e, t) {
                        return e.style[A(t)];
                      },
                w =
                  t.requestAnimationFrame ||
                  t.webkitRequestAnimationFrame ||
                  t.mozRequestAnimationFrame ||
                  t.msRequestAnimationFrame ||
                  t.oRequestAnimationFrame ||
                  function (e) {
                    t.setTimeout(function () {
                      e(+new Date());
                    }, 17);
                  };
              w(function (e) {
                i = 1e12 < e != 1e12 < f();
              });
              var m = [];
              function h(e) {
                var t,
                  n = m.length;
                for (i && (e = f()), t = n; t--; ) m[t](e);
                m.length && w(h);
              }
              function v(e) {
                var t,
                  n = (function (e, t, n) {
                    if (Array.prototype.indexOf) return e.indexOf(t);
                    for (n = 0; n < e.length; ++n) if (e[n] === t) return n;
                  })(m, e);
                0 <= n &&
                  ((t = m.slice(n + 1)), (m.length = n), (m = m.concat(t)));
              }
              function I(e, t) {
                var n,
                  i = {};
                return (
                  (n = e.match(s)) && (i.rotate = R(n[1], t ? t.rotate : null)),
                  (n = e.match(c)) && (i.scale = R(n[1], t ? t.scale : null)),
                  (n = e.match(l)) &&
                    ((i.skewx = R(n[1], t ? t.skewx : null)),
                    (i.skewy = R(n[3], t ? t.skewy : null))),
                  (n = e.match(g)) &&
                    ((i.translatex = R(n[1], t ? t.translatex : null)),
                    (i.translatey = R(n[3], t ? t.translatey : null))),
                  i
                );
              }
              function T(e) {
                var t = "";
                return (
                  "rotate" in e && (t += "rotate(" + e.rotate + "deg) "),
                  "scale" in e && (t += "scale(" + e.scale + ") "),
                  "translatex" in e &&
                    (t +=
                      "translate(" +
                      e.translatex +
                      "px," +
                      e.translatey +
                      "px) "),
                  "skewx" in e &&
                    (t += "skew(" + e.skewx + "deg," + e.skewy + "deg)"),
                  t
                );
              }
              function k(e) {
                var t,
                  n,
                  i,
                  o = e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
                return (
                  o
                    ? ((t = o[1]),
                      (n = o[2]),
                      (i = o[3]),
                      "#" +
                        ((1 << 24) | (t << 16) | (n << 8) | i)
                          .toString(16)
                          .slice(1))
                    : e
                ).replace(/#(\w)(\w)(\w)$/, "#$1$1$2$2$3$3");
              }
              function A(e) {
                return e.replace(/-(.)/g, function (e, t) {
                  return t.toUpperCase();
                });
              }
              function O(e) {
                return "function" == typeof e;
              }
              function y(e) {
                return Math.sin((e * Math.PI) / 2);
              }
              function N(e, i, o, a, r, s) {
                a = O(a) ? a : L.easings[a] || y;
                var t,
                  c = e || b,
                  l = this,
                  g = s - r,
                  d = f(),
                  u = 0,
                  p = 0;
                return (
                  (t = function e(t) {
                    var n = t - d;
                    if (c < n || u)
                      return (
                        (s = isFinite(s) ? s : 1),
                        u ? p && i(s) : i(s),
                        v(e),
                        o && o.apply(l)
                      );
                    isFinite(s) ? i(g * a(n / c) + r) : i(a(n / c));
                  }),
                  1 === m.push(t) && w(h),
                  {
                    stop: function (e) {
                      (u = 1), (p = e) || (o = null);
                    },
                  }
                );
              }
              function P(e, t) {
                var n,
                  i,
                  o = e.length,
                  a = [];
                for (n = 0; n < o; ++n) a[n] = [e[n][0], e[n][1]];
                for (i = 1; i < o; ++i)
                  for (n = 0; n < o - i; ++n)
                    (a[n][0] =
                      (1 - t) * a[n][0] + t * a[parseInt(n + 1, 10)][0]),
                      (a[n][1] =
                        (1 - t) * a[n][1] + t * a[parseInt(n + 1, 10)][1]);
                return [a[0][0], a[0][1]];
              }
              function D(e, t, n, i, o, a, r) {
                if ("transform" != o)
                  return "string" == typeof n[a][o]
                    ? (function (e, t, n) {
                        var i,
                          o,
                          a,
                          r,
                          s = [];
                        for (i = 0; i < 6; i++)
                          (a = Math.min(15, parseInt(t.charAt(i), 16))),
                            (r = Math.min(15, parseInt(n.charAt(i), 16))),
                            (o =
                              15 < (o = Math.floor((r - a) * e + a))
                                ? 15
                                : o < 0
                                ? 0
                                : o),
                            (s[i] = o.toString(16));
                        return "#" + s.join("");
                      })(e, n[a][o], i[a][o])
                    : ((r =
                        Math.round(((i[a][o] - n[a][o]) * e + n[a][o]) * b) /
                        b),
                      o in d || (r += t[a][o] || "px"),
                      r);
                for (var s in ((r = {}), n[a][o]))
                  r[s] =
                    s in i[a][o]
                      ? Math.round(
                          ((i[a][o][s] - n[a][o][s]) * e + n[a][o][s]) * b
                        ) / b
                      : n[a][o][s];
                return r;
              }
              function R(e, t, n, i, o) {
                return (n = r.exec(e))
                  ? (o = parseFloat(n[2])) && t + ("+" == n[1] ? 1 : -1) * o
                  : parseFloat(e);
              }
              function L(e, o) {
                var a,
                  t,
                  n,
                  r = e ? (r = isFinite(e.length) ? e : [e]) : [],
                  i = o.complete,
                  s = o.duration,
                  c = o.easing,
                  l = o.bezier,
                  g = [],
                  d = [],
                  u = [],
                  p = [];
                for (
                  l &&
                    ((t = o.left),
                    (n = o.top),
                    delete o.right,
                    delete o.bottom,
                    delete o.left,
                    delete o.top),
                    a = r.length;
                  a--;

                ) {
                  if (((g[a] = {}), (d[a] = {}), (u[a] = {}), l)) {
                    var f = C(r[a], "left"),
                      b = C(r[a], "top"),
                      w = [
                        R(O(t) ? t(r[a]) : t || 0, parseFloat(f)),
                        R(O(n) ? n(r[a]) : n || 0, parseFloat(b)),
                      ];
                    (p[a] = O(l) ? l(r[a], w) : l),
                      p[a].push(w),
                      p[a].unshift([parseInt(f, 10), parseInt(b, 10)]);
                  }
                  for (var m in o) {
                    switch (m) {
                      case "complete":
                      case "duration":
                      case "easing":
                      case "bezier":
                        continue;
                    }
                    var h,
                      v = C(r[a], m),
                      y = O(o[m]) ? o[m](r[a]) : o[m];
                    "string" != typeof y || !x.test(y) || x.test(v)
                      ? ((g[a][m] =
                          "transform" == m
                            ? I(v)
                            : "string" == typeof y && x.test(y)
                            ? k(v).slice(1)
                            : parseFloat(v)),
                        (d[a][m] =
                          "transform" == m
                            ? I(y, g[a][m])
                            : "string" == typeof y && "#" == y.charAt(0)
                            ? k(y).slice(1)
                            : R(y, parseFloat(v))),
                        "string" == typeof y &&
                          (h = y.match(E)) &&
                          (u[a][m] = h[1]))
                      : delete o[m];
                  }
                }
                return N.apply(r, [
                  s,
                  function (e, t, n) {
                    for (a = r.length; a--; )
                      for (var i in (l &&
                        ((n = P(p[a], e)),
                        (r[a].style.left = n[0] + "px"),
                        (r[a].style.top = n[1] + "px")),
                      o))
                        (t = D(e, u, g, d, i, a)),
                          "transform" == i
                            ? (r[a].style[_] = T(t))
                            : "opacity" != i || S
                            ? (r[a].style[A(i)] = t)
                            : (r[a].style.filter =
                                "alpha(opacity=" + 100 * t + ")");
                  },
                  i,
                  c,
                ]);
              }
              return (
                (L.tween = N),
                (L.getStyle = C),
                (L.bezier = P),
                (L.transform = _),
                (L.parseTransform = I),
                (L.formatTransform = T),
                (L.animationFrame = w),
                (L.easings = {}),
                L
              );
            })();
          },
          {},
        ],
        "webengage/notification-inbox": [
          function (e, t, n) {
            "use strict";
            var s = e("webengage/logger"),
              c = e("webengage/engagement"),
              l = e("webengage/util"),
              g = e("webengage/comm"),
              o = e("webengage/events"),
              d = e("webengage/weq"),
              u = e("webengage/state"),
              a = e("webengage/properties");
            function i(t, e, n) {
              s.debug({ msg: "Notification Inbox Init", ctx: { data: t } }),
                (function (e, t, n) {
                  function i(e) {
                    (e =
                      e && e.response && e.response.data
                        ? e.response.data
                        : []),
                      n(e);
                  }
                  s.debug({
                    msg: "Notification Inbox getNotificationInboxEntites",
                    ctx: { lc: e },
                  });
                  var o = u.getForever(),
                    a = {};
                  o.cuid ? (a.uid = o.cuid) : (a.uid = o.luid);
                  var r =
                    "https://c.webengage.com:443/inbox/v1/getAllNotifications/" +
                    e +
                    "/" +
                    a.uid;
                  t && Object.keys(t).length && (r += "?to=" + t.creationTime);
                  try {
                    g.xhr(r, null, function (e) {
                      i(l.parseJSON(e));
                    });
                  } catch (e) {
                    (a.c = ""), g.jsonp(l.addParamsToURL(r, a), i, "p");
                  }
                })(t, e, function (e) {
                  (webengage_fs_configurationMap.notificationInboxRuleList =
                    e.messages),
                    X.notificationInbox.init(t, webengage_fs_configurationMap),
                    n();
                });
            }
            function r(e, t, n, i, o) {
              var a,
                r = {};
              return (
                (r.activity = c.util.getActivity()),
                e.data &&
                  (l.copy(r, {
                    notificationInboxId: (a = e).id,
                    licenseCode: d.get("webengage.licenseCode"),
                    propertyType: a.data.layoutAttributes.dom_id.type,
                    propertyName:
                      a.data.layoutAttributes.dom_id.xpathVariableName,
                    propertyValue: a.data.layoutAttributes.dom_id.value,
                    operation: a.data.layoutAttributes.dom_id.op,
                  }),
                  (r.isNotificationClickable = !(
                    !e.data.actions || !e.data.actions.length
                  ))),
                t && (r.actionId = t),
                n && (r.actionLink = n),
                i && (r.primeAction = !0),
                (r.actionTarget = o || "_self"),
                r
              );
            }
            function p(e) {
              var t = a.instanceCallbacks;
              if (
                (t.push.apply(t, ["read", "unread", "delete"]),
                e && e.instance && e.instance.id)
              )
                for (var n = 0; n < t.length; n++) {
                  var i = t[n];
                  o.desubscribe("notificationInbox." + i + "." + e.instance.id);
                }
            }
            function f(e) {
              var t;
              s.debug({ msg: "Notification Inbox Clear" }),
                (t = e) &&
                  t.length &&
                  l.mapArray(t, function (e) {
                    p(e);
                  });
            }
            function b(e) {
              s.debug({ msg: "Notification Inbox ClearEntity" }), p(e);
            }
            t.exports = function () {
              var e = new c("notificationInbox", {
                methods: {
                  clear: f,
                  clearEntity: b,
                  getCallbackData: r,
                  notificationInboxInit: i,
                },
              });
              return s.debug({ msg: "NOTIFICATION INBOX INIT" }), e;
            };
          },
          {},
        ],
        "webengage/notification-prep": [
          function (a, e, t) {
            "use strict";
            var y = a("webengage/util/bare"),
              r = a("webengage/dom"),
              f = a("webengage/events"),
              s = a("webengage/load"),
              b = a("webengage/logger"),
              x = a("webengage/util/sha1"),
              c = X.require("webengage/ua");
            function l(o, h, e) {
              var a = h.parentDom || v,
                v = h.dom;
              function s(e, t) {
                switch (e) {
                  case "_container":
                    return t + "-notification-container";
                  case "_formContainer":
                    return t + "-notification-form-container";
                  case "_form":
                    return t + "-notification-form";
                  case "_close":
                    return t + "-notification-close-div";
                  case "_minimize":
                    return t + "-notification-minimize-div";
                }
              }
              function c(e, t) {
                var n = !1;
                if (t && t.length)
                  for (var i = 0; i < t.length; i++) {
                    var o = t[i];
                    if (o.actionEId === e && o.isPrime) {
                      n = !0;
                      break;
                    }
                  }
                return n;
              }
              function r(e, t, n) {
                var i =
                    t.containerId || "webklipper-publisher-widget-container",
                  o = (function (e, t) {
                    for (
                      var n = [
                          "_container",
                          "_formContainer",
                          "_close",
                          "_form",
                          "_minimize",
                        ],
                        i = 0;
                      i < n.length;
                      i++
                    )
                      e[n[i]] = s(n[i], t);
                    return e;
                  })(t.data, i);
                o.layoutId = t.layoutId;
                var a = e.getMarkUp(o),
                  r = v.createElement("div", a);
                v.addClass(r, "prime"),
                  (function (e, t) {
                    if (
                      ((t.actionMap = {}),
                      t.actions && y.isArray(t.actions) && 0 < t.actions.length)
                    )
                      for (var n = 0; n < t.actions.length; n++) {
                        var i = t.actions[n],
                          o =
                            ((s = i.actionLink),
                            (c = '<a href="' + s + '"></a>'),
                            (l = v.createElement("div", c)),
                            (g = v.queryOne("a", l)),
                            y.trim(g.href));
                        if (i.actionText) var a = y.trim(i.actionText);
                        (t.actionMap[o + "-" + a] = {
                          actionEId: i.actionEId,
                          actionTarget: i.actionTarget,
                        }),
                          (t.actionsTarget = i.actionTarget);
                        var r = v.queryOne(
                          '[data-action-id="' + i.actionEId + '"]',
                          e
                        );
                        r &&
                          (r.setAttribute("data-action-link", o),
                          r.setAttribute("data-action-target", i.actionTarget),
                          r.setAttribute("data-action-is-prime", "true"));
                      }
                    var s,
                      c,
                      l,
                      g,
                      d = v.query(".description a", e),
                      u = void 0 !== h ? h.osName.toLowerCase() : $;
                    if (d && 0 < d.length)
                      for (var p = 0; p < d.length; p++) {
                        var f = d[p].href,
                          b = d[p].innerHTML,
                          w = t.actionMap[f + "-" + b];
                        if (
                          "android" === u &&
                          h &&
                          [
                            "1af576b9",
                            "1af576b9-ls",
                            "6ic376a",
                            "6ic376a-ls",
                          ].includes(h.layoutId)
                        ) {
                          var m =
                            "w://p/open_url_in_browser/" +
                            encodeURIComponent(f);
                          (d[p].href = m),
                            (w = t.actionMap[m + "-" + b]) ||
                              "/" !== f[f.length - 1] ||
                              ((m =
                                "w://p/open_url_in_browser/" +
                                encodeURIComponent(f.slice(0, -1))),
                              (w = t.actionMap[m + "-" + b]));
                        }
                        w || ((w = {}).actionEId = x(f)),
                          w &&
                            w.actionEId &&
                            d[p].setAttribute("data-action-id", w.actionEId);
                      }
                  })(r, o),
                  n.appendChild(r);
              }
              function l(e, t, n) {
                var i = t.data,
                  o = e.getStyles(i);
                v.css.createStyleNode(o, { id: "dynamicStyles" }, n);
              }
              var t,
                n,
                i = h.layoutId,
                g = o.layout[i],
                d = v.queryOne("body"),
                u = v.queryOne("head");
              function p() {
                var e = g.selector.wrapper
                    ? v.queryOne(g.selector.wrapper)
                    : v.queryOne(".wrapper"),
                  n = g.selector.close || ".close",
                  i = g.selector.minimize || ".minimize",
                  o = g.selector.maximize || ".maximize";
                f.bind(e, "click", function (e) {
                  if (h.opened) {
                    var t = e.target || e.srcElement;
                    switch (!0) {
                      case v.contains(v.queryOne(n), t):
                      case v.contains(v.queryOne(".modal-backdrop"), t):
                        h.closed ||
                          (b.debug({
                            msg: "CLICKED CLOSE BUTTON OF NOTIFICATION",
                            ctx: { selector: g.selector, target: t },
                          }),
                          h.hide(),
                          h.events && h.events.close(),
                          "function" == typeof h.close && h.close(),
                          (h.closed = !0));
                        break;
                      case v.contains(v.queryOne(i), t):
                        b.debug({
                          msg: "CLICKED MINIMIZE BUTTON OF NOTIFICATION",
                          ctx: { selector: g.selector, target: t },
                        }),
                          h.minimize(),
                          h.events && h.events.minimize();
                        break;
                      case v.contains(v.queryOne(o), t):
                        b.debug({
                          msg: "CLICKED MAXIMIZE BUTTON OF NOTIFICATION",
                          ctx: { selector: g.selector, target: t },
                        }),
                          h.maximize();
                    }
                  }
                });
                var t = v.query("[data-action-id]");
                if (t && t.length)
                  for (var a = 0; a < t.length; a++) {
                    !(function (r) {
                      f.bind(r, "click", function (e) {
                        if (
                          (e.preventDefault
                            ? e.preventDefault()
                            : (e.returnValue = !1),
                          h.opened)
                        ) {
                          h.hide();
                          var t,
                            n,
                            i = r.getAttribute("data-action-id"),
                            o = r.tagName,
                            a = c(i, h.data.actions);
                          (n =
                            "A" === o
                              ? ((t = r.getAttribute("href")),
                                r.getAttribute("target") || "_top")
                              : ((t = r.getAttribute("data-action-link")),
                                r.getAttribute("data-action-target"))),
                            "function" == typeof h.click && h.click(i, t, a),
                            h.events && h.events.click(i, t, a, n);
                        }
                      });
                    })(t[a]);
                  }
              }
              b.debug({
                msg: "STARTING TO CREATE A " + i + " LAYOUT NOTIFICATION",
              }),
                (t = u),
                (n = g.getStaticStyles()),
                v.css.createStyleNode(n, { id: "staticStyles" }, t),
                l(g, h, u),
                r(g, h, d),
                p(),
                (!f.happened("ready") &&
                  X.getLicenseCode &&
                  "aa131c7a" == X.getLicenseCode()) ||
                  (b.debug({ msg: "NOTIFICATION INIT" }),
                  g.init(h, function t() {
                    if (
                      ((h.tempFrameStyle = {}),
                      !h.opened && h && h.frame && h.frame.style)
                    )
                      for (
                        var e = ["left", "top", "right", "bottom"], n = 0;
                        n < 4;
                        n++
                      )
                        h.tempFrameStyle[e[n]] =
                          h.frame.style["we_" + e[n]] !== $
                            ? h.frame.style["we_" + e[n]]
                            : "auto";
                    b.debug({ msg: "NOTIFICATION INIT CALLBACK" });
                    try {
                      var i = h.getBuffer();
                      (h.show = function () {
                        var e, t, n, i, o;
                        b.debug({ msg: "ENTERED NOTIFICATION SHOW METHOD" }),
                          h.opened ||
                            (v.css.applyCss(
                              h.frame,
                              ((e = h.frame),
                              (t = h.tempFrameStyle),
                              (i = n = void 0),
                              (o = {}),
                              t.left === $ ||
                                "auto" === t.left ||
                                n ||
                                (n = parseInt(t.left, 10) - e.offsetLeft),
                              t.right === $ ||
                                "auto" === t.right ||
                                n ||
                                (n =
                                  v.css.getWindowWidth() -
                                  (v.css.getElementWidth(e) +
                                    parseInt(t.right, 10)) -
                                  e.offsetLeft),
                              t.top === $ ||
                                "auto" === t.top ||
                                i ||
                                (i = parseInt(t.top, 10) - e.offsetTop),
                              t.bottom === $ ||
                                "auto" === t.bottom ||
                                i ||
                                (i =
                                  v.css.getWindowHeight() -
                                  (v.css.getElementHeight(e) +
                                    parseInt(t.bottom, 10)) -
                                  e.offsetTop),
                              n && i && "number" == typeof (n + i)
                                ? ((o.transform =
                                    "translate(" + n + "px," + i + "px)"),
                                  (o["-webkit-transform"] =
                                    "translate(" + n + "px," + i + "px)"),
                                  (o["-moz-transform"] =
                                    "translate(" + n + "px," + i + "px)"),
                                  (o["-ms-transform"] =
                                    "translate(" + n + "px," + i + "px)"),
                                  (o["-o-transform"] =
                                    "translate(" + n + "px," + i + "px)"),
                                  o)
                                : t)
                            ),
                            g.show(v.getDoc(), h),
                            h.events &&
                              "function" == typeof h.events.open &&
                              h.events.open(),
                            "function" == typeof h.open && h.open(),
                            (h.opened = !0));
                      }),
                        (h.hide = function () {
                          b.debug({ msg: "ENTERED NOTIFICATION HIDE METHOD" }),
                            g.hide(v.getDoc(), h, function () {
                              h.frame && a.iframe.remove(h.frame);
                            });
                        }),
                        (h.clear = function () {
                          b.debug({ msg: "ENTERED NOTIFICATION CLEAR METHOD" }),
                            g.clear && g.clear(h);
                        }),
                        (h.minimize = function () {
                          h.opened ||
                            (v.css.applyCss(h.frame, h.tempFrameStyle),
                            (h.opened = !0)),
                            b.debug({
                              msg: "ENTERED NOTIFICATION MINIMIZE METHOD",
                            }),
                            g.minimize(v.getDoc(), h);
                        }),
                        (h.maximize = function () {
                          b.debug({
                            msg: "ENTERED NOTIFICATION MAXIMIZE METHOD",
                          }),
                            g.maximize(v.getDoc(), h),
                            h.opened
                              ? h.events && h.events.maximize()
                              : h.events && h.events.open();
                        }),
                        (h.updateStyles = function () {
                          b.debug({ msg: "UPDATED STYLES OF NOTIFICATION" });
                          var e = h.layoutId,
                            t = o.layout[e],
                            n = v.queryOne("head"),
                            i = v.queryOne("#dynamicStyles");
                          v.remove(i), l(t, h, n);
                        }),
                        (h.updateMarkup = function () {
                          b.debug({ msg: "UPDATED MARKUP OF NOTIFICATION" });
                          var e = v.queryOne("body > div"),
                            t = v.queryOne("body");
                          v.remove(e), r(g, h, t), p();
                        }),
                        (h.updatePosition = function () {
                          b.debug({ msg: "UPDATED POSITION OF NOTIFICATION" });
                          var e = v.queryOne("#computedStyles");
                          e && v.remove(e),
                            h.updateStyles(h),
                            h.updateMarkup(h),
                            "function" == typeof g.update
                              ? g.update(h, function () {})
                              : g.init(h, function () {
                                  t(), (h.opened = !1), h.show();
                                });
                        }),
                        i.show && h.show(),
                        i.close && h.hide(),
                        i.minimize && h.minimize(),
                        i.maximize && h.maximize();
                    } catch (e) {
                      h && h.error && h.error(e.stack);
                    }
                  }));
            }
            e.exports = function (t) {
              try {
                X.notification.layout = X.notification.layout || {};
                var n = Z.webengage.notification;
                if (
                  (t.parentDom || (t.parentDom = r),
                  t.dom || (t.dom = r),
                  t.osName || (t.osName = c.os),
                  "function" != typeof t.getBuffer)
                ) {
                  var e = { show: !1, hide: !1, minimise: !1 };
                  (t.show = function () {
                    e.show = !0;
                  }),
                    (t.hide = function () {
                      e.hide = !0;
                    }),
                    (t.minimize = function () {
                      e.minimize = !0;
                    }),
                    (t.getBuffer = function () {
                      return e;
                    });
                }
                !0 === t.data.layoutAttributes.allowLandscape &&
                  !1 === t.data.layoutAttributes.allowPortrait &&
                  (t.layoutId = t.layoutId + "-ls");
                var i = t.layoutId,
                  o = t.baseURL + "js/notification-layout-" + i + ".js";
                if (X.notification.layout && X.notification.layout[i]) {
                  if (
                    !f.happened("ready") &&
                    X.getLicenseCode &&
                    "aa131c7a" == X.getLicenseCode()
                  )
                    return;
                  l(n, t);
                } else
                  s.script(o)(function (e) {
                    try {
                      if (e) throw e;
                      if (
                        !f.happened("ready") &&
                        X.getLicenseCode &&
                        "aa131c7a" == X.getLicenseCode()
                      )
                        return;
                      (X.notification.layout[i] = a(
                        "webengage/notification-layouts/notification-layout-" +
                          i
                      )),
                        l(n, t);
                    } catch (e) {
                      f.publish("error", e), t.error && t.error(e.stack);
                    }
                  });
                return t;
              } catch (e) {
                t.error && t.error(e.stack);
              }
            };
          },
          {},
        ],
        "webengage/notification": [
          function (m, e, t) {
            "use strict";
            var c = m("webengage/dom"),
              l = m("webengage/engagement"),
              i = m("webengage/events"),
              g = m("webengage/properties"),
              d = m("webengage/notification-prep"),
              h = m("webengage/comm"),
              v = m("webengage/state"),
              y = m("webengage/weq"),
              x = (m("webengage/ua"), m("webengage/util")),
              E = m("webengage/logger"),
              _ = "webklipper-publisher-widget-container-notification-frame",
              u = "webengage-notification-container";
            function n(o, e, a) {
              var r = o.instance;
              (r.layoutId = o.layout),
                (r.baseURL =
                  ("http:" == location.protocol ? "http:" : "https:") +
                  "//ssl.widgets.webengage.com/"),
                (r.appHost = "webengage.com");
              var t = c.queryOne("#" + u);
              t ||
                (((t = c.createElement("div", "")).id = u),
                g.widgetContainer.appendChild(t));
              var n = c.iframe.create({
                name: "notification-frame-" + o.instance.id,
                frameContainer: t,
                css: {
                  display: "block",
                  position: "fixed",
                  "z-index": "-9999999",
                  left: "-1000px",
                  top: "-1000px",
                },
                onload: function (e) {
                  r.frame = e;
                  var t = c.iframe.getDoc(e);
                  t.write(
                    "<!DOCTYPE html><html><head></head><body></body></html>"
                  ),
                    t.close(),
                    (r.dom = c.doc(t)),
                    (r.parentDom = c);
                  var n = r.dom.queryOne("head"),
                    i = r.dom.createElement("base");
                  (i.href = K.baseURI),
                    n.appendChild(i),
                    d(r),
                    E.debug({
                      msg: "NOTIFICATION PREPARED",
                      ctx: { id: o.instance.id, entity: o, config: a },
                    });
                },
              });
              function s(e, t) {
                if (
                  (t
                    ? E.warn({
                        msg: "NOTIFICATION TRACK CLICK - TIMEOUT",
                        ctx: { id: o.instance.id, data: e },
                      })
                    : E.debug({
                        msg: "NOTIFICATION TRACK CLICK",
                        ctx: { id: o.instance.id, data: e },
                      }),
                  !x.isEmptyObject(e))
                ) {
                  var n = e.actionTarget,
                    i = e.actionLink;
                  "_blank" !== n && (Z.location.href = i);
                }
              }
              return (
                n.setAttribute(
                  "data-notification-layout-id",
                  o.instance.layoutId
                ),
                n.setAttribute(
                  "data-notification-layout-name",
                  {
                    i78egag: "banner",
                    "~20cc49c3": "box",
                    "2341ifc8": "callout",
                    i78egaf: "classic",
                    "~184fc0b7": "modal",
                    "1af576bc": "footer-mobile",
                    "2341ifc7": "footer-desktop",
                    "~fg00aab": "header-mobile",
                    "1af576bb": "header-desktop",
                  }[o.instance.layoutId]
                ),
                (r.frame = n),
                i.subscribe("notification.open." + o.instance.id, function (e) {
                  !(function (e) {
                    var t = v.getTotalViewsAcrossScope(
                      "notification",
                      e.notificationId
                    );
                    0 < t ? (t -= 1) : (t = 0);
                    var n = x.addParamsToURL(
                      ("http:" == location.protocol ? "http:" : "https:") +
                        "//notification.webengage.com/json/notification.html",
                      {
                        notificationEId: e.notificationId,
                        action: "track",
                        timesShown: t,
                        licenseCode: y.get("webengage.licenseCode"),
                        luid: X.state.getForever().luid,
                        cuid: X.state.getForever().cuid,
                      }
                    );
                    h.jsonp(n, function () {
                      E.debug({
                        msg: "NOTIFICATION TRACK VIEW",
                        ctx: { id: e.notificationId, url: n },
                      });
                    });
                  })(e);
                }),
                i.subscribe(
                  "notification.click." + o.instance.id,
                  function (e) {
                    var t = e.actionTarget,
                      n = e.actionLink,
                      i = v.getForever(),
                      o = {
                        country: x.ensureString(e.activity.country),
                        region: x.ensureString(e.activity.region),
                        city: x.ensureString(e.activity.city),
                        browser: x.ensureString(e.activity.browser),
                        version: String(e.activity.browserVersion),
                        platform: x.ensureString(e.activity.platform),
                        pageUrl: Z.location.href,
                        referer: Z.document.referrer,
                        notificationEId: x.ensureString(e.notificationId),
                        notificationActionEId: x.ensureString(e.actionId),
                        licenseCode: x.ensureString(e.licenseCode),
                        widgetVersion: "5",
                        timesShown: v.getTimesShown(
                          "notification",
                          e.notificationEId
                        ),
                        luid: i.luid,
                        pageTitle: K.title,
                      };
                    i.cuid && (o.cuid = i.cuid),
                      x.isEmptyObject(r.customData) ||
                        (o.clientDataString = l.util.getClientDataString(
                          r.customData
                        )),
                      !0 === y.get("webengage.aip") && (o.aip = 1);
                    var a = setTimeout(function () {
                      s(e, !(a = null));
                    }, 5e3);
                    h.xhr(
                      ("http:" == location.protocol ? "http:" : "https:") +
                        "//notification.webengage.com/json/notification.html?action=save",
                      o,
                      function () {
                        a && (clearTimeout(a), s(e));
                      }
                    ),
                      "_blank" === t && Z.open(n, t);
                  }
                ),
                o
              );
            }
            function o(e, t, n, i, o) {
              var a,
                r = {};
              return (
                (r.activity = l.util.getActivity()),
                e.data &&
                  (x.copy(r, {
                    notificationId: (a = e).id,
                    licenseCode: y.get("webengage.licenseCode"),
                    title: a.data.title,
                  }),
                  (r.isNotificationClickable = !(
                    !e.data.actions || !e.data.actions.length
                  ))),
                t && (r.actionId = t),
                n && (r.actionLink = n),
                i && (r.primeAction = !0),
                (r.actionTarget = o || "_top"),
                r
              );
            }
            function a(n, i, o) {
              var a = n.notificationEncId;
              n.v;
              function t(e) {
                if (!(e && e.templateData && e.status && e.status.success))
                  return (
                    n.clearEntity(),
                    void E.warn({
                      msg: "NOTIFICATION INVALID DATA",
                      ctx: { id: a, data: e },
                    })
                  );
                if (!K.getElementById(_)) {
                  e = e.templateData;
                  var t = y.get("webengage.direction");
                  ("ltr" !== t && "rtl" !== t) || (e.direction = t),
                    (e.licenseCode = i),
                    (e.webengageHost = "//webengage.com"),
                    (e.appHost =
                      ("http:" == location.protocol ? "http:" : "https:") +
                      "//notification.webengage.com"),
                    E.debug({
                      msg: "NOTIFICATION DATA",
                      ctx: { id: a, data: e },
                    }),
                    o(e);
                }
              }
              var e = v.getForever(),
                r = v.getSession(),
                s = m("webengage/profile").getPersonalizationContext(
                  n,
                  n.instance.tokens
                ),
                c = webengage_fs_configurationMap.notificationRuleList || [],
                l = (r.upf && r.upf.journey) || {},
                g = {};
              e.cuid && (g.cuid = e.cuid);
              for (var d = 0; d < c.length; d++)
                if (a === c[d].notificationEncId) {
                  c[d].journeyId &&
                    l[c[d].journeyId] &&
                    ((g.journey_id = c[d].journeyId),
                    (g.context_id = l[c[d].journeyId].id));
                  break;
                }
              var u =
                  "https://p.webengage.com:443/users/" +
                  i +
                  "/" +
                  e.luid +
                  "/templates/NOTIFICATION-" +
                  a,
                p = y.get("webengage.personalization.host"),
                f = y.get("webengage.personalization.scheme"),
                b = y.get("webengage.personalization.port");
              p &&
                f &&
                b &&
                (u =
                  f +
                  "://" +
                  p +
                  ":" +
                  b +
                  "/users/" +
                  i +
                  "/" +
                  e.luid +
                  "/templates/NOTIFICATION-" +
                  a);
              var w = x.stringify(x.transit.encode(s));
              try {
                h.raw(x.addParamsToURL(u, g), w, function (e) {
                  t(x.parseJSON(e));
                });
              } catch (e) {
                (g.c = x.compress.compressToBase64(w)),
                  h.jsonp(x.addParamsToURL(u, g), t, "p");
              }
            }
            function r(e) {
              if (e && e.instance && e.instance.id)
                for (var t = 0; t < g.instanceCallbacks.length; t++) {
                  var n = g.instanceCallbacks[t];
                  i.desubscribe("notification." + n + "." + e.instance.id);
                }
            }
            function s(e) {
              if (e && e.instance) {
                var t = e.instance;
                t.clear && t.clear(),
                  t.frame && (c.iframe.remove(t.frame), (t.frame = null)),
                  (t.opened = null),
                  (t.layoutId = null),
                  (t.baseURL = null),
                  (t.appHost = null),
                  (t.dom = null),
                  (t.parentDom = null),
                  t.reset(),
                  r(e);
              }
            }
            function p(e) {
              var t,
                n = c.queryOne("#" + u);
              c.remove(n),
                (t = e) &&
                  t.length &&
                  x.mapArray(t, function (e) {
                    r(e);
                  });
            }
            e.exports = function () {
              var e = new l("notification", {
                methods: {
                  prepare: n,
                  getCallbackData: o,
                  getData: a,
                  clear: p,
                  clearEntity: s,
                },
                frameId: _,
              });
              return (
                (e.getContainer = function () {
                  return c.queryOne("#" + u);
                }),
                (e.getNotificationFrame = function () {
                  return c.queryOne("#" + _);
                }),
                E.debug({ msg: "NOTIFICATION INIT" }),
                e
              );
            };
          },
          {},
        ],
        "webengage/preview-selector": [
          function (u, e, t) {
            "use strict";
            var p,
              f,
              b,
              n,
              i =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (e) {
                      return typeof e;
                    }
                  : function (e) {
                      return e &&
                        "function" == typeof Symbol &&
                        e.constructor === Symbol &&
                        e !== Symbol.prototype
                        ? "symbol"
                        : typeof e;
                    },
              w = u("webengage/properties"),
              m = u("webengage/util"),
              o = u("webengage/events"),
              h = u("webengage/dom"),
              a = u("webengage/load"),
              v = u("webengage/logger"),
              y = u("webengage/animate"),
              x = null,
              r = null,
              E = {},
              _ = {
                i78ece1: u(
                  "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1.js"
                ),
                "1af572eg": u(
                  "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg.js"
                ),
                "2341ibfc": u(
                  "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc.js"
                ),
                "~20cc4d8h": u(
                  "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h.js"
                ),
                "~184fc482": u(
                  "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482.js"
                ),
                "~fg00e76": u(
                  "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76.js"
                ),
                "~483856a": u(
                  "webengage/web-personalization-layouts/web-personalization-shopify-~483856a.js"
                ),
              },
              S = {
                horizontalPadding: 20,
                verticalPadding: 15,
                horizontalOffset: 65,
                verticalPipeLength: 70,
                verticalOffset: 65,
              };
            function s() {
              !(function (e, t) {
                var n;
                p(t).css({ display: "block" });
                var i = p(e).offset(),
                  o = p(K).width(),
                  a = (p(K).height(), []),
                  r = [];
                if (i.left + p(e).outerWidth() + p(t).width() < o)
                  if (
                    ((n = {
                      left: i.left + p(e).outerWidth(),
                      direction: "left",
                    }),
                    0 < i.top - p(t).height() / 2)
                  ) {
                    (n.top = i.top - p(t).height() / 2),
                      (n.svgLeft = i.left + p(e).outerWidth() / 2),
                      (n.svgTop = n.top + S.verticalOffset),
                      (n.svgWidth = p(e).outerWidth() / 2 + 12),
                      (n.svgHeight = i.top - (n.top + S.verticalOffset));
                    var s = [];
                    s.push(3, 3, n.svgWidth - 6, 3),
                      r.push(s),
                      (s = []).push(3, 3, 3, n.svgHeight - 6),
                      r.push(s),
                      a.push(n.svgWidth - 3, 3, 3, n.svgHeight - 3);
                  } else {
                    (n.top = i.top + p(e).height() / 2 + S.verticalPipeLength),
                      (n.svgLeft = i.left + p(e).outerWidth()),
                      (n.svgTop = i.top + p(e).height() / 2),
                      (n.svgWidth = S.horizontalOffset),
                      (n.svgHeight = S.verticalPipeLength + S.verticalPadding);
                    var s = [];
                    s.push(6, 3, n.svgWidth - 3, 3),
                      r.push(s),
                      (s = []).push(
                        n.svgWidth - 3,
                        3,
                        n.svgWidth - 3,
                        n.svgHeight - 6
                      ),
                      r.push(s),
                      a.push(n.svgWidth - 3, n.svgHeight - 3, 3, 3);
                  }
                else if (0 < i.left - p(t).width())
                  if (
                    ((n = { left: i.left - p(t).width(), direction: "right" }),
                    0 < i.top - p(t).height() / 2)
                  ) {
                    (n.top = i.top - p(t).height() / 2),
                      (n.svgLeft = i.left - S.horizontalPadding),
                      (n.svgTop = n.top + S.verticalOffset),
                      (n.svgWidth =
                        p(e).outerWidth() / 2 + S.horizontalPadding),
                      (n.svgHeight = i.top - (n.top + S.verticalOffset));
                    var s = [];
                    s.push(6, 3, n.svgWidth - 3, 3),
                      r.push(s),
                      (s = []).push(
                        n.svgWidth - 3,
                        3,
                        n.svgWidth - 3,
                        n.svgHeight - 6
                      ),
                      r.push(s),
                      a.push(3, 3, n.svgWidth - 3, n.svgHeight - 3);
                  } else {
                    (n.top = i.top + p(e).height() / 2 + S.verticalPipeLength),
                      (n.svgLeft = i.left - S.horizontalOffset),
                      (n.svgTop = i.top + p(e).height() / 2),
                      (n.svgWidth = S.horizontalOffset),
                      (n.svgHeight = S.verticalPipeLength + S.verticalPadding);
                    var s = [];
                    s.push(3, 3, n.svgWidth - 6, 3),
                      r.push(s),
                      (s = []).push(3, 3, 3, n.svgHeight - 6),
                      r.push(s),
                      a.push(3, n.svgHeight - 3, n.svgWidth - 3, 3);
                  }
                else {
                  ((n = {
                    left: i.left + p(e).outerWidth() / 2 - p(t).width() / 2,
                    top: i.top + p(e).outerHeight() + S.verticalPipeLength,
                    direction: "down",
                  }).svgWidth = p(e).outerWidth() / 2),
                    (n.svgHeight = S.verticalPipeLength + S.verticalPadding),
                    (n.svgLeft = i.left + p(e).outerWidth() / 2),
                    (n.svgTop = i.top + p(e).outerHeight());
                  var s = [];
                  s.push(3, 6, 3, n.svgHeight - 6),
                    r.push(s),
                    a.push(3, n.svgHeight - 3, 3, 3);
                }
                if (
                  (p(t).css({
                    position: "absolute",
                    top: n.top + "px",
                    left:
                      (n.left > p(Z).width() || n.left <= 0 ? 10 : n.left) +
                      "px",
                    right:
                      (n.right > p(Z).width() || n.right <= 0 ? 10 : n.right) +
                      "px",
                  }),
                  p("#pipe-section").remove(),
                  K.createElementNS)
                ) {
                  var c = K.createElementNS(
                    "http://www.w3.org/2000/svg",
                    "svg"
                  );
                  if (
                    ((c.style.position = "absolute"),
                    (c.style.zIndex = "99999999"),
                    c.setAttribute("id", "pipe-section"),
                    (c.style.top = n.svgTop + "px"),
                    (c.style.left = n.svgLeft + "px"),
                    c.setAttribute("width", n.svgWidth),
                    c.setAttribute("height", n.svgHeight),
                    0 < a.length)
                  ) {
                    var l = K.createElementNS(
                      "http://www.w3.org/2000/svg",
                      "svg:circle"
                    );
                    l.setAttribute("cx", 0 == a[0] ? 3 : a[0]),
                      l.setAttribute("cy", 0 == a[1] ? 3 : a[1]),
                      l.setAttribute("r", 3),
                      l.setAttribute(
                        "style",
                        "stroke-width: 3; fill: #7866E7;"
                      ),
                      c.appendChild(l),
                      (l = K.createElementNS(
                        "http://www.w3.org/2000/svg",
                        "svg:circle"
                      )).setAttribute("cx", 0 == a[2] ? 3 : a[2]),
                      l.setAttribute("cy", 0 == a[3] ? 3 : a[3]),
                      l.setAttribute("r", 3),
                      l.setAttribute(
                        "style",
                        "stroke-width: 3; fill: #7866E7;"
                      ),
                      c.appendChild(l);
                  }
                  for (var g = 0; g < r.length; g++) {
                    var d = K.createElementNS(
                      "http://www.w3.org/2000/svg",
                      "svg:line"
                    );
                    d.setAttribute("x1", r[g][0]),
                      d.setAttribute("y1", r[g][1]),
                      d.setAttribute("x2", r[g][2]),
                      d.setAttribute("y2", r[g][3]),
                      d.setAttribute("style", "stroke:#7866E7; stroke-width:3"),
                      c.appendChild(d);
                  }
                  f.appendChild(c),
                    (E.pipeSectionInit = !0),
                    p("#pipe-section").css("left", n.svgLeft),
                    p("html, body").animate({ scrollTop: n.top - 100 }, "slow");
                }
              })(x, p(".we-container")),
                p(".we-content-section").hide(),
                x
                  ? (p("#we-cw-main-content").show(),
                    p("#we-node-selector-div").show(),
                    m.sendPostMessage({
                      type: "WE_CW",
                      action: w.CW_POST_MESSAGE_EVENT_NAME.EDITOR_OPENED,
                      selector: {},
                    }))
                  : p("#we-cw-main-content").show();
            }
            function c() {
              v.debug({ msg: "POPUPLOAD RENDER CALLED", ctx: E }),
                E &&
                  E.containerBoxInit === $ &&
                  (v.debug({ msg: "POPUPLOAD MARKUP ADDED" }),
                  p("head").append(
                    "\n\t\t\t\t<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n\t\t\t\t<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n\t\t\t\t<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@100&display=swap\" rel=\"stylesheet\">\n        <style>\n\t\t\t\t\t\t* {\n\t\t\t\t\t\t\tpadding:0px;\n\t\t\t\t\t\t\tmargin:0px;\n\t\t\t\t\t\t}\n            html{\n                background:transparent;\n                /* overflow:hidden; */\n            }\n\n            body {\n              /* font-family: 'Inter', sans-serif; */\n              background-color:transparent;\n              color:#333;\n              background: transparent;\n            }\n            \n            body,\n            table td,\n            .we-container{\n                font-size:15px;\n                line-height:160%;\n            }\n\t\t\t\t\t\t#we-container-box {\n              z-index: 999999999;\n\t\t\t\t\t\t\tfont-family: 'Inter', sans-serif !important;\n          }\n\t\t\t\t\t\t\n\t\t\t\t\t\t.we-container{\n\t\t\t\t\t\t\twidth: 250px;\n\t\t\t\t\t\t\tposition: relative;\n\t\t\t\t\t}\n            .close {\n                color:#000;\n                background:-webkit-linear-gradient(red, blue);\n                background:-o-linear-gradient(red, blue);\n                background:-moz-linear-gradient(red, blue);\n                background:linear-gradient(transparent, transparent);\n                border-color:transparent;\n                border-width:0px;\n                height: 20px;\n                width: 20px;\n                cursor: pointer;\n                position: absolute;\n                top: 0px; \n                right : 0px;\n                zIndex : 999999999;\n                font-family : Arial; sans-serif;\n                font-size : 14px;\n                line-height : 12px;\n                -moz-border-radius : 20px;\n                -webkit-border-radius : 20px;\n                border-radius : 20px;\n            }\n\n            .close span {\n                display : inline-block;\n                width : 16px;\n                margin-left : 7px;\n                margin-top : 7px;\n            }\n\n            @font-face {\n                font-family: 'Wecontent';\n                src:url('https://ssl.widgets.webengage.com/css/library/fonts/Wecontent.eot?jfq2i1');\n                src:url('https://ssl.widgets.webengage.com/css/library/fonts/Wecontent.eot?#iefixjfq2i1') format('embedded-opentype'),\n                    url('https://ssl.widgets.webengage.com/css/library/fonts/Wecontent.woff?jfq2i1') format('woff'),\n                    url('https://ssl.widgets.webengage.com/css/library/fonts/Wecontent.ttf?jfq2i1') format('truetype'),\n                    url('https://ssl.widgets.webengage.com/css/library/fonts/Wecontent.svg?jfq2i1#Wecontent') format('svg');\n                font-weight: normal;\n                font-style: normal;\n            }\n\n            .weicon {\n                font-family: 'Inter', sans-serif !important;\n                speak: none;\n                font-style: normal;\n                font-weight: normal;\n                font-variant: normal;\n                text-transform: none;\n                line-height: 1;\n\n                /* Better Font Rendering =========== */\n                -webkit-font-smoothing: antialiased;\n                -moz-osx-font-smoothing: grayscale;\n            }\n\n            .we_cancel:before {\n                content: \"\\e609\";\n            }\n            .we_check:before {\n                content: \"\\e632\";\n            }\n\n\t\t\t\t\t\t.we-content-mark {\n\t\t\t\t\t\t\t/* display: inline-flex; */\n\t\t\t\t\t\t\tflex-direction: column;\n\t\t\t\t\t\t\tjustify-content: center;\n\t\t\t\t\t\t\tborder-radius: 1px;\n\t\t\t\t\t\t /* border: 1px solid black; */\n\t\t\t\t\t\t/*\twidth: 186px; */\n\t\t\t\t\t\t\t/*\theight: 100px; */\n\t\t\t\t\t\t\tbackground: #fff;\n\t\t\t\t\t\t\tcolor: #292d32;\n\t\t\t\t\t\t\tpadding: 3px;\n\t\t\t\t\t\t\tborder-radius: 4px;\n\t\t\t\t\t\t\tfont-size: 14px;\n\t\t\t\t\t\t\tbox-shadow: 0px 9px 28px 8px rgba(0, 0, 0, 0.04), 0px 6px 16px 0px rgba(0, 0, 0, 0.06), 0px 3px 6px -4px rgba(0, 0, 0, 0.10);\n\t\t\t\t\t\t\tfont-family: 'Inter', sans-serif !important;\n\t\t\t\t\t\t}\n\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t.insert_below,\n\t\t\t\t\t\t.replace1,\n\t\t\t\t\t\t.insert_after1 {\n\t\t\t\t\t\t\tpadding: 7px 14px 6px 14px;\n\t\t\t\t\t\t\tcursor: pointer;\n\t\t\t\t\t\t\tfont-weight: 500;\n\t\t\t\t\t\tfont-family: sans-serif;\n\t\t\t\t\t\tdisplay: flex;\n\t\t\t\t\t\t\t\n\t\t\t\t\t\t}\n\t\t\t\t\t\t.insert_below:hover {\n\t\t\t\t\t\t\tbackground-color: #e9e5ff;\n\t\t\t\t\t\t\tborder-radius: 4px;\n\t\t\t\t\t\t\tcolor: #5745cf;\n\t\t\t\t\t\t\tbox-shadow: 0px 9px 28px 8px #0000000A; \n\t\t\t\t\t\t\tbox-sizing: border-box;\n\t\t\t\t\t\t\tmargin: 1px;\n\t\t\t\t\t\t}\n\n\t\t\t\t\t\t.replace1:hover {\n\t\t\t\t\t\t\tbackground-color: #e9e5ff;\n\t\t\t\t\t\t\tborder-radius: 4px;\n\t\t\t\t\t\t\tcolor: #5745cf;\n\t\t\t\t\t\t\tbox-shadow: 0px 9px 28px 8px #0000000A; \n\t\t\t\t\t\t\tbox-sizing: border-box;\n\t\t\t\t\t\t\tmargin: 1px;\n\t\t\t\t\t\t}\n\t\t\t\t\t\t.insert_after1:hover {\n\t\t\t\t\t\t\tbackground-color: #e9e5ff;\n\t\t\t\t\t\t\tborder-radius: 4px;\n\t\t\t\t\t\t\tcolor: #5745cf;\n\t\t\t\t\t\t\tbox-shadow: 0px 9px 28px 8px #0000000A; \n\t\t\t\t\t\t\tbox-sizing: border-box;\n\t\t\t\t\t\t\tmargin: 1px;\n\t\t\t\t\t\t}\n\t\t\t\t\t\t.we-margin-right {\n\t\t\t\t\t\t\tmargin-right: 8px;\n\t\t\t\t\t\t}\n        </style>\n    "
                  ),
                  p("body").append(
                    '\n        <div class="we-container webengage" id="we-container-box">\n            <div id=\'close\' class=\'close closePopup webengage\'>\n\t\t\t\t\t\t<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\n\t\t\t\t\t\t\t\t<rect class="webengage" width="20" height="20" rx="10" fill="white"/>\n\t\t\t\t\t\t\t\t<path class="webengage" d="M5.4881 15.2C5.35206 15.2 5.21908 15.1596 5.10595 15.084C4.99274 15.0084 4.9045 14.9009 4.8524 14.7751C4.80029 14.6494 4.78666 14.5109 4.81323 14.3774C4.8398 14.2439 4.90537 14.1212 5.00166 14.025L14.025 5.00161C14.1541 4.87252 14.3292 4.8 14.5117 4.8C14.6943 4.8 14.8694 4.87252 14.9985 5.00161C15.1276 5.1307 15.2001 5.30578 15.2001 5.48834C15.2001 5.6709 15.1276 5.84599 14.9985 5.97507L5.97525 14.9983C5.97523 14.9983 5.97521 14.9983 5.97519 14.9984C5.91128 15.0624 5.83537 15.1132 5.75179 15.1478C5.6682 15.1824 5.57858 15.2001 5.4881 15.2ZM5.4881 15.2L5.48837 15M5.4881 15.2L5.48837 15M5.4881 15.2C5.4882 15.2 5.4883 15.2 5.48841 15.2L5.48837 15M5.4881 15.2L5.48837 15" fill="black" stroke="black" stroke-width="0.4"/>\n\t\t\t\t\t\t\t\t<path class="webengage" d="M14.0248 14.9983L5.00161 5.97507C4.87252 5.84598 4.8 5.6709 4.8 5.48834C4.8 5.30578 4.87252 5.1307 5.00161 5.00161C5.1307 4.87252 5.30578 4.8 5.48834 4.8C5.6709 4.8 5.84598 4.87252 5.97507 5.00161L14.9984 14.025C14.9984 14.025 14.9984 14.025 14.9985 14.025C15.0947 14.1212 15.1603 14.2439 15.1869 14.3774C15.2134 14.5109 15.1998 14.6494 15.1477 14.7751C15.0956 14.9009 15.0073 15.0084 14.8941 15.084C14.781 15.1596 14.648 15.2 14.512 15.2L14.0248 14.9983ZM14.0248 14.9983L14.025 14.9985L14.1664 14.857L14.0248 14.9983Z" fill="black" stroke="black" stroke-width="0.4"/>\n\t\t\t\t\t\t</svg></div>\n\t\t\t\t\t\t\t<div class="we-content-section we-content-mark webengage" id="we-cw-main-content">\n\t\t\t\t\t\t\t\t\t<div class="insert_below operation webengage" name="before" >\n\t\t\t\t\t\t\t\t\t\t<img class="we-margin-right" name="before" src="https://dmq2kle6yj1z5.cloudfront.net/10a5cb699/2023-07-28T10%3A41%3A21.744Zarrow-up.svg"/>\n\t\t\t\t\t\t\t\t\t\t<p name="before" >Insert above</p>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="replace1 operation webengage" name="replace" >\n\t\t\t\t\t\t\t\t\t\t<img class="we-margin-right webengage" name="replace" src="https://dmq2kle6yj1z5.cloudfront.net/10a5cb699/2023-07-28T10%3A50%3A32.096Zarrow-up%20%287%29.svg"/>\n\t\t\t\t\t\t\t\t\t\t<p name="replace" >Replace</p>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t<div class="insert_after1 operation webengage" name="after" >\n\t\t\t\t\t\t\t\t\t\t<img class="we-margin-right webengage" name="after" src="https://dmq2kle6yj1z5.cloudfront.net/406578/2023-07-28T10%3A48%3A17.940Zarrow-up%20%283%29.svg"/>\n\t\t\t\t\t\t\t\t\t\t<p name="after" >Insert below</p> \n\t\t\t\t\t\t\t\t\t</div> \n\t\t\t\t\t\t\t</div>\n            </div>\n            </div>\n        </div>\n    '
                  ),
                  (E.containerBoxInit = !0)),
                E &&
                  E.operationListener === $ &&
                  (v.debug({ msg: "POPUPLOAD OPERATION CLICK LISTENER" }),
                  p(".operation")
                    .unbind("click")
                    .bind("click", function (e) {
                      var t = p(e.target).attr("name");
                      v.debug({ msg: "OPERATION SELECTED", ctx: t }),
                        (function (e) {
                          var t = h.getQuerySelector(x),
                            n = { cssSelector: t, placement: e.placement };
                          if (
                            (v.debug({
                              msg: "VARIABLE SELECTED INSTANCE MODIFIED",
                              ctx: { cssSelector: t },
                            }),
                            !b)
                          )
                            throw (
                              (C(), I(), new Error("INSTANCE DATA MISSING"))
                            );
                          var i = {
                            operation: e.placement
                              ? e.placement.toLowerCase()
                              : "",
                            type:
                              b.layoutAttributes.dom_id.type || "CSS_SELECTOR",
                            value: t,
                          };
                          v.debug({
                            msg: "VARIABLE SELECTED INSTANCE MODIFIED",
                            ctx: { data_: n, instance: b },
                          });
                          var o = {
                            type: "WE_CW",
                            mode: "editor",
                            selector: i,
                          };
                          m.sendPostMessage(o),
                            v.debug({
                              msg: "SEND POST MESSAGE TO PARENT ðŸš€",
                              ctx: o,
                            });
                          var a,
                            r = {
                              operation: e.placement
                                ? e.placement.toLowerCase()
                                : "",
                              name: "Web-sdk new selector - 1",
                              type:
                                b.layoutAttributes.dom_id.type ||
                                "CSS_SELECTOR",
                              value: t,
                            };
                          (b.layoutAttributes.dom_id = r),
                            (b.config.selectorEnabled =
                              b.config.selectorEnabled || null),
                            null === b.config.selectorEnabled &&
                              delete b.config.selectorEnabled;
                          C(), "" != t && (a = h.queryOne(t));
                          if (!a)
                            throw (C(), I(), new Error("DOM ELEMENT MISSING"));
                          var s = a.parentNode,
                            c = !1,
                            l = void 0,
                            g = void 0;
                          "i78ece1" != b.layoutEId ||
                            h.queryOne(
                              "#we-" +
                                b.config.id.replace(/~/g, "t_") +
                                "-" +
                                (b.variationId || "preview").replace(/~/g, "t_")
                            ) ||
                            ((c = !0),
                            v.debug({
                              msg: "PREVIEW SELECTOR SKIP OPERATION FOR BANNER LAYOUT USE PREPARE",
                              ctx: { skip: c },
                            }));
                          !1 === X.webPersonalization[b.layoutEId] &&
                            ((c = !0),
                            v.debug({
                              msg: "PREVIEW SELECTOR SKIP OPERATION FOR CAROUSEL LAYOUT USE PREPARE",
                              ctx: { skip: c },
                            }));
                          if ("replace" === e.placement)
                            return (
                              (c = !0),
                              v.debug({
                                msg: "PREVIEW SELECTOR SKIP REPLACE OPERATION USE PREPARE",
                                ctx: { skip: c },
                              }),
                              X.webPersonalization.clear()
                            );
                          if (c)
                            (X.webPersonalization.prepare = u(
                              "webengage/web-personalization-prep"
                            ).prepare),
                              X.webPersonalization.clear(),
                              X.webPersonalization.prepare(b);
                          else {
                            if (
                              (v.debug({
                                msg: "PREVIEW SELECTOR CAMPAIGN ALREADY RENDERED ONLY PLACE ",
                                ctx: { skip: !c },
                              }),
                              !h.queryOne(".webengage-webp13-container"))
                            )
                              throw (
                                (C(),
                                I(),
                                new Error(
                                  "WEB PERSONALIZATION CAMPAIGN IS MISSING IN DOM"
                                ))
                              );
                            switch (
                              ((l =
                                "i78ece1" == b.layoutEId
                                  ? h.queryOne(
                                      "#we-" +
                                        b.config.id.replace(/~/g, "t_") +
                                        "-" +
                                        (b.variationId || "preview").replace(
                                          /~/g,
                                          "t_"
                                        )
                                    )
                                  : h.queryOne(".webengage-webp13-container")),
                              v.debug({
                                msg: "WEBP EXITED DOM",
                                ctx: { exWebP: l.outerHTML },
                              }),
                              (g = h.createElement("div", l.outerHTML)),
                              l &&
                                (l.parentNode
                                  ? l.parentNode.remove()
                                  : l.remove()),
                              v.debug({
                                msg:
                                  "PREVIEW SELECTOR " +
                                  b.layoutId +
                                  " WEBP REMOVED EXITING DOM ELEMENT",
                                ctx: { exWebP: l },
                              }),
                              "i78ece1" != b.layoutEId &&
                                _[b.layoutEId].getScripts(b),
                              e.placement)
                            ) {
                              case "replace":
                                (g.id = a.id),
                                  (g.style.opacity = 0),
                                  y.fadeOut(a, function () {
                                    s.replaceChild(g, a), y.fadeIn(g);
                                  });
                                break;
                              case "after":
                                (g.style.opacity = 0),
                                  s.insertBefore(g, a.nextSibling),
                                  y.fadeIn(g);
                                break;
                              case "before":
                                (g.style.opacity = 0),
                                  s.insertBefore(g, a),
                                  y.fadeIn(g);
                                break;
                              default:
                                v.debug({
                                  msg: "PREVIEW WEB PERSONALIZATIONS DEFAULT CASE",
                                }),
                                  (a.innerHTML = g);
                            }
                            b &&
                            b.config &&
                            b.config.selectorEnabled &&
                            !0 === b.config.selectorEnabled
                              ? (m.sendPostMessage({
                                  type: "WE_CW",
                                  action:
                                    w.CW_POST_MESSAGE_EVENT_NAME
                                      .PREVIEW_ADVANCE_CSS_SELECTOR_PLACED_SUCCESS,
                                  data: {},
                                }),
                                v.debug({
                                  msg: "SEND POST MESSAGE TO PARENT ðŸš€",
                                  ctx: {
                                    action:
                                      w.CW_POST_MESSAGE_EVENT_NAME
                                        .PREVIEW_ADVANCE_CSS_SELECTOR_PLACED_SUCCESS,
                                  },
                                }))
                              : (m.sendPostMessage({
                                  type: "WE_CW",
                                  action:
                                    w.CW_POST_MESSAGE_EVENT_NAME
                                      .PREVIEW_SELECTOR_PLACED_SUCCESS,
                                  data: {},
                                }),
                                v.debug({
                                  msg: "SEND POST MESSAGE TO PARENT ðŸš€",
                                  ctx: {
                                    action:
                                      w.CW_POST_MESSAGE_EVENT_NAME
                                        .PREVIEW_SELECTOR_PLACED_SUCCESS,
                                  },
                                }));
                          }
                          var d = setInterval(function () {
                            var e = K.getElementsByClassName(
                              "webengage-webp13-container"
                            )[0];
                            e &&
                              (e.scrollIntoView({
                                block: "center",
                                behavior: "smooth",
                                inline: "center",
                              }),
                              clearInterval(d));
                          }, 100);
                          v.debug({
                            msg: "PREVIEW WEB PERSONALIZATIONS APPLIED",
                          }),
                            I(),
                            D(),
                            v.debug({
                              msg: "PREVIEW WEB PERSONALIZATIONS closed editor mode",
                            }),
                            X.options("isPreviewMode", !1);
                        })({ placement: t });
                    }),
                  (E.operationListener = !0)),
                p(".we-container").hide(),
                E &&
                  E.closeListener === $ &&
                  (p(".closePopup").click(function () {
                    m.sendPostMessage({
                      type: "WE_CW",
                      action: w.CW_POST_MESSAGE_EVENT_NAME.EDITOR_CLOSED,
                      selector: {},
                    }),
                      v.debug({
                        msg: "SEND POST MESSAGE TO PARENT ðŸš€",
                        ctx: {
                          action: w.CW_POST_MESSAGE_EVENT_NAME.EDITOR_CLOSED,
                        },
                      }),
                      I();
                  }),
                  (E.closeListener = !0)),
                p("button#back-button").click(function () {
                  v.debug({ msg: "BACK CLICKED" }),
                    v.debug({ msg: "CLOSED CALLED" }),
                    A(),
                    p(".we-content-box").removeClass("we-content-box"),
                    p(".we-select-highlight").removeClass(
                      "we-select-highlight"
                    ),
                    O();
                });
            }
            function C() {
              p("#we-cw-main-content").hide(),
                p(".we-container").hide(),
                p("#pipe-section").hide();
            }
            function I() {
              v.debug({ msg: "CLEAR SELECTION FN" }),
                p("#pipe-section").hide(),
                p(f).removeClass("we-display-important"),
                p(".we-container").hide(),
                p(".we-content-box").removeClass("we-content-box"),
                p(".we-select-highlight").removeClass("we-select-highlight"),
                p("#we-container-box").hide(),
                p("#we-node-selector-div").hide(),
                (x = null);
            }
            function l(e) {
              e.preventDefault(),
                e.stopPropagation(),
                p(e.currentTarget).blur();
            }
            function g(t) {
              try {
                return (
                  (t &&
                    "object" !== i(t.className) &&
                    "" != t.className &&
                    -1 < t.className.indexOf("webengage")) ||
                  (t.parentNode &&
                    "object" !== i(t.parentNode.className) &&
                    -1 < t.parentNode.className.indexOf("webengage"))
                );
              } catch (e) {
                return (
                  v.debug({
                    msg: "checkForOwnElements",
                    ctx: t,
                    error: { stack: e.stack },
                  }),
                  !1
                );
              }
            }
            function d(e) {
              var t = e.target || e.srcElement;
              if (!g(t)) {
                (x = t), A(), v.debug({ msg: "ELEMENT CLICKED", ctx: x });
                var n = p(x).closest(".shopify-section").prop("id");
                if (n) {
                  v.debug({ msg: "PARENT SELECTOR ID", ctx: n });
                  var i = p("#" + n)[0];
                  i
                    ? ((x = i || x), v.debug({ msg: "PARENT ELEMENT", ctx: x }))
                    : (v.debug({ msg: "DEFAULT ELEMENT CLICKED", ctx: x }),
                      (x = x));
                }
                (x = x), T(), s(), v.debug({ msg: "OPEN POPUP" });
                var o = h.getQuerySelector(x);
                v.debug({
                  msg: "WIDGET CSS SELECTOR",
                  ctx: { cssSelector: o, test: h.getElementPathCp(x) },
                });
              }
            }
            function T() {
              p("#we-selector-box").remove();
            }
            function k(e) {
              var t = e.target || e.srcElement;
              p(".we-select-highlight").removeClass("we-select-highlight"),
                g(t)
                  ? T()
                  : (function (e) {
                      var t = p(e).closest(".shopify-section").prop("id");
                      if (t) {
                        v.debug({ msg: "PARENT SELECTOR ID", ctx: t });
                        var n = p("#" + t)[0];
                        n
                          ? p(n).addClass("we-select-highlight")
                          : p(e).addClass("we-select-highlight");
                      }
                    })(t);
            }
            function A() {
              p("*").unbind("click", l),
                p(Z).unbind("mouseover", k),
                p("*").unbind("click", d),
                (E.registeredListener = !1);
            }
            function O() {
              p("*").bind("click", l),
                p(Z).bind("mouseover", k),
                p("*").bind("click", d),
                (E.registeredListener = !0);
            }
            function N() {
              v.debug({ msg: "PREVIEW SELECTOR REMOVE NODE SELECTOR " }),
                p("#we-node-selector-div").remove(),
                p(".we-select-highlight").removeClass("we-select-highlight"),
                (E.nodeSelectorContainerInit = !1),
                p("#we-cw-main-content").hide(),
                p("#we-container-box").hide();
            }
            function P() {
              v.debug({ msg: "PREVIEW MODE INIT", ctx: E }),
                p("head").append(
                  "\n        <style>\n\t\t\t\t    /**\n            #we-popup {\n                border-width: 0;\n                position: absolute;\n                z-index: 999999999;\n                overflow: hidden;\n                visibility:hidden;\n                position: absolute;\n            }\n             **/ \n            .we-display-important {\n                display: block !important;\n            }\n\n            .we-select-highlight {\n                cursor: cell !important;\n                border: 2px solid #7866E7 !important;\n\t\t\t\t\t\t\t\tborder-radius: 4px !important;\n            }\n\t\t\t\t\t\t\n            .we-content-box {\n              background-color: #FFF !important;\n              color: black !important;\n              /*position: relative;*/\n              z-index: 999999999;\n              border-width: 2px;\n              border-color: #227AB9;\n              border-style: solid;\n          }\n        </style>\n    "
                ),
                c(),
                p(K).keyup(function (e) {
                  27 == e.keyCode && (v.debug({ msg: "ESC " }), I());
                }),
                ((E && E.nodeSelectorContainerInit === $) ||
                  ("boolean" == typeof E.nodeSelectorContainerInit &&
                    !1 === E.nodeSelectorContainerInit)) &&
                  (v.debug({ msg: "PREVIEW MODE NODE SELECTOR ADDED" }),
                  ((f = h.createElement("div", "")).id =
                    "we-node-selector-div"),
                  (f.className = "webengage"),
                  h.queryOne("body").appendChild(f),
                  (E.nodeSelectorContainerInit = !0)),
                ((E && E.registeredListener === $) ||
                  ("boolean" == typeof E.registeredListener &&
                    !1 === E.registeredListener)) &&
                  O();
            }
            function D(e) {
              v.debug({
                msg: "PREVIEW SELECTOR MODE STOP ",
                ctx: n,
                instance: b,
                data: e,
              }),
                E && E.jqueryInit === $
                  ? a.script(
                      "https://ssl.widgets.webengage.com/js/jquery/jquery-1.10.2.min.js?v=277",
                      h.queryOne("body")
                    )(function () {
                      (r = Z.jQuery),
                        (p = function () {
                          return 1 === arguments.length
                            ? r(arguments[0], K)
                            : r.apply(null, arguments);
                        }),
                        (E.jqueryInit = !0),
                        A(),
                        N();
                    })
                  : (A(), N());
            }
            o.subscribe(w.CW_POST_MESSAGE_EVENT_NAME.PREVIEW, function (e) {
              (b = e),
                v.debug({
                  msg: "PREVIEW SELECTOR WEB PERSONALIZATION CAMPAIGN DATA ",
                  ctx: b,
                });
            }),
              o.subscribe(w.CW_POST_MESSAGE_EVENT_NAME.EDITOR, function (e) {
                (n = e), v.debug({ msg: "EDITOR MODE SELECTED", ctx: e });
              }),
              (e.exports = {
                start: function (e) {
                  v.debug({
                    msg: "PREVIEW SELECTOR MODE START ",
                    ctx: n,
                    instance: b,
                    data: e,
                  }),
                    E && E.jqueryInit === $
                      ? a.script(
                          "https://ssl.widgets.webengage.com/js/jquery/jquery-1.10.2.min.js?v=277",
                          h.queryOne("body")
                        )(function () {
                          (r = Z.jQuery),
                            (p = function () {
                              return 1 === arguments.length
                                ? r(arguments[0], K)
                                : r.apply(null, arguments);
                            }),
                            (E.jqueryInit = !0),
                            X.feedback.abort(),
                            X.survey.abort(),
                            X.notification.abort(),
                            P();
                        })
                      : P();
                },
                stop: D,
                loadSessionStackScript: function (e) {
                  v.debug({ msg: "WE_CW: loading session stack track script" });
                  var t =
                      '\n\t\t\t!(function (a, b) {\n\t\t\tconsole.log("<--- Begin SessionStack code ---\x3e");\n\t\t\tconsole.log("<--- Inside Iframe ---\x3e");\n\n\t\t\tvar c = window;\n\t\t\t(c.SessionStackKey = a), (c[a] = c[a] || { t: b, q: [] });\n\t\t\tfor (\n\t\t\tvar d = [\n\t\t\t\t"start",\n\t\t\t\t"stop",\n\t\t\t\t"identify",\n\t\t\t\t"getSessionId",\n\t\t\t\t"log",\n\t\t\t\t"setOnDataCallback",\n\t\t\t\t"trackEvent",\n\t\t\t\t],\n\t\t\t\te = 0;\n\t\t\te < d.length;\n\t\t\te++\n\t\t\t)\n\t\t\t!(function (b) {\n\t\t\t\tc[a][b] =\n\t\t\t\tc[a][b] ||\n\t\t\t\tfunction () {\n\t\t\t\t\tc[a].q.push([b].concat([].slice.call(arguments, 0)));\n\t\t\t\t};\n\t\t\t})(d[e]);\n\t\t\tvar f = document.createElement("script");\n\t\t\t(f.async = 1),\n\t\t\t(f.crossOrigin = "anonymous"),\n\t\t\t(f.src = "https://cdn.sessionstack.com/sessionstack.js");\n\t\t\tvar g = document.getElementsByTagName("script")[0];\n\t\t\tg.parentNode.insertBefore(f, g);\n\n\t\t\tconsole.log("<--- End SessionStack code ---\x3e");\n\t\t})("SessionStack", {\n\t\t\ttoken: "147cc27731d74dd792025087317d4a45",\n\t\t\tisIframe: true,\n\t\t});\n\t\tSessionStack.identify({\n\t\t\tuserId: "' +
                      e +
                      '",\n\t\t});\n\t',
                    n = K.createElement("script");
                  (n.type = "text/javascript"),
                    (n.charset = "UTF-8"),
                    (n.async = !0),
                    (n.innerHTML = t),
                    K.body.appendChild(n);
                },
              });
          },
          {
            "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg",
            "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc",
            "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1",
            "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482",
            "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h",
            "webengage/web-personalization-layouts/web-personalization-shopify-~483856a.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~483856a",
            "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76",
          },
        ],
        "webengage/profile": [
          function (w, e, t) {
            "use strict";
            function d(e) {
              if (Array.isArray(e)) {
                for (var t = 0, n = Array(e.length); t < e.length; t++)
                  n[t] = e[t];
                return n;
              }
              return Array.from(e);
            }
            var n = w("webengage/properties"),
              u = w("webengage/events"),
              m = w("webengage/state"),
              i = w("webengage/mappings"),
              f = w("webengage/comm"),
              b = w("webengage/weq"),
              h = w("webengage/util"),
              v = w("webengage/logger"),
              p = h.type,
              y = i.ACQUISITION_PROPS,
              x = i.USER_SYSTEM_ATTRIBUTES,
              E = i.USER_GEO_ATTRIBUTES,
              _ = {
                getEventCriteriaValue: function (e) {
                  var t = m.getSession().upf;
                  if (t && "array" === p(t.event_criterias))
                    for (var n = t.event_criterias, i = 0; i < n.length; i++)
                      if (e === n[i].criteria_id) return n[i].val;
                  return $;
                },
                getUserAttribute: function (e) {
                  var t = m.getForever().uattr || {};
                  return "we_birth_date" === e && "string" === p(t[e])
                    ? h.fromDateISOString(t[e] + "T00:00:00.000Z")
                    : "userId" === e
                    ? m.getForever().cuid
                    : t[e];
                },
                getProfileUserLevel: function (e) {
                  var t = m.getForever(),
                    n = m.getSession(),
                    i = n.upf || {};
                  return "session_count" === e
                    ? Math.max(t.sc || 0, i.session_count || 0)
                    : "last_seen" === e
                    ? Math.max(
                        t.lao || 0,
                        (i.last_seen && i.last_seen.getTime()) || 0
                      )
                    : "time_spent" === e
                    ? new Date().getTime() - n.sst
                    : "cuid" === e
                    ? t.cuid
                    : y.hasOwnProperty(e)
                    ? (t.aqsd || {})[y[e]] || $
                    : i.hasOwnProperty(e)
                    ? i[e]
                    : $;
                },
                getProfileDeviceLevel: function (e, t) {
                  var n = w("webengage/rules"),
                    i = m.getForever(),
                    o = m.getSession(),
                    a = o.upf || {};
                  if (1 === e)
                    switch (t) {
                      case "session_count":
                        return Math.max(
                          i.sc || 0,
                          (a.devices &&
                            a.devices[1] instanceof Array &&
                            0 < a.devices[1].length &&
                            a.devices[1][0].session_count) ||
                            0
                        );
                      case "last_seen":
                        return Math.max(
                          i.lao || 0,
                          (a &&
                            a.devices &&
                            a.devices[1] instanceof Array &&
                            0 < a.devices[1].length &&
                            a.devices[1][0].last_seen &&
                            a.devices[1][0].last_seen.getTime()) ||
                            0
                        );
                      case "time_spent":
                        return new Date().getTime() - o.sst;
                      case "browser_name":
                        return n.util.getBrowser(!0);
                      case "browser_version":
                        return n.util.getBrowserVersion();
                      case "os_name":
                        return n.util.getOS(!0);
                      case "device":
                        return n.util.getDevice();
                    }
                  return a.devices &&
                    a.devices[e] instanceof Array &&
                    0 < a.devices[e].length &&
                    a.devices[e][0][t] !== $
                    ? a.devices[e][0][t]
                    : $;
                },
                getProfileJourneyContext: function (e) {
                  var t = m.getSession().upf || {};
                  return (t.journey && t.journey[e]) || $;
                },
                getProfileJourneyStep: function (e, t) {
                  var n = m.getSession().upf || {};
                  return (n.journey && n.journey[e] && n.journey[e][t]) || $;
                },
                updateEventCriterias: function (e, t) {
                  for (
                    var n = m.getSession(),
                      i = webengage_fs_configurationMap.ecl || [],
                      o = (n.upf && n.upf.event_criterias) || [],
                      a = !1,
                      r = 0;
                    r < i.length;
                    r++
                  )
                    if (i[r].eventName === e) {
                      for (
                        var s = 0;
                        s < o.length && i[r].criteria_id !== o[s].criteria_id;
                        s++
                      );
                      if (s !== o.length) {
                        var c = o[s],
                          l = t ? t["we_" + i[r].attribute] : $,
                          g = p(l);
                        if (w("webengage/rules").execute(null, i[r].rule)) {
                          if ("COUNT" === i[r].function)
                            c.val = (c.val || 0) + 1;
                          else if ("number" === g)
                            switch (i[r].function) {
                              case "SUM":
                                c.val = (c.val || 0) + l;
                                break;
                              case "AVG":
                                (c.count = c.count || 0),
                                  (c.val =
                                    ((c.val || 0) * c.count + l) /
                                    (c.count + 1)),
                                  (c.count += 1);
                                break;
                              case "MIN":
                                (c.val === $ || c.val > l) && (c.val = l);
                                break;
                              case "MAX":
                                (c.val === $ || c.val < l) && (c.val = l);
                            }
                          else if ("date" === g)
                            switch (i[r].function) {
                              case "MIN":
                                (c.val === $ ||
                                  c.val.getTime() > l.getTime()) &&
                                  (c.val = l);
                                break;
                              case "MAX":
                                (c.val === $ ||
                                  c.val.getTime() < l.getTime()) &&
                                  (c.val = l);
                            }
                          a = !0;
                        }
                      }
                    }
                  a && ((n.upf.event_criterias = o), m.setSession(n));
                },
                savePersonalizationEvent: function (e) {
                  if (u.happened("ready") || "aa131c7a" != X.getLicenseCode())
                    for (
                      var t,
                        n,
                        i,
                        o =
                          webengage_fs_configurationMap.notificationRuleList ||
                          [],
                        a =
                          webengage_fs_configurationMap.webPersonalizationRuleList ||
                          [],
                        r = [].concat(d(o), d(a)),
                        s = 0;
                      s < r.length;
                      s++
                    ) {
                      t = r[s].tokens || [];
                      for (var c = 0; c < t.length; c++)
                        if (
                          "event" === t[c][0] &&
                          ((n = t[c][1]),
                          (i = t[c][2]),
                          (n === e.category ||
                            ("custom" === n && "application" === e.category)) &&
                            i === e.event_name)
                        ) {
                          var l = m.getSession(),
                            g = l.pev || {};
                          return (
                            g[n] || (g[n] = {}),
                            (g[n][i] = e),
                            (l.pev = g),
                            void m.setSession(l)
                          );
                        }
                    }
                },
                getPersonalizationContext: function (e, t) {
                  for (
                    var n = {},
                      i = m.getSession().pev || {},
                      o = m.getForever().uattr || {},
                      a = e.tokens || [],
                      r = 0;
                    r < a.length;
                    r++
                  )
                    if ("event" === a[r][0]) {
                      var s = a[r][1],
                        c = a[r][2],
                        l = a[r][3],
                        g = a[r][4];
                      if (i[s] && i[s][c]) {
                        n.event || (n.event = {}),
                          n.event[s] || (n.event[s] = {});
                        var d = i[s][c],
                          u = {
                            custom: d.event_data || {},
                            system: h.copy(
                              {
                                event_time: d.event_time,
                                cuid: d.cuid,
                                luid: d.luid,
                              },
                              d.system_data
                            ),
                          };
                        l
                          ? (n.event[s][c] || (n.event[s][c] = {}),
                            g
                              ? (n.event[s][c][l] || (n.event[s][c][l] = {}),
                                u[l].hasOwnProperty(g) &&
                                  (n.event[s][c][l][g] = u[l][g]))
                              : (n.event[s][c][l] = u[l]))
                          : (n.event[s][c] = u);
                      }
                    }
                  for (var p in ((n.screen = {
                    system: { screen_name: b.get("webengage.screenName") },
                    custom: t || {},
                  }),
                  (n.user = { custom: {}, system: {} }),
                  o))
                    o.hasOwnProperty(p) &&
                      o[p] !== $ &&
                      (x.hasOwnProperty(p)
                        ? (n.user.system[x[p]] = o[p])
                        : (n.user.custom[p] = o[p]));
                  return n;
                },
                setProfile: function (e) {
                  var t,
                    n,
                    i = m.getForever(),
                    o = m.getSession(),
                    a = i.uattr || {},
                    r = e.upf,
                    s = e.acquisitionData,
                    c = e.ua,
                    l = e.tld;
                  if (
                    (e.ts && (o.tsD = new Date().getTime() - e.ts),
                    c &&
                      (i.ua = [
                        c.browser.name,
                        c.browser.version,
                        c.os.name,
                        c.device,
                      ]),
                    l && (o.tld = l),
                    s)
                  ) {
                    for (n in ((t = {}), y))
                      s.hasOwnProperty(n) && (t[y[n]] = s[n]);
                    (o.aqsd = t), i.aqsd || (i.aqsd = t);
                  }
                  if (e.geo) {
                    w("webengage/geo").set(e.geo);
                    var g = e.geo;
                    for (n in E) g.hasOwnProperty(n) && (a[E[n]] = g[n]);
                    i.uattr = a;
                  }
                  if (
                    r &&
                    ((r = h.transit.decode(e.upf)),
                    !i.cuid || i.cuid === r.cuid)
                  ) {
                    var d = r.user_attributes || {};
                    for (n in d) d.hasOwnProperty(n) && (a[n] = d[n]);
                    for (n in (delete r.user_attributes, x))
                      x.hasOwnProperty(n) &&
                        r[x[n]] !== $ &&
                        ((a[n] = r[x[n]]), delete r[x[n]]);
                    for (n in ((t = {}), y))
                      r.hasOwnProperty(n) && ((t[y[n]] = r[n]), delete r[n]);
                    t.lp && (i.aqsd = t), (o.upf = r), (i.uattr = a);
                  }
                  o.upf = o.upf || {};
                  for (
                    var u = webengage_fs_configurationMap.ecl || [],
                      p = o.upf.event_criterias || [],
                      f = 0;
                    f < u.length;
                    f++
                  ) {
                    for (
                      var b = 0;
                      b < p.length && u[f].criteria_id !== p[b].criteria_id;
                      b++
                    );
                    b === p.length &&
                      p.push({ criteria_id: u[f].criteria_id, val: $ });
                  }
                  (o.upf.event_criterias = p), m.setSession(o), m.setForever(i);
                },
                load: function (n, e) {
                  var i = m.getForever(),
                    t = m.getSession(),
                    o = webengage_fs_configurationMap.ecl || [],
                    a = (t.upf && t.upf.event_criterias) || [],
                    r = e || (i.cuid && !(t.upf && t.upf.cuid)),
                    s = !t.aqsd || !i.ua,
                    c = !w("webengage/geo").isLoaded();
                  if (!r && o.length && 1 !== i.sc)
                    if (t.upf && t.upf.luid)
                      for (var l = 0; l < o.length; l++) {
                        for (
                          var g = 0;
                          g < a.length && o[l].criteria_id !== a[g].criteria_id;
                          g++
                        );
                        if (g === a.length) {
                          r = !0;
                          break;
                        }
                      }
                    else r = !0;
                  var d = webengage_fs_configurationMap.upfc;
                  if (
                    (d &&
                      ((d = h.compress.compressToBase64(h.stringify(d))),
                      t.upfc === d || r || (r = !0)),
                    r || s || c)
                  ) {
                    var u = {};
                    r &&
                      ((u.licenseCode = b.get("webengage.licenseCode")),
                      (u.luid = i.luid),
                      i.cuid && (u.cuid = i.cuid)),
                      d && (u.upfc = d),
                      s && ((u.lp = t.landingPage), (u.rf = t.referrer)),
                      c &&
                        ((u.geo = "y"),
                        !0 === b.get("webengage.aip") && (u.aip = 1));
                    var p = h.addParamsToURL(
                      "https://c.webengage.com/upf.js",
                      u
                    );
                    f.jsonp(
                      p,
                      function (e) {
                        if (
                          (v.debug({
                            msg: "PROFILE LOAD",
                            ctx: { luid: i.luid, url: p },
                          }),
                          _.setProfile(e),
                          d)
                        ) {
                          var t = m.getSession();
                          (t.upfc = d), m.setSession(t);
                        }
                        n();
                      },
                      "jsonp"
                    );
                  } else n();
                },
                reload: function () {
                  u.subscribe("rules.event-received", function (e, t) {
                    _.updateEventCriterias(e, t),
                      u.publish(n.CHANNEL_PROFILE_UPDATED);
                  }),
                    u.subscribe("tracker.event-logged", function (e) {
                      _.savePersonalizationEvent(e);
                    });
                },
              };
            _.reload(), (e.exports = _);
          },
          {},
        ],
        "webengage/properties": [
          function (e, t, n) {
            "use strict";
            var i = {
              widgetVersion: "4",
              weJquery:
                "//ssl.widgets.webengage.com/js/jquery/jquery-1.3.2.min.js",
              baseWebEngageUrl: "webengage.com",
              feedbackAppHost: "feedback.webengage.com",
              surveyAppHost: "survey.webengage.com",
              widgetDomain: "//ssl.widgets.webengage.com",
              baseStaticUrl: "//ssl.widgets.webengage.com",
              loadSurveyWidgetUrl: function (e) {
                return (
                  "/js/widget/we-survey-widget-" +
                  (e || "~483819f") +
                  "-v-4.0.js?v=277"
                );
              },
              loadSurveyWidgetUrlv3: "/js/widget/we-survey-widget.js?v=277",
              notificationWidgetScriptUrl:
                "/js/widget/we-notification-widget-v-4.1.js?v=277",
              findAllTakenSurveysUrl: function () {
                return (
                  "//survey.webengage.com/publisher-widget-loader.html?action=findAllTakenSurveys&licenseCode=" +
                  _weq["webengage.licenseCode"] +
                  "&url=" +
                  encodeURIComponent(_weUtil.getClientPageUrl())
                );
              },
              widgetContainerId: "webklipper-publisher-widget-container",
              feedbackImageBaseUrl:
                "https://dgn3cmgewqdgl.cloudfront.net/webengage/feedbacktab/",
              loadFeedbackWidgetUrl:
                "/js/widget/we-feedback-widget-v-4.0.js?v=277",
              loadFeedbackWidgetUrlv3: "/js/widget/we-feedback-widget.js?v=277",
              gaCallbacksScriptUrl:
                "//ssl.widgets.webengage.com/js/ga-integration.js?v=277",
              tstbu: "c.webengage.com",
              csUrl: "//ssl.widgets.webengage.com/js/conversion.js?v=277",
              instanceCallbacks: [
                "open",
                "close",
                "click",
                "submit",
                "complete",
                "minimize",
                "maximize",
                "abs_view",
                "control_group",
              ],
              JOURNEY_CX_FETCH_INTERVAL: 6e4,
              CHANNEL_WP_SUBSCRIBED: "web-push.subscribed",
              CHANNEL_PROFILE_UPDATED: "profile.updated",
              SYSTEM_CATEGORY_EVENT: "event.system",
              EVENTS_NEW_SESSION: "visitor_new_session",
              EVENTS_USER_UPDATE: "user_update",
              EVENTS_USER_LOGGED_IN: "user_logged_in",
              EVENTS_USER_DELETE_DEVICE: "user_delete_device",
              EVENTS_WP_PROMPT_VIEW: "push_notification_prompt_view",
              EVENTS_WP_PROMPT_ALLOWED: "push_notification_prompt_allowed",
              EVENTS_WP_PROMPT_DENIED: "push_notification_prompt_denied",
              EVENTS_WP_WINDOW_VIEW: "push_notification_window_view",
              EVENTS_WP_WINDOW_ALLOWED: "push_notification_window_allowed",
              EVENTS_WP_WINDOW_DENIED: "push_notification_window_denied",
              EVENTS_WP_REGISTER: "push_notification_registered",
              EVENTS_WP_UNREGISTER: "push_notification_unregistered",
              EVENTS_WP_OPT_OUT: "push_notification_opt_out",
              WP_PERMISSION_DEFAULT: "default",
              WP_PERMISSION_GRANTED: "granted",
              WP_PERMISSION_DENIED: "denied",
              WP_AUTH_TOKEN_KEY: "_we_token",
              FRONTLINE_HOSTS: [
                "https://dashboard.stg.convertwise.net",
                "https://app.convertwise.com",
                "https://frontline.stg.convertwise.net",
                "https://frontline.webengage.com",
                "https://dashboard-gallery.stg.convertwise.net",
                "https://dashboard-convertwise.stg.convertwise.net",
              ],
              IS_SHOPIFY_CLIENT: "isShopifyClient",
              P13_FILTERS: {
                PRODUCT_SLUG: {
                  PRODUCT_ID: "product_id",
                  VARIANT_ID: "id",
                  PRODUCT_CATEGORY: "productType",
                  AVAILABLE: "inventoryQuantity",
                },
              },
              DUMMY_PRODUCT: [
                {
                  id: "8161523826961",
                  title: "Demo Product",
                  vendor: "WebEngage Product Demo",
                  price: 799,
                  handle: "<Random>",
                  imageSrc:
                    "https://dmq2kle6yj1z5.cloudfront.net/test/2023-11-30T06%3A38%3A53.876ZthumbnailCW%20%281%29.svg",
                  compareAtPrice: 899,
                },
              ],
              CW_WEB_PERSONALIZATION_DELAY: 100,
              CW_POST_MESSAGE_EVENT_NAME: {
                PREVIEW: "event.postMessage.preview",
                EDITOR: "event.postMessage.editor",
                EDITOR_CLOSED: "EDITOR_CLOSED",
                EDITOR_OPENED: "EDITOR_OPEN",
                PREVIEW_ADVANCE_CSS_SELECTOR_PLACED_SUCCESS:
                  "ADVANCE_SELECTOR_FOUND",
                PREVIEW_ADVANCE_CSS_SELECTOR_PLACED_FAILED:
                  "ADVANCE_SELECTOR_NOT_FOUND",
                PREVIEW_SELECTOR_PLACED_FAILED: "CAMPAIGN_PLACEMENT_FAILED",
                PREVIEW_SELECTOR_PLACED_SUCCESS: "CAMPAIGN_PLACEMENT_SUCCESS",
              },
            };
            t.exports = i;
          },
          {},
        ],
        "webengage/rules": [
          function (e, t, n) {
            "use strict";
            var a =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (e) {
                      return typeof e;
                    }
                  : function (e) {
                      return e &&
                        "function" == typeof Symbol &&
                        e.constructor === Symbol &&
                        e !== Symbol.prototype
                        ? "symbol"
                        : typeof e;
                    },
              r = e("webengage/util"),
              s = e("webengage/events"),
              i = e("webengage/state"),
              o = (e("webengage/async"), e("webengage/xpath")),
              c = e("webengage/ua"),
              l = e("webengage/mappings"),
              g = e("webengage/dom"),
              d = e("webengage/geo"),
              u = e("webengage/tracker"),
              p = e("webengage/profile"),
              f = e("webengage/dependency"),
              b = {
                SEARCH_ENGINE_REGEXP: {
                  google: {
                    pattern: "^(?:http(s)?://)?(www\\.)?google\\..*/.*$",
                    queryParam: "q",
                  },
                  yahoo: {
                    pattern:
                      "^(?:http(s)?://)?(?:([a-z]{2})\\.)?search\\.yahoo\\.com/.*$",
                    queryParam: "p",
                  },
                  bing: {
                    pattern:
                      "^(?:http(s)?://)?((?:www|[a-z]{2})\\.)?bing\\.com/search\\?.*$",
                    queryParam: "q",
                  },
                  ask: {
                    pattern: "^(?:http(s)?://)?www\\.ask\\.com/.*$",
                    queryParam: "q",
                  },
                  baidu: {
                    pattern: "^(?:http(s)?://)?www\\.baidu\\.com/.*$",
                    queryParam: "wd",
                  },
                  yandex: {
                    pattern: "^(?:http(s)?://)?www\\.yandex\\.com/.*$",
                    queryParam: "text",
                  },
                  duckduckgo: {
                    pattern: "^(?:http(s)?://)?www\\.duckduckgo\\.com/.*$",
                    queryParam: "q",
                  },
                },
                SOCIAL_MEDIA_REGEX:
                  "^(?:http(s)?://)?(.*.)?(facebook|twitter|t|pinterest)\\.(com|co)/.*$",
              },
              w = {},
              m = {};
            function h() {
              if (d.isLoaded()) return !0;
              throw { type: "geo" };
            }
            function v(e) {
              var t = r.copy({}, e.event_data);
              for (var n in e.system_data)
                e.system_data.hasOwnProperty(n) &&
                  (t["we_" + n] = e.system_data[n]);
              for (n in e)
                e.hasOwnProperty(n) &&
                  "object" !== r.type(e[n]) &&
                  (t["we_" + n] = e[n]);
              var i =
                "system" === e.category ? "we_" + e.event_name : e.event_name;
              (m[i] = t), s.publish("rules.event-received", i, t);
            }
            var y = {
              isMatches: function (e, t) {
                if (e)
                  if (e instanceof Array) {
                    for (var n = 0; n < e.length; n++)
                      if (y.isMatches(e[n], t)) return !0;
                  } else if (t instanceof Array) {
                    for (var i = 0; i < t.length; i++)
                      if (e.match && e.match(new RegExp(t[i], "mgi")))
                        return !0;
                  } else if (e.match && e.match(new RegExp(t, "mgi")))
                    return !0;
                return !1;
              },
              getTimeInMS: function (e) {
                return e && "Invalid Date" !== new Date(e).toString()
                  ? new Date(e).getTime()
                  : null;
              },
              getCurrentTime: function (e) {
                var t = i.getServerTimestamp();
                e !== $ &&
                  (t = t + 6e4 * new Date().getTimezoneOffset() + 1e3 * e);
                return t;
              },
              getCurrentTimeInSec: function (e) {
                var t = new Date(e);
                return (
                  60 * t.getHours() * 60 + 60 * t.getMinutes() + t.getSeconds()
                );
              },
              getClientTime: function () {
                return y.getCurrentTimeInSec(y.getCurrentTime());
              },
              getCurrentWeekDay: function (e) {
                var t = y.getCurrentTime();
                return new Date(t).getDay();
              },
              getClientDayOfWeek: function () {
                return y.getCurrentWeekDay();
              },
              getPublisherTime: function () {
                var e = y.getCurrentTime(webengage_fs_configurationMap.tzo);
                return y.getCurrentTimeInSec(e);
              },
              get4DD: function (e, t) {
                if ("Invalid Date" === (e = new Date(e)).toString())
                  return null;
                var n = String(t).match(
                    /P(?:([-+]?[0-9]+)Y)?(?:([-+]?[0-9]+)M)?(?:([-+]?[0-9]+)W)?(?:([-+]?[0-9]+)D)?(T(?:([-+]?[0-9]+)H)?(?:([-+]?[0-9]+)M)?(?:([-+]?[0-9]+)S)?)?/
                  ),
                  i = parseInt(n[1] || 0),
                  o = parseInt(n[2] || 0),
                  a = parseInt(n[3] || 0),
                  r = parseInt(n[4] || 0),
                  s = parseInt(n[6] || 0),
                  c = parseInt(n[7] || 0),
                  l = parseInt(n[8] || 0),
                  g = e.getUTCFullYear(),
                  d = e.getUTCMonth(),
                  u = e.getUTCDate();
                12 <= o && ((i += Math.floor(o / 12)), (o %= 12)),
                  (g += i),
                  (d += o) < 0 && ((g -= 1), (d += 12)),
                  12 <= d && ((g += 1), (d -= 12));
                var p = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                return (
                  p[d] < u && (u = g % 4 == 0 && 1 === d ? 29 : p[d]),
                  e.setUTCDate(1),
                  e.setUTCFullYear(g),
                  e.setUTCMonth(d),
                  e.setUTCDate(u),
                  e.setTime(
                    e.getTime() +
                      1e3 * (l + 60 * c + 3600 * s + 86400 * r + 604800 * a)
                  ),
                  e.getTime()
                );
              },
              getClientPageUrl: function () {
                return Z.location.href;
              },
              isContainsSearchTerms: function (e, t) {
                var n = !1;
                if (
                  "function" != typeof e ||
                  !t ||
                  !(t instanceof Array) ||
                  t.length <= 0
                )
                  return !1;
                var i = e();
                if ((void 0 === i ? "undefined" : a(i)) !== $ && i)
                  for (
                    var o = 0;
                    o < t.length &&
                    ("boolean" !=
                      typeof (n = y.isContains(
                        i,
                        y.jsTokenizer(t[o], " "),
                        "contains_all"
                      )) ||
                      !n);
                    o++
                  );
                return n;
              },
              isContains: function (e, t, n) {
                var i = e;
                "function" == typeof e && (i = e());
                var o = !1,
                  a = n || "contains_any";
                if (i !== $ && i) {
                  var r = [];
                  if (i instanceof Array)
                    for (var s = 0; s < i.length; s++)
                      r[i[s].toLowerCase()] = !0;
                  else r[i] = !0;
                  if (t !== $ && t)
                    if (t instanceof Array) {
                      if ("contains_all" == a)
                        for (var c = 0; c < t.length; c++) {
                          if (1 != r[t[c].toLowerCase()]) {
                            o = !1;
                            break;
                          }
                          o = !0;
                        }
                      else
                        for (var l = 0; l < t.length; l++)
                          if (1 == r[t[l].toLowerCase()]) {
                            o = !0;
                            break;
                          }
                    } else o = 1 == r[t.toLowerCase()];
                }
                return o;
              },
              getReferrers: function () {
                var e = [];
                K.referrer && (e[e.length] = K.referrer.toLowerCase());
                var t = i.getSession();
                return (
                  !t ||
                    !t.referrer ||
                    (K.referrer && t.referrer == K.referrer) ||
                    (e[e.length] = t.referrer.toLowerCase()),
                  e
                );
              },
              getCountry: function () {
                if (h()) return d.get().country || null;
              },
              getRegion: function () {
                if (h()) return d.get().region || null;
              },
              getCity: function () {
                if (h()) return d.get().city || null;
              },
              getWECountry: function () {
                if (h()) return d.get().we_country || null;
              },
              getWERegion: function () {
                if (h()) return d.get().we_region || null;
              },
              getWECity: function () {
                if (h()) return d.get().we_city || null;
              },
              getSearchEngineMatchResult: function () {
                var e = y.getReferrers(),
                  t = { isSER: !1 };
                for (var n in b.SEARCH_ENGINE_REGEXP) {
                  for (var i = 0; i < e.length; i++)
                    if (
                      0 != y.isMatches(e[i], b.SEARCH_ENGINE_REGEXP[n].pattern)
                    ) {
                      (t.isSER = !0),
                        (t.url = e[i]),
                        (t.queryParam = b.SEARCH_ENGINE_REGEXP[n].queryParam);
                      break;
                    }
                  if (!0 === t.isSER) break;
                }
                return t;
              },
              isSearchEngineReference: function () {
                return y.getSearchEngineMatchResult().isSER;
              },
              isSocialMediaReference: function () {
                return y.isMatches(y.getReferrers(), b.SOCIAL_MEDIA_REGEX);
              },
              isFirstTime: function () {
                return 1 == p.getProfileUserLevel("session_count");
              },
              getSearchTerms: function () {
                var e = null,
                  t = y.getSearchEngineMatchResult();
                if (t.isSER) {
                  var n = decodeURI(y.getParamValue(t.url, t.queryParam));
                  n && (e = y.jsTokenizer(n, " "));
                }
                return e;
              },
              jsTokenizer: function (e, t) {
                var n = [];
                if (e !== $ && e) {
                  var i = r.escapeForRegExp(",\r\n");
                  t !== $ &&
                    t &&
                    (i =
                      t instanceof Array
                        ? r.escapeForRegExp(t.join(""))
                        : r.escapeForRegExp(t));
                  for (
                    var o = (e = e.replace(
                        new RegExp("[" + i + "]", "g"),
                        "\n"
                      )).split(/\n/g),
                      a = 0;
                    a < o.length;
                    a++
                  )
                    "" != o[a] && (n[n.length] = o[a]);
                }
                return n;
              },
              getParamValue: function (e, t) {
                var n = "",
                  i = new RegExp("[\\?&]" + t + "=([^&#]*)").exec(e);
                return null !== i && (n = i[1]), n;
              },
              escapeForRegExp: function (e) {
                return r.escapeForRegExp(e);
              },
              getTotalPageView: function () {
                var e = i.getSession();
                return e && e.pvc ? e.pvc : 1;
              },
              sampling: function () {
                var e =
                    0 < arguments.length && arguments[0] !== $
                      ? arguments[0]
                      : "",
                  t =
                    1 < arguments.length && arguments[1] !== $
                      ? arguments[1]
                      : "";
                if (((e = this.entityId || e), t)) {
                  var n = r.getHashCode(
                    (i.getForever().cuid || i.getForever().luid) + t
                  );
                  return Math.abs(n % 100);
                }
                if (e) {
                  n = r.getHashCode(
                    (i.getForever().cuid || i.getForever().luid) + e
                  );
                  return Math.abs(n % 100);
                }
                n = r.getHashCode(i.getForever().cuid || i.getForever().luid);
                return Math.abs(n % 100);
              },
              getSessionCookieReferer: function () {
                return i.getSession().referrer || null;
              },
              getXpathStringResult: function (e) {
                return o.evaluateXPathQuery(e);
              },
              getXpathIntegerResult: function (e) {
                var t = o.evaluateXPathQuery(e);
                return t ? parseFloat(t) : null;
              },
              isCSSPropertyExists: function (e) {
                var t = g.queryOne(e);
                return t || null;
              },
              getBrowser: function (e) {
                var t = (i.getForever().ua || [])[0];
                return t
                  ? (!e && l.UA_BROWSER_TRANSLATIONS[t]) || t
                  : c.browser;
              },
              getBrowserVersion: function () {
                return (i.getForever().ua || [])[1] || c.version;
              },
              getOS: function (e) {
                var t = (i.getForever().ua || [])[2];
                return t ? (!e && l.UA_OS_TRANSLATIONS[t]) || t : c.os;
              },
              getDevice: function (e) {
                var t = (i.getForever().ua || [])[3];
                return t ? (!e && l.UA_DEVICE_TRANSLATIONS[t]) || t : c.device;
              },
              getEventData: function (e, t) {
                ("on_exit" !== e &&
                  "we_wk_on_exit" !== e &&
                  "we_wk_leaveIntent" !== e) ||
                  (e = "we_leaveIntent"),
                  ("we_wk_time" !== e &&
                    "time" !== e &&
                    "we_wk_pageDelay" !== e) ||
                    (e = "we_pageDelay"),
                  ("totalTimeOnSite" !== e && "we_wk_totalTimeOnSite" !== e) ||
                    (e = "we_totalTimeOnSite"),
                  "we_wk_scrollPercentage" === e && (e = "we_scrollPercentage");
                try {
                  if (m.hasOwnProperty(e))
                    return t
                      ? m[e].hasOwnProperty(t)
                        ? m[e][t]
                        : null
                      : "we_leaveIntent" === e
                      ? m[e].happened
                      : m[e];
                } catch (e) {
                  return null;
                }
              },
            };
            function x(e, t, n) {
              var i = r.copy({}, w);
              return (
                ((i = r.copy(i, n || {}, !0)).entityId = e),
                (t = t === $ || t),
                new Function(
                  "util",
                  "_ruleUtil",
                  "_constants",
                  "operands",
                  "return (" + t + ");"
                )(r, y, b, i)
              );
            }
            function E() {
              (m = {}),
                (function () {
                  var e = {
                    referer: y.getReferrers,
                    url: y.getClientPageUrl(),
                    cookie: function (e) {
                      return g.cookie.getCookie(e);
                    },
                    country: y.getCountry,
                    region: y.getRegion,
                    city: y.getCity,
                    we_country: y.getWECountry,
                    we_region: y.getWERegion,
                    we_city: y.getWECity,
                    time: "",
                    isFirstTime: y.isFirstTime,
                    isSER: y.isSearchEngineReference,
                    isSMR: y.isSocialMediaReference,
                    searchTerms: y.getSearchTerms,
                    browser: y.getBrowser,
                    browser_version: y.getBrowserVersion,
                    os: y.getOS,
                    device: y.getDevice,
                    endUserTime: y.getClientTime,
                    publisherTime: y.getPublisherTime,
                    totalPageView: y.getTotalPageView,
                    sampling: y.sampling,
                    contentXPathString: y.getXpathStringResult,
                    contentXPathInteger: y.getXpathIntegerResult,
                    contentXPathNode: y.getXpathStringResult,
                    cssProperty: y.isCSSPropertyExists,
                    isDirectVisitor: y.getSessionCookieReferer,
                    dayOfWeek: y.getClientDayOfWeek,
                    event: y.getEventData,
                    eventCriteria: p.getEventCriteriaValue,
                    userAttr: p.getUserAttribute,
                    userSys: p.getProfileUserLevel,
                    userDevice: p.getProfileDeviceLevel,
                    journeyStep: p.getProfileJourneyStep,
                  };
                  for (var t in ((w = {}), e))
                    e.hasOwnProperty(t) &&
                      ((w[t] = e[t]), (w["we_wk_" + t] = e[t]));
                })(),
                s.subscribe("tracker.event-logged", v),
                s.subscribe("event.trigger", function (e, t) {
                  var n = u.base();
                  (n.category = "system"),
                    (n.event_name = e),
                    (n.event_data = t),
                    (n.event_time = new Date()),
                    v(n);
                });
            }
            var _ = {
              execute: x,
              evaluate: function (e, i, o) {
                return function (n) {
                  !(function t() {
                    try {
                      n(null, x(e, i, o));
                    } catch (e) {
                      e && e.type
                        ? f.load(e.type, null, t)
                        : (s.publish("error", e), n(e));
                    }
                  })();
                };
              },
              reload: E,
              util: y,
            };
            E(), (t.exports = _);
          },
          {},
        ],
        "webengage/state": [
          function (e, t, n) {
            "use strict";
            var i,
              o,
              a,
              r = e("webengage/async"),
              g = e("webengage/util"),
              s = e("webengage/dom"),
              c = e("webengage/weq"),
              l = e("webengage/events"),
              d = e("webengage/storage"),
              u = (e("webengage/ua"), e("webengage/logger")),
              p = e("webengage/properties"),
              f = g.curry,
              b = "_we_wk_ls_",
              w = "_we_wk_ss_",
              m = new Date();
            function h(e) {
              e || !T.getForever()
                ? ("boolean" ===
                    g.type(webengage_fs_configurationMap.ampEnabled) &&
                    s.cookie.getCookie("we_luid") &&
                    s.cookie.deleteCookie("we_luid", "/"),
                  (globalThis
                    ? globalThis.localStorage
                    : Z.localStorage
                  ).removeItem(p.WP_AUTH_TOKEN_KEY),
                  T.setForever(null),
                  T.setSession(null))
                : T.getSession()
                ? "number" === g.type(webengage_fs_configurationMap.sit)
                  ? (!a ||
                      a <
                        new Date().getTime() -
                          webengage_fs_configurationMap.sit) &&
                    T.setSession(null)
                  : s.cookie.getCookie("_we_wk_ss_lsf_") || T.setSession(null)
                : T.setSession(null);
              var t = T.getForever(),
                n = T.getSession();
              (c.get("webengage.isDemoMode") &&
                c.get("webengage.isPreviewMode")) ||
                n.vtd ||
                (l.publish("event.system", "visitor_new_session"),
                (n.vtd = 1),
                (t.lst = new Date().getTime())),
                (t.tpvc = t.tpvc ? t.tpvc + 1 : 1),
                (n.pvc = n.pvc ? n.pvc + 1 : 1),
                webengage_fs_configurationMap.ampEnabled &&
                  (s.cookie.getCookie("we_luid")
                    ? (t.luid = s.cookie.getCookie("we_luid"))
                    : s.cookie.setCookie("we_luid", t.luid, 365)),
                u.debug({ msg: "STATE INIT", ctx: { session: n, forever: t } }),
                T.setForever(t),
                T.setSession(n);
            }
            var v = {
              "session.notification.close": "closedNIds",
              "forever.notification.taken": "takenNIds",
              "session.notification.open": "snids",
              "forever.notification.open": "seenNIds",
              "forever.notification.open.absence": "anids",
              "session.notification.open.absence": "anids",
              "session.notification.minimize": "minNIds",
              "session.survey.close": "closedSurveys",
              "forever.survey.taken": "takenSurveys",
              "session.survey.open": "ssids",
              "forever.survey.open": "seenSIds",
              "forever.survey.open.absence": "asids",
              "session.survey.open.absence": "asids",
              "session.survey.minimize": "minSIds",
              "forever.webPersonalization.taken": "takenWPIds",
              "session.webPersonalization.open": "swpids",
              "forever.webPersonalization.open": "seenWPIds",
              "forever.webPersonalization.open.absence": "awpids",
              "session.webPersonalization.open.absence": "awpids",
            };
            function y(e, t, n, i) {
              var o = [];
              return (
                g.mapArray([e, t, n, i ? "absence" : ""], function (e) {
                  g.ensureString(e) && o.push(e);
                }),
                v[o.join(".")]
              );
            }
            function x(e, t, n, i, o, a) {
              var r,
                s,
                c = y(n, i, e, a);
              if (c) {
                var l = T["get" + g.capitalize(n)]();
                (l[c] = t
                  ? (function (e, n) {
                      if ((e = g.ensureString(e)).indexOf(n) < 0)
                        e += "##" + n + "=1";
                      else {
                        var t = new RegExp(
                          "##" + g.escapeForRegExp(n) + "=(\\d+)",
                          "g"
                        );
                        e = e.replace(t, function (e, t) {
                          return "##" + n + "=" + (+t + 1);
                        });
                      }
                      return e;
                    })(l[c], o)
                  : ((r = l[c]),
                    (s = o),
                    (r = g.ensureString(r)).indexOf(s) < 0 && (r += "##" + s),
                    r)),
                  T["set" + g.capitalize(n)](l);
              }
            }
            function E(t, n, e, i, o, a) {
              g.isArray(e)
                ? g.mapArray(e, function (e) {
                    x(t, n, e, i, o, a);
                  })
                : x(t, n, e, i, o, a);
            }
            function _(e, t, n, i, o, a) {
              var r = y(n, i, e, a);
              if (r) {
                var s = T["get" + g.capitalize(n)]();
                (s[r] = t
                  ? void s[r]
                  : (function (e, t) {
                      e = g.ensureString(e);
                      var n = new RegExp("##" + g.escapeForRegExp(t) + "$"),
                        i = new RegExp("##" + g.escapeForRegExp(t) + "##");
                      return (e = (e = e.replace(n, "")).replace(i, "##"));
                    })(s[r], o)),
                  T["set" + g.capitalize(n)](s);
              }
            }
            function S(t, n, e, i, o, a) {
              g.isArray(e)
                ? g.mapArray(e, function (e) {
                    _(t, n, e, i, o, a);
                  })
                : _(t, n, e, i, o, a);
            }
            function C(e, t, n, i, o, a) {
              var r,
                s,
                c = y(n, i, e, a);
              if (c) {
                var l = T["get" + g.capitalize(n)]();
                return t
                  ? (function (e, t) {
                      e = g.ensureString(e);
                      var n = new RegExp(
                          "##" + g.escapeForRegExp(t) + "=(\\d+)"
                        ),
                        i = e.match(n);
                      return i instanceof Array && 1 < i.length
                        ? parseInt(i[1], 10)
                        : 0;
                    })(l[c], o)
                  : ((r = l[c]),
                    (s = o),
                    (r = g.ensureString(r)),
                    (s = g.escapeForRegExp(s)),
                    !(!r.match("##" + s + "##") && !r.match("##" + s + "$")));
              }
              return null;
            }
            function I(e, t, n, i, o, a) {
              return C(e, t, n, i, o, a);
            }
            var T = {
              load: function (e) {
                function t() {
                  (o = g.transit.decode(d.get(i))),
                    (a = o && o.lmts),
                    d.onChange(i, function () {
                      o = g.transit.decode(d.get(i));
                    }),
                    d.remove(b),
                    d.remove(w),
                    e();
                }
                (i =
                  "_WE_" + c.get("webengage.licenseCode").replace(/~/g, "z")),
                  (o = null),
                  d.load(i)(function () {
                    d.get(i)
                      ? t()
                      : r.parallel([d.load(b), d.load(w)], function () {
                          if (d.get(b)) {
                            var e = d.get(b);
                            d.get(w) &&
                              ((e.session = d.get(w)),
                              e.session.lmts &&
                                e.lmts < e.session.lmts &&
                                (e.lmts = e.session.lmts)),
                              d.set(i, e);
                          }
                          t();
                        });
                  });
              },
              init: function () {
                h();
              },
              reset: function () {
                h(!0);
              },
              getForever: function () {
                return o;
              },
              getSession: function () {
                return o && o.session;
              },
              setForever: function (e) {
                var t = !e;
                (e = e || {}).luid ||
                  (e.luid = (function () {
                    if (
                      webengage_fs_configurationMap.ampEnabled &&
                      s.cookie.getCookie("we_luid")
                    )
                      return s.cookie.getCookie("we_luid");
                    for (
                      var e,
                        t,
                        n = [
                          c.get("webengage.licenseCode"),
                          new Date().getTime(),
                          m.getTime(),
                          m.toString().substr(25),
                          Z.navigator.platform,
                          268435456 * Math.random() + 65536,
                          65536 * Math.random(),
                        ].concat(
                          Z.location.href.split("/"),
                          Z.navigator.userAgent.split(" "),
                          K.cookie.split(";")
                        ),
                        i = n.length - 1;
                      0 < i;
                      i--
                    )
                      (e = Math.floor(Math.random() * (i + 1))),
                        (t = n[i]),
                        (n[i] = n[e]),
                        (n[e] = t);
                    var o = g.sha1(n.join());
                    return (
                      webengage_fs_configurationMap.ampEnabled &&
                        s.cookie.setCookie("we_luid", o, 365, "/"),
                      o
                    );
                  })()),
                  e.time || (e.time = new Date().getTime()),
                  e.isGzip === $ &&
                    c.has("webengage.isGzip") &&
                    (e.isGzip = c.get("webengage.isGzip"));
                var n = T.getForever();
                return (
                  t &&
                    n &&
                    "two-step" === n.wp_optin_type &&
                    ((e.wp_optin_type = "two-step"),
                    (e.wp_status = n.wp_status),
                    (e.interface_id = n.interface_id)),
                  (o = e),
                  d.set(i, g.transit.encode(o)),
                  T.getForever()
                );
              },
              setSession: function (e) {
                var t = T.getForever();
                e = e || {};
                var n = {
                  sst: new Date().getTime(),
                  pvc: 0,
                  landingPage: Z.location.href,
                  referrer: K.referrer,
                };
                return (
                  g.copy(e, n, !1),
                  e.suid ||
                    ((e.suid = new Date().getTime()),
                    (t.sc = t.sc ? t.sc + 1 : 1)),
                  (t.session = e),
                  T.setForever(t),
                  "number" !== g.type(webengage_fs_configurationMap.sit) &&
                    s.cookie.setCookie(
                      "_we_wk_ss_lsf_",
                      "ls" === T.where(),
                      "",
                      "/",
                      "",
                      ""
                    ),
                  T.getSession()
                );
              },
              where: function () {
                return d.where(i);
              },
              getServerTimestamp: function () {
                return new Date().getTime() + (T.getSession().tsD || 0);
              },
              setGZIPFlag: function (e) {
                var t = T.getForever();
                return (t.isGzip = e || !1), T.setForever(t);
              },
              markAsShown: f(E, "open", !0, ["session", "forever"]),
              markAsTaken: f(E, "taken", !1, "forever"),
              markAsClosed: f(E, "close", !1, "session"),
              markAsMinimized: f(E, "minimize", !1, "session"),
              markAsNotMinimzed: f(S, "minimize", !1, "session"),
              ifClosed: f(I, "close", !1, "session"),
              ifTaken: f(I, "taken", !1, "forever"),
              getTimesShown: f(I, "open", !0, "forever"),
              getTimesShownInSession: f(I, "open", !0, "session"),
              getMinimizedState: f(I, "minimize", !1, "session"),
              getEntity: I,
              getTotalViewsAcrossScope: function (e, t) {
                var n = y("forever", e, "open", !1);
                if (n) {
                  for (
                    var i,
                      o = T.getForever()[n],
                      a = g.ensureString(o).split("##"),
                      r = new RegExp(
                        g.escapeForRegExp(t) + "(?:\\[[^\\]]*\\])?=(\\d+)"
                      ),
                      s = 0,
                      c = 0;
                    c < a.length;
                    c++
                  )
                    (i = a[c].match(r)) instanceof Array &&
                      1 < i.length &&
                      (s += parseInt(i[1], 10));
                  return s;
                }
                return 0;
              },
              removeEntity: function (e, t, n, i) {
                S("minimize", !1, "session", e, t, n);
              },
              setEntity: function (e, t, n, i) {
                switch (e) {
                  case "open":
                    T.markAsShown(t, n, i);
                    break;
                  case "click":
                  case "submit":
                    T.markAsTaken(t, n, i);
                    break;
                  case "minimize":
                    T.markAsMinimized(t, n, i);
                    break;
                  case "close":
                    T.markAsClosed(t, n, i);
                }
              },
            };
            t.exports = T;
          },
          {},
        ],
        "webengage/storage": [
          function (e, t, n) {
            "use strict";
            var l,
              a,
              r,
              s = e("webengage/util"),
              g = e("webengage/events"),
              d = e("webengage/dom"),
              c = e("webengage/weq"),
              u = e("webengage/callback-frame"),
              p = "_we_wk_data_store",
              f = parseInt("40000"),
              b = "store",
              w = "ls",
              m = "ck",
              h = {};
            function v(e) {
              return e
                ? "{" === e.charAt(0)
                  ? s.parseJSON(e)
                  : s.parseJSON(s.compress.decompressFromBase64(e) || "{}")
                : null;
            }
            function i(e, t) {
              var n,
                i = h[e];
              if (
                ((i.cache = t),
                (i.cache.lmts = new Date().getTime()),
                (t = (n = i.cache)
                  ? s.compress.compressToBase64(s.stringify(n))
                  : ""),
                l && d.iframe.postMessage(p, { name: e, value: t, action: b }),
                i.where === w)
              )
                try {
                  Z.localStorage.setItem(e, t), d.cookie.setCookie(e, "", -1);
                } catch (e) {
                  i.where = m;
                }
              if (i.where === m) {
                d.cookie.setCookie(e, t, 99999, "/", "", "");
                try {
                  Z.localStorage.removeItem(e);
                } catch (e) {}
              }
            }
            function y(e, t) {
              if (h.hasOwnProperty(e)) {
                var n,
                  i,
                  o = h[e];
                try {
                  n = Z.localStorage.getItem(e);
                } catch (e) {
                  n = null;
                }
                i = d.cookie.getCookie(e);
                var a,
                  r = v(n),
                  s = v(t),
                  c = v(i);
                if (
                  (c &&
                    (!r || r.lmts < c.lmts) &&
                    ((n = i), (r = c), (o.where = m)),
                  r && (!s || !s.lmts || s.lmts < r.lmts))
                )
                  l &&
                    d.iframe.postMessage(p, { name: e, value: n, action: b }),
                    (a = r);
                else if (s && (!r || !r.lmts || r.lmts < s.lmts)) {
                  if (o.where === w)
                    try {
                      Z.localStorage.setItem(e, t),
                        d.cookie.setCookie(e, "", -1);
                    } catch (e) {
                      o.where = m;
                    }
                  if (o.where === m) {
                    d.cookie.setCookie(e, t, 99999, "/", "", "");
                    try {
                      Z.localStorage.removeItem(e);
                    } catch (e) {}
                  }
                  a = s;
                } else s && (a = s);
                (o.cache = a || null), g.publish("storage.change." + e);
              }
            }
            function x(e) {
              h.hasOwnProperty(e.key) && y(e.key, null);
            }
            var o = {
              init: function (t) {
                var e = c.get("webengage.licenseCode");
                if (
                  ((h = {}),
                  (l = a = null),
                  !e ||
                    !0 === c.get("webengage.isDemoMode") ||
                    !0 === c.get("webengage.isPreviewMode") ||
                    0 === f ||
                    !(function () {
                      try {
                        var e =
                          "undefined" != typeof Storage &&
                          "localStorage" in Z &&
                          null !== Z.localStorage;
                        return (
                          e &&
                            ((Z.localStorage._we_dm_ios_sup_f_ = "true"),
                            Z.localStorage.removeItem("_we_dm_ios_sup_f_")),
                          e
                        );
                      } catch (e) {
                        return !1;
                      }
                    })())
                )
                  return (a = !1), t();
                function n(e) {
                  e ||
                    (l && d.iframe.remove(p),
                    (l = null),
                    g.bind(Z, "storage", x)),
                    (a = !0 === e),
                    t();
                }
                g.unbind(Z, "storage", x), (r = setTimeout(n, f));
                var i = "https://" + e.replace(/~/g, "z") + ".webengage.co",
                  o =
                    i +
                    "/storage-frame-1.18.htm?cdn=y&cbf=" +
                    u.getName() +
                    "&lc=" +
                    e;
                u.onMessage(i, "storage", function (e) {
                  "init" === (e = s.parseJSON(e)).msg
                    ? e.value && "success" === e.value.status
                      ? (clearTimeout(r),
                        (Z.webengage_fs_configurationMap =
                          e.value.webengage_fs_configurationMap),
                        c.set("webengage.isGzip", e.value.isGzip),
                        n(!0))
                      : n(!1)
                    : h.hasOwnProperty(e.name) &&
                      h[e.name].recv &&
                      h[e.name].recv(e.name, e.value);
                }),
                  (l = d.iframe.create({ name: p, src: o }));
              },
              load: function (a) {
                return function (t) {
                  var n = { key: a, where: w };
                  function i(e) {
                    y(a, e), (n.recv = y), t();
                  }
                  if (((h[a] = n), !l)) return i();
                  var o = setTimeout(i, 1e3);
                  (h[a].recv = function (e, t) {
                    clearTimeout(o), i(t);
                  }),
                    d.iframe.postMessage(p, { name: a, action: "read" });
                };
              },
              onChange: function (e, t) {
                h.hasOwnProperty(e) && g.subscribe("storage.change." + e, t);
              },
              get: function (e) {
                if (h.hasOwnProperty(e)) return h[e].cache || null;
              },
              set: function (e, t) {
                h.hasOwnProperty(e) && i(e, t);
              },
              remove: function (e) {
                !(function (e) {
                  h.hasOwnProperty(e) && (h[e].cache = null),
                    l && d.iframe.postMessage(p, { name: e, action: "delete" });
                  try {
                    Z.localStorage.removeItem(e);
                  } catch (e) {}
                  d.cookie.setCookie(e, "", -1);
                })(e);
              },
              where: function (e) {
                return h.hasOwnProperty(e) ? h[e].where : null;
              },
              status: function () {
                return a;
              },
            };
            t.exports = o;
          },
          {},
        ],
        "webengage/survey": [
          function (e, t, n) {
            "use strict";
            var l = e("webengage/util"),
              g = e("webengage/weq"),
              d = e("webengage/events"),
              u = e("webengage/engagement"),
              p = e("webengage/properties"),
              f = e("webengage/state"),
              b = e("webengage/dom"),
              i = e("webengage/comm"),
              o = e("webengage/animate"),
              w = e("webengage/css"),
              m = e("webengage/logger"),
              h = e("webengage/callback-frame"),
              v = "webklipper-publisher-widget-container-survey-frame",
              y =
                ("http:" == location.protocol ? "http:" : "https:") +
                "//survey.webengage.com/mini-survey.html",
              x = {
                "~483819f": {
                  alignLayout: function (e, t) {
                    b.css.applyCss(e.frame, {
                      position: "absolute",
                      bottom: "0px",
                      right: "0px",
                      border: "none",
                      overflow: "hidden",
                      visibility: "visible",
                      display: "block",
                      "background-color": "transparent",
                      height: "100%",
                      width: "100%",
                    });
                    var n = t.alignment,
                      i = {
                        left: "auto",
                        right: "auto",
                        top: "auto",
                        zIndex: -1,
                        position: "fixed",
                        backgroundColor: "transparent",
                        bottom: "0px",
                        display: "block",
                        visibility: "hidden",
                        "-ms-filter":
                          "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)",
                        filter: "alpha(opacity=0)",
                        "-moz-opacity": 0,
                        "-khtml-opacity": 0,
                        opacity: "0",
                      };
                    "right" ==
                    (n = n && "BOTTOM_RIGHT" === n ? "right" : "left")
                      ? (i.right = "0px")
                      : (i.left = "10px"),
                      b.css.applyCss(e.surveyContainer, i);
                  },
                  show: function (e) {
                    b.css.applyCss(e.surveyContainer, {
                      zIndex: b.css.getMaxZIndex() + 1,
                      visibility: "visible",
                    }),
                      o.fadeIn(e.surveyContainer);
                  },
                  resize: function (e, t, n) {
                    b.css.applyCss(e.surveyContainer, {
                      height: t + 20 + "px",
                      width: n + 20 + "px",
                    });
                  },
                },
                "~20cc49c2": {
                  alignLayout: function (e) {
                    b.css.applyCss(e.surveyContainer, {
                      height: "100%",
                      width: "100%",
                      zIndex: -1,
                      position: "fixed",
                      backgroundColor: "transparent",
                      top: "0px",
                      left: "0px",
                      display: "block",
                      visibility: "hidden",
                      "-ms-filter":
                        "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)",
                      filter: "alpha(opacity=0)",
                      "-moz-opacity": 0,
                      "-khtml-opacity": 0,
                      opacity: "0",
                    }),
                      b.css.applyCss(e.frame, {
                        position: "relative",
                        bottom: "0px",
                        right: "0px",
                        border: "none",
                        overflow: "hidden",
                        visibility: "visible",
                        height: "100%",
                        width: "100%",
                        display: "block",
                        left: "0px",
                        backgroundColor: "transparent",
                      });
                  },
                  resize: function (e, t, n) {
                    b.css.applyCss(e.surveyContainer, {
                      height: t + "px",
                      width: n + "px",
                    });
                  },
                  show: function (e) {
                    b.css.applyCss(e.surveyContainer, {
                      zIndex: b.css.getMaxZIndex() + 1,
                      visibility: "visible",
                    }),
                      o.fadeIn(e.surveyContainer);
                  },
                },
                "~184fc0b6": {
                  alignLayout: function (e) {
                    b.css.applyCss(e.surveyContainer, {
                      display: "block",
                      "text-align": "center",
                      position: "absolute",
                      width: "100%",
                      zIndex: -1,
                      height: K.body.scrollHeight + "px",
                      left: "0",
                      top: "0",
                      outline: "none !important",
                      "-webkit-box-sizing": "border-box",
                      "-moz-box-sizing": "border-box",
                      "box-sizing": "border-box",
                      padding: "0px",
                      margin: "0",
                      "overflow-y": "auto",
                      "overflow-x": "hidden",
                      "background-color": "rgba(0, 0, 0, 0.2)",
                      visibility: "visible",
                      "-ms-filter":
                        "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)",
                      filter: "alpha(opacity=0)",
                      "-moz-opacity": 0,
                      "-khtml-opacity": 0,
                      opacity: "0",
                    }),
                      b.css.applyCss(e.frame, {
                        display: "block",
                        "text-align": "center",
                        position: "absolute",
                        width: "100%",
                        height: "100%",
                        left: "0",
                        top: "0",
                        outline: "none !important",
                        "-webkit-box-sizing": "border-box",
                        "-moz-box-sizing": "border-box",
                        "box-sizing": "border-box",
                        padding: "0px",
                        margin: "0",
                        "overflow-y": "auto",
                        "overflow-x": "hidden",
                        visibility: "visible",
                      });
                  },
                  resize: function (e) {},
                  show: function (e) {
                    b.css.applyCss(e.surveyContainer, {
                      zIndex: b.css.getMaxZIndex() + 1,
                      visibility: "visible",
                    }),
                      o.fadeIn(e.surveyContainer);
                  },
                },
              };
            function E(e) {
              var t = l.addParamsToURL(
                ("http:" == location.protocol ? "http:" : "https:") +
                  "//survey.webengage.com/track/survey.html",
                {
                  surveyEId: e.surveyId,
                  action: "track",
                  act: "view",
                  licenseCode: g.get("webengage.licenseCode"),
                }
              );
              i.jsonp(t, function () {
                m.debug({
                  msg: "SURVEY TRACK VIEW",
                  ctx: { id: e.surveyId, url: t },
                });
              });
            }
            function a(t, e) {
              var a = t.instance,
                n = f.getForever(),
                r = x[t.instance.layoutId],
                s = !0,
                i = b.createElement("div", "");
              b.addClass(i, "webklipper-publisher-survey-container-" + a.id),
                p.widgetContainer.appendChild(i),
                (a.surveyContainer = i);
              var o = u.util.getActivity(),
                c = {
                  action: "edit",
                  surveyEId: t.instance.id,
                  licenseCode: e,
                  widgetVersion: g.get("webengage.widgetVersion"),
                  pageUrl: Z.location.href,
                  pageTitle: K.title,
                  enableCallbacks: !0,
                  defaultTracking: !1,
                  r: Math.random(),
                  timesShown: f.getTimesShown("survey", a.id),
                  luid: n.luid,
                  country: o.country,
                  region: o.region,
                  city: o.city,
                  browser: o.browser,
                  version: o.browserVersion,
                  platform: o.platform,
                  cbFrame: h.getName(),
                };
              if (
                (t.scope && (c.scope = t.scope),
                t.scopeType && (c.scopeType = t.scopeType),
                g.get("webengage.survey.width") &&
                  (c.width = g.get("webengage.survey.width")),
                g.get("webengage.survey.theme") &&
                  (c.width = g.get("webengage.survey.theme")),
                g.get("webengage.aip") && (c.width = g.get("webengage.aip")),
                l.isEmptyObject(a.customData) ||
                  (c.clientDataString = u.util.getClientDataString(
                    a.customData
                  )),
                n.cuid && (c.cuid = n.cuid),
                (a.hide = function (e) {
                  b.remove(i);
                }),
                !K.getElementById(v))
              )
                return (
                  (a.frame = u.util.loadFrame(
                    y,
                    c,
                    {
                      name: "survey-frame-" + t.instance.id,
                      frameContainer: i,
                    },
                    function (e) {
                      setTimeout(function () {
                        s && _(t), "function" == typeof e && e();
                      }, 1e3);
                    }
                  )),
                  d.subscribe("survey.message." + a.id, function (e) {
                    var t, n;
                    switch (e.eventName) {
                      case "getScrollTop":
                        a.frame.contentWindow.postMessage(
                          '{ "scrollTop" :' + w.getScrollTop() + "}",
                          "*"
                        );
                        break;
                      case "resize":
                        r.resize(a, e.data.height, e.data.width);
                        break;
                      case "success":
                        (s = !1),
                          (t = e.data),
                          (n = t),
                          (a.show = function () {
                            a.opened ||
                              (a.events && a.events.open(n),
                              r.show(a),
                              (a.opened = !0));
                          }),
                          a.getBuffer().show && a.show(),
                          e.data.height &&
                            r.resize(a, e.data.height, e.data.width);
                        break;
                      case "submit":
                        a.events && a.events.submit(e.data),
                          e.data.height &&
                            r.resize(a, e.data.height, e.data.width);
                        break;
                      case "complete":
                        a.events && a.events.complete(e.data),
                          e.data.height &&
                            r.resize(a, e.data.height, e.data.width);
                        break;
                      case "redirect":
                        var i = e.data.response.redirectURL,
                          o = e.data.response.urlDestination;
                        "TOP" === o
                          ? (Z.location.href = i)
                          : "_BLANK" === o && Z.open(i, "_blank");
                        break;
                      case "close":
                        a.events && a.events.close(e.data), a.hide();
                        break;
                      case "error":
                        a.hide();
                    }
                  }),
                  r.alignLayout(a, t.la),
                  d.subscribe("survey.open." + a.id, E),
                  m.debug({
                    msg: "SURVEY PREPARED",
                    ctx: { id: t.instance.id, entity: t },
                  }),
                  t
                );
            }
            function r(e) {
              if (e && e.instance && e.instance.id)
                for (var t = 0; t < p.instanceCallbacks; t++) {
                  var n = p.instanceCallbacks[t];
                  d.desubscribe("survey." + n + "." + e.instance.id);
                }
            }
            function _(e) {
              if (e && e.instance) {
                var t = e.instance;
                t.frame && (b.iframe.remove(t.frame), (t.frame = null)),
                  t.surveyContainer &&
                    (b.remove(t.surveyContainer), (t.surveyContainer = null)),
                  (t.opened = null),
                  d.desubscribe("survey.message." + t.id),
                  t.reset(),
                  r(e);
              }
            }
            function s(e) {
              var t;
              (t = e) &&
                t.length &&
                l.mapArray(t, function (e) {
                  e && e.instance && e.instance.id && r(e);
                });
            }
            function c(e, t) {
              var n = (t = t || {}).response || {};
              return (n.surveyId = e.id), n;
            }
            t.exports = function () {
              var e = new u("survey", {
                methods: {
                  prepare: a,
                  getCallbackData: c,
                  clear: s,
                  clearEntity: _,
                },
                frameId: v,
              });
              return (
                h.onMessage(
                  ("http:" == location.protocol ? "http:" : "https:") +
                    "//survey.webengage.com",
                  "survey",
                  function (e) {
                    "survey" === (e = l.parseJSON(e)).engagement &&
                      d.publish("survey.message." + e.id, e);
                  }
                ),
                m.debug({ msg: "SURVEY INIT" }),
                e
              );
            };
          },
          {},
        ],
        "webengage/targeting-events": [
          function (e, t, n) {
            "use strict";
            var c = e("webengage/events"),
              i = e("webengage/state"),
              l = e("webengage/dom"),
              g = [],
              o = {
                we_wk_pageDelay: function () {
                  for (var e = 0; e < arguments.length; e++)
                    arguments[e] != $ &&
                      (function (e) {
                        var t = setTimeout(function () {
                          c.publish("event.trigger", "pageDelay", {
                            value: e + 1,
                          });
                        }, e);
                        g.push(function () {
                          clearTimeout(t);
                        });
                      })(arguments[e]);
                },
                we_wk_totalTimeOnSite: function () {
                  for (var e = 0; e < arguments.length; e++)
                    arguments[e] != $ &&
                      (function (e) {
                        var t = e - (new Date().getTime() - i.getSession().sst),
                          n = setTimeout(
                            function () {
                              c.publish("event.trigger", "totalTimeOnSite", {
                                value: e + 1,
                              });
                            },
                            0 < t ? t : 0
                          );
                        g.push(function () {
                          clearTimeout(n);
                        });
                      })(arguments[e]);
                },
                we_wk_leaveIntent: function () {
                  var i = K.documentElement,
                    o = l.queryOne("body"),
                    a = { x: 0, y: 0 };
                  function r(e) {
                    a.y = e.clientY;
                  }
                  function s(e) {
                    var t,
                      n = (e = e || Z.event).relatedTarget || e.toElement;
                    (t = Z.innerHeight
                      ? Z.innerHeight / 5
                      : Math.min(i.clientHeight, o.clientHeight) / 5),
                      (!n || "HTML" == n.nodeName) &&
                        e.clientY <= 0 &&
                        (a.y <= 0 || a.y < t) &&
                        (c.unbind(i, "mouseleave", s),
                        c.unbind(i, "mousemove", r),
                        c.publish("event.trigger", "leaveIntent", {
                          happened: !0,
                        }));
                  }
                  c.bind(i, "mouseleave", s),
                    c.bind(i, "mousemove", r),
                    g.push(function () {
                      c.unbind(i, "mouseleave", s), c.unbind(i, "mousemove", r);
                    });
                },
                we_wk_scrollPercentage: function () {
                  var i = Math.min.apply(null, arguments),
                    o = Math.max.apply(null, arguments),
                    a = K.documentElement,
                    r = l.queryOne("body");
                  function s(e) {
                    var t = Math.max(
                        r.scrollHeight || 0,
                        a.scrollHeight || 0,
                        r.offsetHeight || 0,
                        a.offsetHeight || 0,
                        r.clientHeight || 0,
                        a.clientHeight || 0
                      ),
                      n =
                        (((Z.pageYOffset || r.scrollTop || a.scrollTop || 0) +
                          (Z.innerHeight ||
                            a.clientHeight ||
                            r.clientHeight ||
                            0)) /
                          t) *
                        100;
                    i <= n &&
                      (setTimeout(function () {
                        c.publish("event.trigger", "scrollPercentage", {
                          value: n,
                        });
                      }, 0),
                      o <= n && c.unbind(Z, "scroll", s));
                  }
                  c.bind(Z, "scroll", s),
                    g.push(function () {
                      c.unbind(Z, "scroll", s);
                    });
                },
              };
            t.exports = {
              register: function (e) {
                o[e].apply(null, Array.prototype.slice.call(arguments, 1));
              },
              reload: function () {
                for (var e = 0; e < g.length; e++) g[e]();
                g = [];
              },
            };
          },
          {},
        ],
        "webengage/tracker": [
          function (o, e, t) {
            "use strict";
            var c = o("webengage/util"),
              l = o("webengage/weq"),
              g = o("webengage/events"),
              d = o("webengage/state"),
              a = o("webengage/dom"),
              s = o("webengage/comm"),
              u = o("webengage/fetch-helper"),
              r = [],
              p = !1;
            function f() {
              var e = d.getForever(),
                t = d.getSession(),
                n = {
                  license_code: l.get("webengage.licenseCode"),
                  suid: t.suid,
                  luid: e.luid,
                  system_data: {
                    webengage_version: l.get("webengage.widgetVersion"),
                    timezone:
                      webengage_fs_configurationMap &&
                      webengage_fs_configurationMap.tzo
                        ? webengage_fs_configurationMap.tzo
                        : 0,
                    visitor_start_time:
                      e.time && !isNaN(e.time)
                        ? new Date(parseInt(e.time, 10))
                        : null,
                    visitor_last_session_time:
                      e.lst && !isNaN(e.lst)
                        ? new Date(parseInt(e.lst, 10))
                        : null,
                    session_count: e.sc,
                    total_page_view_count: e.tpvc,
                    referrer: t.referrer,
                    visitor_session_start_time:
                      t.sst && !isNaN(t.sst)
                        ? new Date(parseInt(t.sst, 10))
                        : null,
                    page_view_count_session: t.pvc,
                    page_title: K.title,
                    page_url: Z.location.href,
                    viewport_height: a.css.getWindowHeight(),
                    viewport_width: a.css.getWindowWidth(),
                    sdk_id: 1,
                    ver: 2,
                  },
                };
              t.landingPage && (n.system_data.landing_page = t.landingPage),
                l.get("webengage.screenName") &&
                  (n.system_data.screen_name = l.get("webengage.screenName")),
                e.cuid && (n.cuid = e.cuid),
                e.interface_id && (n.interface_id = e.interface_id),
                webengage_fs_configurationMap &&
                  webengage_fs_configurationMap.config &&
                  webengage_fs_configurationMap.config.webPushConfig &&
                  webengage_fs_configurationMap.config.webPushConfig
                    .vapidPublicKey &&
                  (n.vapidPublicKey =
                    webengage_fs_configurationMap.config.webPushConfig.vapidPublicKey);
              var i = o("webengage/geo").get();
              return (
                i.we_country &&
                  ((n.system_data.country = i.we_country),
                  (n.system_data.region = i.we_region),
                  (n.system_data.city = i.we_city)),
                !0 === l.get("webengage.aip") && (n.system_data.aip = 1),
                n
              );
            }
            function b(e) {
              navigator.sendBeacon
                ? (function (t) {
                    for (var e, n = f(), i = 0; i < t.length; i++)
                      t[i].x_request_id ||
                        ((t[i].license_code = n.license_code),
                        (t[i].suid = n.suid),
                        (t[i].luid = n.luid),
                        (t[i].system_data = c.clone(
                          n.system_data || {},
                          t[i].system_data || {}
                        )),
                        (t[i].event_data = c.copy({}, t[i].event_data || {})),
                        [
                          "web_personalization_abs_view",
                          "web_personalization_control_group",
                        ].includes(t[i].event_name) &&
                          (delete t[i].system_data.id,
                          delete t[i].event_data.control_group),
                        n.cuid && (t[i].cuid = n.cuid),
                        n.interface_id && (t[i].interface_id = n.interface_id),
                        (e = c.copy(
                          { event_time: new Date(d.getServerTimestamp()) },
                          t[i]
                        )),
                        (t[i].x_request_id =
                          n.luid +
                          "-" +
                          n.license_code +
                          "-" +
                          e.event_time.getTime() +
                          "-" +
                          i),
                        g.publish("tracker.event-logged", e));
                    var o = c.stringify(c.transit.encode(t));
                    o = c.compress.compressToBase64(o);
                    var a = JSON.stringify({ data: o });
                    if (l.get("webengage.httpFetch"))
                      u.fetchKeepAlive(
                        ("http:" == location.protocol ? "http:" : "https:") +
                          "//c.webengage.com/l4.jpg",
                        a,
                        function () {
                          for (var e = 0; e < t.length; e++)
                            X.log.debug({
                              msg: "EVENT LOG",
                              ctx: { event: t[e].event_name, payload: t[e] },
                            });
                        }
                      );
                    else {
                      var r = navigator.sendBeacon(
                        ("http:" == location.protocol ? "http:" : "https:") +
                          "//c.webengage.com/l4.jpg",
                        a
                      );
                      if (r)
                        for (var s = 0; s < t.length; s++)
                          X.log.debug({
                            msg: "EVENT LOG",
                            ctx: { event: t[s].event_name, payload: t[s] },
                          });
                      else w(t);
                    }
                  })(e)
                : w(e);
            }
            function w(o) {
              for (
                var e, t = d.getForever(), n = f(), i = t.epq || [], a = 0;
                a < o.length;
                a++
              )
                o[a].x_request_id ||
                  ((o[a].license_code = n.license_code),
                  (o[a].suid = n.suid),
                  (o[a].luid = n.luid),
                  (o[a].system_data = c.clone(
                    n.system_data || {},
                    o[a].system_data || {}
                  )),
                  (o[a].event_data = c.copy({}, o[a].event_data || {})),
                  n.cuid && (o[a].cuid = n.cuid),
                  n.interface_id && (o[a].interface_id = n.interface_id),
                  (e = c.copy(
                    { event_time: new Date(d.getServerTimestamp()) },
                    o[a]
                  )),
                  (o[a].x_request_id =
                    n.luid +
                    "-" +
                    n.license_code +
                    "-" +
                    e.event_time.getTime() +
                    "-" +
                    a),
                  i.push(c.copy({ x_request_id: o[a].x_request_id }, e)),
                  g.publish("tracker.event-logged", e));
              "ls" === d.where() && ((t.epq = i), d.setForever(t));
              var r = c.stringify(c.transit.encode(o));
              (r = c.compress.compressToBase64(r)),
                s.xhr(
                  "https://c.webengage.com/l3.jpg",
                  { data: r },
                  function () {
                    var e = d.getForever();
                    if (e) {
                      for (var t = 0, n = e.epq || []; t < o.length; t++) {
                        for (var i = 0; i < n.length; i++)
                          if (o[t].x_request_id === n[i].x_request_id) {
                            n.splice(i, 1);
                            break;
                          }
                        X.log.debug({
                          msg: "EVENT LOG",
                          ctx: { event: o[t].event_name, payload: o[t] },
                        });
                      }
                      d.setForever(e);
                    }
                  }
                );
            }
            function i(e, t, n, i) {
              (l.get("webengage.isDemoMode") &&
                l.get("webengage.isPreviewMode")) ||
                (p
                  ? b([
                      {
                        category: e,
                        event_name: t,
                        event_data: n,
                        system_data: i,
                      },
                    ])
                  : r.push({
                      category: e,
                      event_name: t,
                      event_data: n,
                      system_data: i,
                    }));
            }
            function n() {
              (p = !(r = [])),
                g.subscribe("event.application", function (e, t) {
                  i("application", e, t);
                }),
                g.subscribe("event.system", function (e, t, n) {
                  i("system", e, t, n);
                }),
                g.subscribe("error", function (e, t, n, i, o, a) {
                  function r(e) {
                    return e
                      .replace(/[\\]/g, "\\\\")
                      .replace(/[\"]/g, '\\"')
                      .replace(/[\/]/g, "\\/")
                      .replace(/[\b]/g, "\\b")
                      .replace(/[\f]/g, "\\f")
                      .replace(/[\n]/g, "\\n")
                      .replace(/[\r]/g, "\\r")
                      .replace(/[\t]/g, "\\t");
                  }
                  try {
                    if (
                      (e instanceof Error &&
                        ((n =
                          900 < (n = e.stack || e.description).length
                            ? n.substring(0, 900)
                            : n),
                        (i = e.message || n.substring(0, 50)),
                        (t = e.type || "exception")),
                      t)
                    ) {
                      var s =
                        '{"version":"' +
                        l.get("webengage.widgetVersion") +
                        '", "text":"' +
                        r(n) +
                        '"';
                      if (
                        ((s +=
                          a && o
                            ? ', "et":"' + r(o) + '", "eid":"' + r(a) + '"}'
                            : "}"),
                        X.winUnloading && "error" === t)
                      )
                        return;
                      new Image().src = c.addParamsToURL(
                        ("http:" == location.protocol ? "http:" : "https:") +
                          "//c.webengage.com/e.jpg",
                        {
                          event: i,
                          category: l.get("webengage.licenseCode"),
                          type: t,
                          data: s,
                          ts: new Date().getTime(),
                        }
                      );
                    }
                  } catch (e) {}
                });
            }
            var m = {
              base: f,
              reload: n,
              ready: function () {
                p = !0;
                var e = d.getForever().epq || [];
                if ("array" !== c.type(e)) {
                  var t = d.getForever();
                  (t.epq = e = []), d.setForever(t);
                }
                e.length && b(e.slice()), r.length && (b(r), (r = []));
              },
            };
            n(), (e.exports = m);
          },
          {},
        ],
        "webengage/ua": [
          function (e, t, n) {
            "use strict";
            var i = navigator.userAgent,
              o =
                i.match(
                  /(Opera|Chrome|Safari|Firefox|MSIE|Trident(?=\/))\/?\s*(\d+)/i
                ) || [],
              a = o[1],
              r = o[2],
              s = "browser";
            function c(e, t) {
              t = t || e;
              for (var n = 0; n < e.length; n++)
                if (0 <= i.toLowerCase().indexOf(e[n].toLowerCase()))
                  return t[n];
            }
            /Trident/i.test(a) &&
              ((a = "MSIE"),
              (r = (o = /\brv[ :]+(\d+)/g.exec(i) || [])[1] || "")),
              "Chrome" === a &&
                null !== (o = i.match(/\b(OPR|Edge|Edg|EdgA)\/(\d+)/)) &&
                ((a = o[1]
                  .replace("OPR", "Opera")
                  .replace(/\b(?:(Edg|EdgA))\b/, "Edge")),
                (r = o[2])),
              "Safari" === a &&
                null !== (o = i.match(/\b(EdgiOS)\/(\d+)/)) &&
                ((a = o[1].replace("EdgiOS", "Edge")), (r = o[2])),
              r || ((a = navigator.appName), (r = navigator.appVersion)),
              null !== (o = i.match(/version\/(\d+)/i)) && (r = o[1]),
              c([
                "Mediapartners-Google",
                "Googlebot",
                "AdsBot-Google",
                "Google Page Speed Insights",
                "Site24x7",
                "PhantomJS",
                "HLB/",
              ]) && (s = "bot"),
              "MSIE" === a && (a = "Explorer");
            var l = c(
                [
                  "iPhone",
                  "iPod",
                  "iPad",
                  "Android",
                  "Windows Phone",
                  "Win",
                  "Mac",
                  "Linux",
                  "Mobile",
                  "Tablet",
                ],
                [
                  "iOS",
                  "iOS",
                  "iOS",
                  "Android",
                  "Windows Phone",
                  "Windows",
                  "Mac",
                  "Linux",
                  "Mobile",
                  "Tablet",
                ]
              ),
              g = c(
                [
                  "iPhone",
                  "iPod",
                  "iPad",
                  "Windows Phone",
                  "Mobile",
                  "Tablet",
                  "Android",
                  "Win",
                  "Mac",
                  "Linux",
                ],
                [
                  "Mobile",
                  "Mobile",
                  "Tablet",
                  "Mobile",
                  "Mobile",
                  "Tablet",
                  "Tablet",
                  "Desktop",
                  "Desktop",
                  "Desktop",
                ]
              );
            t.exports = {
              browser: a,
              version: parseInt(r),
              os: l || "unknown OS",
              device: g || "Desktop",
              type: s,
              ie: "Explorer" === a,
              ie6: "Explorer" === a && 6 == r,
              mobile: "Mobile" === g,
            };
          },
          {},
        ],
        "webengage/user": [
          function (e, t, n) {
            "use strict";
            var g = e("webengage/events"),
              d = e("webengage/state"),
              u = e("webengage/mappings"),
              p = e("webengage/logger"),
              f = e("webengage/util"),
              i = e("webengage/weq"),
              b = (e("webengage/indexedDB-helper"), f.type),
              o = e("webengage/properties");
            var a = {
              identify: function (e) {
                a.login(e);
              },
              login: function (e) {
                var t =
                    1 < arguments.length && arguments[1] !== $
                      ? arguments[1]
                      : null,
                  n = d.getForever();
                null != e &&
                  "" != e &&
                  ("string" !== b(e) && (e = f.stringify(e)),
                  100 < e.length &&
                    (p.warn(
                      'webengage.user.login() user id "' +
                        e +
                        '" exceeds character limit. Truncating to 100 character'
                    ),
                    (e = f.strunc(e, 100))),
                  n.cuid !== e &&
                    (null != n.cuid && (a.logout(), (n = d.getForever())),
                    (n.cuid = e),
                    d.setForever(n),
                    t && i.get("webengage.httpFetch") && a.setToken(t),
                    g.publish("event.system", "user_logged_in")));
              },
              logout: function () {
                null != d.getForever().cuid &&
                  g.publish("event.system", "user_logged_out"),
                  d.reset();
              },
              setAttribute: function (e, t) {
                var n,
                  i = d.getForever(),
                  o = i.uattr || {},
                  a = {},
                  r = {},
                  s = b(e),
                  c = !1;
                if ("string" === s) (n = {})[e] = t;
                else {
                  if ("object" !== s)
                    return void p.error(
                      "webengage.user.setAttribute() passed improper arguments"
                    );
                  n = e;
                }
                for (var l in n)
                  if (n.hasOwnProperty(l))
                    if (((t = n[l]), (s = b(t)), "" !== f.trim(l)))
                      if (
                        "number" === s ||
                        "boolean" === s ||
                        "string" === s ||
                        "date" === s ||
                        "object" === s ||
                        "array" === s
                      )
                        if (
                          (50 < l.length &&
                            (p.warn(
                              'webengage.user.setAttribute() attribute name "' +
                                l +
                                '" exceeds 50 character limit. Truncating to 50 characters'
                            ),
                            (l = f.strunc(l, 50))),
                          "string" === s &&
                            1e3 < t.length &&
                            (p.warn(
                              'webengage.user.setAttribute() value of attribute "' +
                                l +
                                '" exceeds 1000 character limit. Truncating to 1000 characters'
                            ),
                            (t = f.strunc(t, 1e3))),
                          u.USER_SYSTEM_ATTRIBUTES.hasOwnProperty("we_" + l) &&
                            !u.RESTRICTED_USER_SYS_ATTR["we_" + l] &&
                            (l = "we_" + l),
                          (e = u.USER_SYSTEM_ATTRIBUTES[l]))
                        ) {
                          if ("birth_date" === e) {
                            if (
                              ((t = f.fromDateISOString(t + "T00:00:00.000Z")),
                              isNaN(t.getTime()))
                            ) {
                              p.warn(
                                'webengage.user.setAttribute() "' +
                                  l +
                                  '" value is not in valid date format',
                                { value: t }
                              );
                              continue;
                            }
                            if (
                              "date" === b(o[l]) &&
                              t.getTime() === o.we_birth_date.getTime()
                            ) {
                              p.debug(
                                'webengage.user.setAttribute() ignored attribute "' +
                                  l +
                                  '" as same value has already been saved'
                              );
                              continue;
                            }
                          } else if ("gender" === e) {
                            if (
                              "male" !== t &&
                              "female" !== t &&
                              "other" !== t
                            ) {
                              p.warn(
                                'webengage.user.setAttribute() "' +
                                  l +
                                  '" value is invalid',
                                { value: t }
                              );
                              continue;
                            }
                          } else if ("email" === e) {
                            if (
                              "string" !== s ||
                              !/[^\s@]+@[^\s@]+\.[^\s@]+/.test(t)
                            ) {
                              p.warn(
                                'webengage.user.setAttribute() "' +
                                  l +
                                  '" value is not valid email address',
                                { value: t }
                              );
                              continue;
                            }
                          } else if (
                            "email_opt_in" === e ||
                            "sms_opt_in" === e ||
                            "whatsapp_opt_in" === e
                          ) {
                            if ("boolean" !== s) {
                              p.warn(
                                'webengage.user.setAttribute() "' +
                                  l +
                                  '" value is not a boolean',
                                { value: t }
                              );
                              continue;
                            }
                          } else if ("string" !== s) {
                            p.warn(
                              'webengage.user.setAttribute() "' +
                                l +
                                '" value is not a string',
                              { value: t }
                            );
                            continue;
                          }
                          if (t === o[l]) {
                            p.debug(
                              'webengage.user.setAttribute() ignored attribute "' +
                                l +
                                '" as same value has already been saved'
                            );
                            continue;
                          }
                          if (u.RESTRICTED_USER_SYS_ATTR[l]) {
                            p.debug(
                              'webengage.user.setAttribute() "' +
                                l +
                                '" is a restricted attribute'
                            );
                            continue;
                          }
                          (r[e] = t), (o[l] = t), (c = !0);
                        } else {
                          if (0 === l.indexOf("we_")) {
                            p.warn(
                              'webengage.user.setAttribute() "' +
                                l +
                                '" is not a known system attribute'
                            );
                            continue;
                          }
                          if ("date" === s) {
                            if (isNaN(t.getTime())) {
                              p.warn(
                                'webengage.user.setAttribute() "' +
                                  l +
                                  '" value is not a valid date object',
                                { value: t }
                              );
                              continue;
                            }
                            if (
                              "date" === b(o[l]) &&
                              o[l].getTime() === t.getTime()
                            ) {
                              p.debug(
                                'webengage.user.setAttribute() ignored attribute "' +
                                  l +
                                  '" as same value has already been saved'
                              );
                              continue;
                            }
                          } else if (
                            t === o[l] &&
                            "object" !== s &&
                            "array" !== s
                          ) {
                            p.debug(
                              'webengage.user.setAttribute() ignored attribute "' +
                                l +
                                '" as same value has already been saved'
                            );
                            continue;
                          }
                          (a[l] = t), (o[l] = t), (c = !0);
                        }
                      else
                        p.warn(
                          'webengage.user.setAttribute() is passed value of unsupported type "' +
                            s +
                            '" for attribute "' +
                            l +
                            '"',
                          { value: t }
                        );
                    else
                      p.warn(
                        "webengage.user.setAttribute() is passed blank name for an attribute",
                        { value: t }
                      );
                c &&
                  ((i.uattr = o),
                  d.setForever(i),
                  g.publish("event.system", "user_update", a, r));
              },
              getAnonymousId: function () {
                return d.getForever() && d.getForever().luid;
              },
              setToken: function (e) {
                1 < arguments.length && arguments[1] !== $ && arguments[1];
                (globalThis ? globalThis.localStorage : Z.localStorage).setItem(
                  o.WP_AUTH_TOKEN_KEY,
                  e
                );
              },
            };
            t.exports = a;
          },
          {},
        ],
        "webengage/util/bare": [
          function (u, e, t) {
            "use strict";
            var a =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (e) {
                      return typeof e;
                    }
                  : function (e) {
                      return e &&
                        "function" == typeof Symbol &&
                        e.constructor === Symbol &&
                        e !== Symbol.prototype
                        ? "symbol"
                        : typeof e;
                    },
              l = {
                copy: function (e, t, n, i) {
                  for (var o in ((n = !1 !== n), t))
                    if (t.hasOwnProperty(o) && (e[o] === $ || n)) {
                      if (i && t[o] == $) continue;
                      e[o] = t[o];
                    }
                  return e;
                },
                clone: function (e, t) {
                  return l.copy(l.copy({}, e), t);
                },
                isEmptyObject: function (e) {
                  for (var t in e) if (e.hasOwnProperty(t)) return !1;
                  return !0;
                },
                trim: function (e) {
                  return e.replace(/^\s+|\s+$/g, "");
                },
                strunc: function (e, t) {
                  return e && e.substr(0, t);
                },
                isArray: function (e) {
                  return e && e.constructor == Array;
                },
                inArray: function (e, t) {
                  return -1 !== l.indexOfArray(e, t);
                },
                indexOfArray: function (e, t, n) {
                  return e.indexOf(t, n);
                },
                mapArray: function (e, t) {
                  return e.map(t);
                },
                stringify: function (e) {
                  return JSON.stringify(e);
                },
                parseJSON: function (e) {
                  return JSON.parse(e);
                },
                getHashCode: function (e) {
                  e = e || "";
                  for (var t = 0, n = 0; t < e.length; t++)
                    (n = (n << 5) - n + e.charCodeAt(t)), (n |= 0);
                  return n;
                },
                capitalize: function (e) {
                  return (
                    "string" == typeof e &&
                      0 < e.length &&
                      (e = e.charAt(0).toUpperCase() + e.substring(1)),
                    e
                  );
                },
                ensureString: function (e) {
                  return "string" == typeof e ? e : "";
                },
                escapeScopeChars: function (e) {
                  return (e + "").replace(/([,#[\]\\])/g, "$1");
                },
                escapeForRegExp: function (e) {
                  return (e + "").replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1");
                },
                toDateISOString: function (e) {
                  return e.toISOString();
                },
                fromDateISOString: function (e) {
                  return new Date(e);
                },
                guard: function (e, t) {
                  if ("function" != typeof e)
                    throw new Error(
                      "guard() - First argument is not a function"
                    );
                  return function () {
                    try {
                      return e.apply(this, arguments);
                    } catch (e) {
                      if (
                        (X.require("webengage/events").publish("error", e),
                        !0 !== t)
                      )
                        throw e;
                    }
                  };
                },
                addParamsToURL: function (e, t) {
                  var n = [];
                  for (var i in t)
                    t.hasOwnProperty(i) &&
                      t[i] != $ &&
                      n.push(
                        encodeURIComponent(i) + "=" + encodeURIComponent(t[i])
                      );
                  return (
                    n.length &&
                      (-1 === e.indexOf("?")
                        ? (e += "?")
                        : e.indexOf("?") !== e.length - 1 &&
                          "&" !== e.charAt(e.length - 1) &&
                          (e += "&"),
                      (e += n.join("&"))),
                    e
                  );
                },
                base64Encode: function (e) {
                  return btoa(
                    encodeURIComponent(e).replace(
                      /%([0-9A-F]{2})/g,
                      function (e, t) {
                        return String.fromCharCode("0x" + t);
                      }
                    )
                  );
                },
                base64Decode: function (e) {
                  return decodeURIComponent(
                    atob(e)
                      .split("")
                      .map(function (e) {
                        return (
                          "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2)
                        );
                      })
                      .join("")
                  );
                },
                urlBase64ToUint8Array: function (e) {
                  for (
                    var t = (e + "=".repeat((4 - (e.length % 4)) % 4))
                        .replace(/\-/g, "+")
                        .replace(/_/g, "/"),
                      n = atob(t),
                      i = new Uint8Array(n.length),
                      o = 0;
                    o < n.length;
                    ++o
                  )
                    i[o] = n.charCodeAt(o);
                  return i;
                },
                pick: function (n, e) {
                  return e.reduce(function (e, t) {
                    return (
                      n &&
                        Object.prototype.hasOwnProperty.call(n, t) &&
                        (e[t] = n[t]),
                      e
                    );
                  }, {});
                },
                deepDiffMapper: {
                  VALUE_CREATED: "created",
                  VALUE_UPDATED: "updated",
                  VALUE_DELETED: "deleted",
                  VALUE_UNCHANGED: "unchanged",
                  map: function (e, t) {
                    if (this.isFunction(e) || this.isFunction(t))
                      throw new Error(
                        "Invalid argument. Function given, object expected."
                      );
                    if (this.isValue(e) || this.isValue(t))
                      return {
                        type: this.compareValues(e, t),
                        data: e === $ ? t : e,
                      };
                    var n = {};
                    for (var i in e)
                      if (!this.isFunction(e[i])) {
                        var o = $;
                        t[i] !== $ && (o = t[i]), (n[i] = this.map(e[i], o));
                      }
                    for (var a in t)
                      this.isFunction(t[a]) ||
                        n[a] !== $ ||
                        (n[a] = this.map($, t[a]));
                    return n;
                  },
                  compareValues: function (e, t) {
                    return e === t
                      ? this.VALUE_UNCHANGED
                      : this.isDate(e) &&
                        this.isDate(t) &&
                        e.getTime() === t.getTime()
                      ? this.VALUE_UNCHANGED
                      : e === $
                      ? this.VALUE_CREATED
                      : t === $
                      ? this.VALUE_DELETED
                      : this.VALUE_UPDATED;
                  },
                  isFunction: function (e) {
                    return (
                      "[object Function]" === Object.prototype.toString.call(e)
                    );
                  },
                  isArray: function (e) {
                    return (
                      "[object Array]" === Object.prototype.toString.call(e)
                    );
                  },
                  isDate: function (e) {
                    return (
                      "[object Date]" === Object.prototype.toString.call(e)
                    );
                  },
                  isObject: function (e) {
                    return (
                      "[object Object]" === Object.prototype.toString.call(e)
                    );
                  },
                  isValue: function (e) {
                    return !this.isObject(e) && !this.isArray(e);
                  },
                },
                isRender: function (e) {
                  var t = [
                      "numberOfProductsInCampaign",
                      "recommendationName",
                      "showSameCategory",
                      "catalog_slug",
                      "cta",
                      "productIds",
                      "buttonEnabled",
                      "banner_image",
                      "operation",
                      "value",
                      "selectorEnabled",
                      "productIds.0",
                      "priceSettings.displayComparePrice",
                      "campaignHeadlineEnabled",
                    ],
                    n = [
                      "buttonBackgroundColor",
                      "buttonBorderColor",
                      "buttonTextColor",
                      "campaignHeadlineValue",
                      "currency",
                      "imageBorderRadius",
                      "imageMarginRight",
                      "maxImageHeight",
                      "maxImageWidth",
                      "primaryLayoutBackground",
                      "secondaryLayoutBackground",
                    ],
                    i = [];
                  for (var o in e)
                    Object.hasOwnProperty.call(e, o) &&
                      (t.includes(o) && i.push(!0),
                      n.includes(o) && i.push(!1));
                  return (
                    0 <
                    i.filter(function (e) {
                      return e;
                    }).length
                  );
                },
                sendPostMessage: function (e) {
                  Z.parent.postMessage(e, "*"), Z.postMessage(e, "*");
                },
                isPropertyPersonalized: function (e, t, n) {
                  var i =
                    "we-" + (n.id + "-" + n.experimentId).replace(/~/g, "t_");
                  if (t) {
                    return (
                      null !=
                      (
                        (["before", "after"].includes(t)
                          ? e.parentElement
                          : e) || K.querySelector("html")
                      ).querySelector("#" + i + " .webengage-webp13-container")
                    );
                  }
                  return !1;
                },
                flattenObject: function (e) {
                  var t = {};
                  for (var n in e)
                    if (e.hasOwnProperty(n))
                      if ("object" == a(e[n]) && null !== e[n]) {
                        var i = l.flattenObject(e[n]);
                        for (var o in i)
                          i.hasOwnProperty(o) && (t[n + "." + o] = i[o]);
                      } else t[n] = e[n];
                  return t;
                },
                handlerDiffKeyChanges: function (e, s) {
                  var t,
                    c = u("webengage/dom"),
                    l = {
                      "6ic378c": u(
                        "webengage/web-personalization-layouts/web-personalization-6ic378c.js"
                      ),
                      "~48381b0": u(
                        "webengage/web-personalization-layouts/web-personalization-~48381b0.js"
                      ),
                      i78ece1: u(
                        "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1.js"
                      ),
                      "1af572eg": u(
                        "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg.js"
                      ),
                      "2341ibfc": u(
                        "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc.js"
                      ),
                      "~20cc4d8h": u(
                        "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h.js"
                      ),
                      "~184fc482": u(
                        "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482.js"
                      ),
                      "~fg00e76": u(
                        "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76.js"
                      ),
                      "~483856a": u(
                        "webengage/web-personalization-layouts/web-personalization-shopify-~483856a.js"
                      ),
                    };
                  function n(e) {
                    c.css.applyCss(
                      c.queryOne(
                        ".we-box-title",
                        c.queryOne(".webengage-webp13-container")
                      ),
                      { display: e && !0 === e ? "block" : "none" }
                    );
                  }
                  function i(e) {
                    c.css.applyCss(
                      c.query(
                        ".we-li-quick-actions",
                        c.queryOne(".webengage-webp13-container")
                      ),
                      { display: e && !0 === e ? "block" : "none" }
                    );
                  }
                  function o(e) {
                    var t = !0,
                      n = !1,
                      i = $;
                    try {
                      for (
                        var o,
                          a = c
                            .query(
                              ".we-add-to-cart > span",
                              c.queryOne(".webengage-webp13-container")
                            )
                            [Symbol.iterator]();
                        !(t = (o = a.next()).done);
                        t = !0
                      ) {
                        o.value.innerHTML = e;
                      }
                    } catch (e) {
                      (n = !0), (i = e);
                    } finally {
                      try {
                        !t && a.return && a.return();
                      } finally {
                        if (n) throw i;
                      }
                    }
                  }
                  function a(e) {
                    var t = !0,
                      n = !1,
                      i = $;
                    try {
                      for (
                        var o,
                          a = c
                            .query(
                              ".we-add-to-cart",
                              c.queryOne(".webengage-webp13-container")
                            )
                            [Symbol.iterator]();
                        !(t = (o = a.next()).done);
                        t = !0
                      ) {
                        var r = o.value;
                        c.css.applyCss(r, { color: e });
                      }
                    } catch (e) {
                      (n = !0), (i = e);
                    } finally {
                      try {
                        !t && a.return && a.return();
                      } finally {
                        if (n) throw i;
                      }
                    }
                  }
                  function r() {
                    u("webengage/logger").debug({
                      msg: "UPDATED STYLES OF WEB PERSONALIZATION",
                    });
                    var e,
                      t,
                      n,
                      i = s.layoutEId,
                      o = l[i],
                      a = c.queryOne("head"),
                      r = c.queryOne("#we-dynamicStyles");
                    c.remove(r),
                      (e = a),
                      (t = s),
                      (n = o.getStyles(t)),
                      c.css.createStyleNode(n, { id: "we-dynamicStyles" }, e);
                  }
                  function g() {
                    u("webengage/logger").debug({
                      msg: "UPDATED FONT FACE OF WEB PERSONALIZATION",
                    });
                    var e,
                      t,
                      n,
                      i = s.layoutEId,
                      o = l[i],
                      a = c.queryOne("head"),
                      r = c.queryOne("#we-dynamicLinks");
                    c.remove(r),
                      (e = a),
                      (t = s),
                      (n = o.getFontFace(t)),
                      e && (e.innerHTML += n);
                  }
                  for (var d in e)
                    Object.hasOwnProperty.call(e, d) &&
                      ("campaignHeadlineEnabled" === d && !1 === e[d].data
                        ? n(!1)
                        : n(!0),
                      "buttonEnabled" === d && !1 === e[d].data ? i(!1) : i(!0),
                      "campaignHeadlineValue" === d &&
                        ((t = e[d].data),
                        (c.queryOne(
                          ".we-box-title",
                          c.queryOne(".webengage-webp13-container")
                        ).innerHTML = t)),
                      "text" === d && o(e[d].data),
                      "buttonTextColor" === d && a(e[d].data),
                      ("layoutSettings.heading.font.variant" !== d &&
                        "productDescriptionSettings.font.variant" !== d &&
                        "priceSettings.font.variant" !== d &&
                        "buttonSettings.text.font.variant" !== d &&
                        "layoutSettings.heading.font.family" !== d &&
                        "productDescriptionSettings.font.family" !== d &&
                        "priceSettings.font.family" !== d &&
                        "buttonSettings.text.font.family" !== d &&
                        "buttonSettings.button.hoverColor" !== d) ||
                        (r(), g()),
                      ("css" !== d &&
                        "imageSettings.fixedHeight" !== d &&
                        "imageSettings.fixedWidth" !== d &&
                        "buttonSettings.text.color" !== d &&
                        "buttonSettings.button.color" !== d &&
                        "buttonSettings.button.border.radius" !== d &&
                        "buttonSettings.button.border.width" !== d &&
                        "buttonSettings.button.border.color" !== d &&
                        "imageSettings.width" !== d &&
                        "imageSettings.height" !== d &&
                        "priceSettings.color" !== d &&
                        "productDescriptionSettings.color" !== d &&
                        "productDescriptionSettings.font.size" !== d &&
                        "imageSettings.background.color" !== d &&
                        "layoutSettings.background.color" !== d &&
                        "layoutSettings.heading.font.size" !== d &&
                        "layoutSettings.heading.color" !== d &&
                        "layoutSettings.heading.alignment" !== d &&
                        "buttonSettings.text.font.size" !== d &&
                        "priceSettings.compareColor" !== d &&
                        "priceSettings.color" !== d &&
                        "priceSettings.font.size" !== d &&
                        "campaignHeadlineEnabled" !== d) ||
                        r());
                },
                debounce: function (i, o) {
                  var a = void 0;
                  return function () {
                    for (
                      var e = arguments.length, t = Array(e), n = 0;
                      n < e;
                      n++
                    )
                      t[n] = arguments[n];
                    clearTimeout(a),
                      (a = setTimeout(function () {
                        clearTimeout(a), i.apply($, t);
                      }, o));
                  };
                },
                getMessageDiff: function (e, t) {
                  var n = l.flattenObject(
                      l.deepDiffMapper.map(e.data.config, t.data.config)
                    ),
                    i = l.flattenObject(
                      l.deepDiffMapper.map(
                        e.data.layoutAttributes.dom_id,
                        t.data.layoutAttributes.dom_id
                      )
                    ),
                    o = l.clone(n || {}, i || {}),
                    a = {};
                  if (o)
                    for (var r in o)
                      if (Object.hasOwnProperty.call(o, r)) {
                        var s = r.replace(/(\.type|\.data)/g, "");
                        a[s] === $ && (a[s] = {}),
                          r.endsWith(".type") && (a[s].type = o[r]),
                          r.endsWith(".data") && (a[s].data = o[r]);
                      }
                  for (var c in a)
                    Object.hasOwnProperty.call(a, c) &&
                      "unchanged" === a[c].type &&
                      delete a[c];
                  return a;
                },
              };
            e.exports = l;
          },
          {
            "webengage/web-personalization-layouts/web-personalization-6ic378c.js":
              "webengage/web-personalization-layouts/web-personalization-6ic378c",
            "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg",
            "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc",
            "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1",
            "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482",
            "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h",
            "webengage/web-personalization-layouts/web-personalization-shopify-~483856a.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~483856a",
            "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76",
            "webengage/web-personalization-layouts/web-personalization-~48381b0.js":
              "webengage/web-personalization-layouts/web-personalization-~48381b0",
          },
        ],
        "webengage/util/compress": [
          function (e, t, n) {
            "use strict";
            var w = {
              _keyStr:
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
              _f: String.fromCharCode,
              compressToBase64: function (e) {
                if (null == e) return "";
                var t,
                  n,
                  i,
                  o,
                  a,
                  r,
                  s,
                  c = "",
                  l = 0;
                for (e = w.compress(e); l < 2 * e.length; )
                  l % 2 == 0
                    ? ((t = e.charCodeAt(l / 2) >> 8),
                      (n = 255 & e.charCodeAt(l / 2)),
                      (i =
                        l / 2 + 1 < e.length
                          ? e.charCodeAt(l / 2 + 1) >> 8
                          : NaN))
                    : ((t = 255 & e.charCodeAt((l - 1) / 2)),
                      (l + 1) / 2 < e.length
                        ? ((n = e.charCodeAt((l + 1) / 2) >> 8),
                          (i = 255 & e.charCodeAt((l + 1) / 2)))
                        : (n = i = NaN)),
                    (l += 3),
                    (o = t >> 2),
                    (a = ((3 & t) << 4) | (n >> 4)),
                    (r = ((15 & n) << 2) | (i >> 6)),
                    (s = 63 & i),
                    isNaN(n) ? (r = s = 64) : isNaN(i) && (s = 64),
                    (c =
                      c +
                      w._keyStr.charAt(o) +
                      w._keyStr.charAt(a) +
                      w._keyStr.charAt(r) +
                      w._keyStr.charAt(s));
                return c;
              },
              decompressFromBase64: function (e) {
                if (null == e) return "";
                var t,
                  n,
                  i,
                  o,
                  a,
                  r,
                  s,
                  c = "",
                  l = 0,
                  g = 0,
                  d = w._f;
                for (e = e.replace(/[^A-Za-z0-9\+\/\=]/g, ""); g < e.length; )
                  (n =
                    (w._keyStr.indexOf(e.charAt(g++)) << 2) |
                    ((a = w._keyStr.indexOf(e.charAt(g++))) >> 4)),
                    (i =
                      ((15 & a) << 4) |
                      ((r = w._keyStr.indexOf(e.charAt(g++))) >> 2)),
                    (o =
                      ((3 & r) << 6) | (s = w._keyStr.indexOf(e.charAt(g++)))),
                    l % 2 == 0
                      ? ((t = n << 8),
                        64 != r && (c += d(t | i)),
                        64 != s && (t = o << 8))
                      : ((c += d(t | n)),
                        64 != r && (t = i << 8),
                        64 != s && (c += d(t | o))),
                    (l += 3);
                return w.decompress(c);
              },
              compress: function (e) {
                if (null == e) return "";
                var t,
                  n,
                  i,
                  o = {},
                  a = {},
                  r = "",
                  s = "",
                  c = "",
                  l = 2,
                  g = 3,
                  d = 2,
                  u = "",
                  p = 0,
                  f = 0,
                  b = w._f;
                for (i = 0; i < e.length; i += 1)
                  if (
                    ((r = e.charAt(i)),
                    Object.prototype.hasOwnProperty.call(o, r) ||
                      ((o[r] = g++), (a[r] = !0)),
                    (s = c + r),
                    Object.prototype.hasOwnProperty.call(o, s))
                  )
                    c = s;
                  else {
                    if (Object.prototype.hasOwnProperty.call(a, c)) {
                      if (c.charCodeAt(0) < 256) {
                        for (t = 0; t < d; t++)
                          (p <<= 1),
                            15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++;
                        for (n = c.charCodeAt(0), t = 0; t < 8; t++)
                          (p = (p << 1) | (1 & n)),
                            15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++,
                            (n >>= 1);
                      } else {
                        for (n = 1, t = 0; t < d; t++)
                          (p = (p << 1) | n),
                            15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++,
                            (n = 0);
                        for (n = c.charCodeAt(0), t = 0; t < 16; t++)
                          (p = (p << 1) | (1 & n)),
                            15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++,
                            (n >>= 1);
                      }
                      0 == --l && ((l = Math.pow(2, d)), d++), delete a[c];
                    } else
                      for (n = o[c], t = 0; t < d; t++)
                        (p = (p << 1) | (1 & n)),
                          15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++,
                          (n >>= 1);
                    0 == --l && ((l = Math.pow(2, d)), d++),
                      (o[s] = g++),
                      (c = String(r));
                  }
                if ("" !== c) {
                  if (Object.prototype.hasOwnProperty.call(a, c)) {
                    if (c.charCodeAt(0) < 256) {
                      for (t = 0; t < d; t++)
                        (p <<= 1),
                          15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++;
                      for (n = c.charCodeAt(0), t = 0; t < 8; t++)
                        (p = (p << 1) | (1 & n)),
                          15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++,
                          (n >>= 1);
                    } else {
                      for (n = 1, t = 0; t < d; t++)
                        (p = (p << 1) | n),
                          15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++,
                          (n = 0);
                      for (n = c.charCodeAt(0), t = 0; t < 16; t++)
                        (p = (p << 1) | (1 & n)),
                          15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++,
                          (n >>= 1);
                    }
                    0 == --l && ((l = Math.pow(2, d)), d++), delete a[c];
                  } else
                    for (n = o[c], t = 0; t < d; t++)
                      (p = (p << 1) | (1 & n)),
                        15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++,
                        (n >>= 1);
                  0 == --l && ((l = Math.pow(2, d)), d++);
                }
                for (n = 2, t = 0; t < d; t++)
                  (p = (p << 1) | (1 & n)),
                    15 == f ? ((f = 0), (u += b(p)), (p = 0)) : f++,
                    (n >>= 1);
                for (;;) {
                  if (((p <<= 1), 15 == f)) {
                    u += b(p);
                    break;
                  }
                  f++;
                }
                return u;
              },
              decompress: function (e) {
                if (null == e) return "";
                if ("" == e) return null;
                var t,
                  n,
                  i,
                  o,
                  a,
                  r,
                  s,
                  c = [],
                  l = 4,
                  g = 4,
                  d = 3,
                  u = "",
                  p = "",
                  f = w._f,
                  b = {
                    string: e,
                    val: e.charCodeAt(0),
                    position: 32768,
                    index: 1,
                  };
                for (t = 0; t < 3; t += 1) c[t] = t;
                for (i = 0, a = Math.pow(2, 2), r = 1; r != a; )
                  (o = b.val & b.position),
                    (b.position >>= 1),
                    0 == b.position &&
                      ((b.position = 32768),
                      (b.val = b.string.charCodeAt(b.index++))),
                    (i |= (0 < o ? 1 : 0) * r),
                    (r <<= 1);
                switch (i) {
                  case 0:
                    for (i = 0, a = Math.pow(2, 8), r = 1; r != a; )
                      (o = b.val & b.position),
                        (b.position >>= 1),
                        0 == b.position &&
                          ((b.position = 32768),
                          (b.val = b.string.charCodeAt(b.index++))),
                        (i |= (0 < o ? 1 : 0) * r),
                        (r <<= 1);
                    s = f(i);
                    break;
                  case 1:
                    for (i = 0, a = Math.pow(2, 16), r = 1; r != a; )
                      (o = b.val & b.position),
                        (b.position >>= 1),
                        0 == b.position &&
                          ((b.position = 32768),
                          (b.val = b.string.charCodeAt(b.index++))),
                        (i |= (0 < o ? 1 : 0) * r),
                        (r <<= 1);
                    s = f(i);
                    break;
                  case 2:
                    return "";
                }
                for (n = p = c[3] = s; ; ) {
                  if (b.index > b.string.length) return "";
                  for (i = 0, a = Math.pow(2, d), r = 1; r != a; )
                    (o = b.val & b.position),
                      (b.position >>= 1),
                      0 == b.position &&
                        ((b.position = 32768),
                        (b.val = b.string.charCodeAt(b.index++))),
                      (i |= (0 < o ? 1 : 0) * r),
                      (r <<= 1);
                  switch ((s = i)) {
                    case 0:
                      for (i = 0, a = Math.pow(2, 8), r = 1; r != a; )
                        (o = b.val & b.position),
                          (b.position >>= 1),
                          0 == b.position &&
                            ((b.position = 32768),
                            (b.val = b.string.charCodeAt(b.index++))),
                          (i |= (0 < o ? 1 : 0) * r),
                          (r <<= 1);
                      (c[g++] = f(i)), (s = g - 1), l--;
                      break;
                    case 1:
                      for (i = 0, a = Math.pow(2, 16), r = 1; r != a; )
                        (o = b.val & b.position),
                          (b.position >>= 1),
                          0 == b.position &&
                            ((b.position = 32768),
                            (b.val = b.string.charCodeAt(b.index++))),
                          (i |= (0 < o ? 1 : 0) * r),
                          (r <<= 1);
                      (c[g++] = f(i)), (s = g - 1), l--;
                      break;
                    case 2:
                      return p;
                  }
                  if ((0 == l && ((l = Math.pow(2, d)), d++), c[s])) u = c[s];
                  else {
                    if (s !== g) return null;
                    u = n + n.charAt(0);
                  }
                  (p += u),
                    (c[g++] = n + u.charAt(0)),
                    (n = u),
                    0 == --l && ((l = Math.pow(2, d)), d++);
                }
              },
            };
            t.exports = w;
          },
          {},
        ],
        "webengage/util/curry-bind": [
          function (e, t, n) {
            "use strict";
            var i = Array.prototype.slice;
            function o(e, t, n) {
              return function () {
                return e.apply(t, n.concat(i.call(arguments)));
              };
            }
            function a(e) {
              return o(e, null, i.call(arguments, 1));
            }
            (a.bind = function (e, t) {
              return o(e, t, i.call(arguments, 2));
            }),
              (t.exports = a);
          },
          {},
        ],
        "webengage/util": [
          function (e, t, n) {
            "use strict";
            var i = e("webengage/util/bare");
            (i.compress = e("webengage/util/compress")),
              (i.sha1 = e("webengage/util/sha1")),
              (i.transit = e("webengage/util/transit")),
              (i.type = e("webengage/util/type")),
              (i.curry = e("webengage/util/curry-bind")),
              (t.exports = i);
          },
          {},
        ],
        "webengage/util/sha1": [
          function (e, t, n) {
            "use strict";
            t.exports = function (e) {
              function t(e, t, n, i) {
                switch (e) {
                  case 0:
                    return (t & n) ^ (~t & i);
                  case 1:
                    return t ^ n ^ i;
                  case 2:
                    return (t & n) ^ (t & i) ^ (n & i);
                  case 3:
                    return t ^ n ^ i;
                }
              }
              function n(e, t) {
                return (e << t) | (e >>> (32 - t));
              }
              function i(e) {
                for (var t = "", n = 7; 0 <= n; n--)
                  t += ((e >>> (4 * n)) & 15).toString(16);
                return t;
              }
              e = unescape(encodeURIComponent(e));
              for (
                var o = [1518500249, 1859775393, 2400959708, 3395469782],
                  a = (e += String.fromCharCode(128)).length / 4 + 2,
                  r = Math.ceil(a / 16),
                  s = new Array(r),
                  c = 0;
                c < r;
                c++
              ) {
                s[c] = new Array(16);
                for (var l = 0; l < 16; l++)
                  s[c][l] =
                    (e.charCodeAt(64 * c + 4 * l) << 24) |
                    (e.charCodeAt(64 * c + 4 * l + 1) << 16) |
                    (e.charCodeAt(64 * c + 4 * l + 2) << 8) |
                    e.charCodeAt(64 * c + 4 * l + 3);
              }
              (s[r - 1][14] = (8 * (e.length - 1)) / Math.pow(2, 32)),
                (s[r - 1][14] = Math.floor(s[r - 1][14])),
                (s[r - 1][15] = (8 * (e.length - 1)) & 4294967295);
              var g,
                d,
                u,
                p,
                f,
                b = 1732584193,
                w = 4023233417,
                m = 2562383102,
                h = 271733878,
                v = 3285377520,
                y = new Array(80);
              for (c = 0; c < r; c++) {
                for (var x = 0; x < 16; x++) y[x] = s[c][x];
                for (x = 16; x < 80; x++)
                  y[x] = n(y[x - 3] ^ y[x - 8] ^ y[x - 14] ^ y[x - 16], 1);
                (g = b), (d = w), (u = m), (p = h), (f = v);
                for (x = 0; x < 80; x++) {
                  var E = Math.floor(x / 20),
                    _ =
                      (n(g, 5) + t(E, d, u, p) + f + o[E] + y[x]) & 4294967295;
                  (f = p), (p = u), (u = n(d, 30)), (d = g), (g = _);
                }
                (b = (b + g) & 4294967295),
                  (w = (w + d) & 4294967295),
                  (m = (m + u) & 4294967295),
                  (h = (h + p) & 4294967295),
                  (v = (v + f) & 4294967295);
              }
              return i(b) + i(w) + i(m) + i(h) + i(v);
            };
          },
          {},
        ],
        "webengage/util/transit": [
          function (e, t, n) {
            "use strict";
            var r = e("webengage/util/type"),
              s = e("webengage/util/bare"),
              i = {
                encode: function (e) {
                  return (function e(t, n) {
                    var i;
                    if (((n = n ? n.slice() : []), null === t)) return null;
                    if ("string" === r(t))
                      return "~" == t.charAt(0) ? "~" + t : t;
                    if ("date" === r(t)) return "~t" + s.toDateISOString(t);
                    if ("array" === r(t)) {
                      i = [];
                      for (var o = 0; o < t.length; o++) i[o] = e(t[o], n);
                      return i;
                    }
                    if ("object" !== r(t)) return t;
                    if (-1 != s.indexOfArray(n, t))
                      throw new Error(
                        "Encountered circular references while encoding data in transit format"
                      );
                    for (var a in (n.push(t), (i = {}), t))
                      t.hasOwnProperty(a) && (i[e(a)] = e(t[a], n));
                    return i;
                  })(e);
                },
                decode: function (e) {
                  return (function e(t) {
                    var n;
                    if (null === t) return null;
                    if ("string" === r(t))
                      return 0 === t.indexOf("~t")
                        ? s.fromDateISOString(t.substr(2))
                        : 0 === t.indexOf("~~")
                        ? t.substr(1)
                        : t;
                    if ("array" === r(t)) {
                      n = [];
                      for (var i = 0; i < t.length; i++) n[i] = e(t[i]);
                      return n;
                    }
                    if ("object" !== r(t)) return t;
                    for (var o in ((n = {}), t))
                      t.hasOwnProperty(o) && (n[e(o)] = e(t[o]));
                    return n;
                  })(e);
                },
              };
            t.exports = i;
          },
          {},
        ],
        "webengage/util/type": [
          function (e, t, n) {
            "use strict";
            var i = Object.prototype.toString;
            t.exports = function (e) {
              var t = i.call(e);
              switch (t) {
                case "[object String]":
                  return "string";
                case "[object Number]":
                  return "number";
                case "[object Boolean]":
                  return "boolean";
                case "[object Date]":
                  return "date";
                case "[object Array]":
                  return "array";
                case "[object Function]":
                  return "function";
                case "[object RegExp]":
                  return "regexp";
                case "[object Arguments]":
                  return "arguments";
              }
              return null === e
                ? "null"
                : e === $
                ? "undefined"
                : "[object Object]" === t
                ? "object"
                : t.slice(8, -1);
            };
          },
          {},
        ],
        "webengage/web-personalization-layouts/web-personalization-6ic378c": [
          function (e, t, n) {
            "use strict";
            t.exports = {
              getMarkUp: function (e) {
                if (!e || !e.customCode)
                  throw new Error("WEB PERSONALIZATIONS LAYOUT DATA MISSING");
                return (
                  '<div class="webengage-webp13-container"><div class="webengage-webp13-custom-code-container">' +
                  e.customCode +
                  "</div></div>"
                );
              },
              getStyles: function (e) {
                return "";
              },
            };
          },
          {},
        ],
        "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg":
          [
            function (e, t, n) {
              "use strict";
              t.exports = {
                getMarkUp: e("./web-personalization-shopify-~184fc482")
                  .getMarkUp,
                getStyles: e("./web-personalization-shopify-~184fc482")
                  .getStyles,
                getScripts: e("./web-personalization-shopify-~184fc482")
                  .getScripts,
                getFontFace: e("./web-personalization-shopify-~184fc482")
                  .getFontFace,
              };
            },
            {
              "./web-personalization-shopify-~184fc482":
                "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482",
            },
          ],
        "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc":
          [
            function (e, t, n) {
              "use strict";
              t.exports = {
                getMarkUp: e("./web-personalization-shopify-~184fc482")
                  .getMarkUp,
                getStyles: e("./web-personalization-shopify-~184fc482")
                  .getStyles,
                getScripts: e("./web-personalization-shopify-~184fc482")
                  .getScripts,
                getFontFace: e("./web-personalization-shopify-~184fc482")
                  .getFontFace,
              };
            },
            {
              "./web-personalization-shopify-~184fc482":
                "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482",
            },
          ],
        "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1":
          [
            function (e, t, n) {
              "use strict";
              t.exports = {
                getMarkUp: function (e) {
                  if (!e || !e.layoutAttributes)
                    throw new Error("WEB PERSONALIZATIONS LAYOUT DATA MISSING");
                  var t,
                    n,
                    i,
                    o = (t = !0 === e.isPreview ? e.config : e.layoutAttributes)
                      .webP13BannerId;
                  if (e.actions && e.actions.length)
                    for (var a = 0, r = e.actions.length; a < r; a++)
                      if (e.actions[a].isPrime) {
                        e.actions[a].actionText,
                          (n = e.actions[a].actionEId),
                          (i = e.actions[a].actionLink);
                        break;
                      }
                  var s = t.banner_image && t.banner_image.imageUrl,
                    c = t.banner_image && t.banner_image.mImageUrl;
                  return (
                    "<div id=" +
                    o +
                    '><div class="webengage-webp13-container prime"><div ' +
                    (i
                      ? "id='" +
                        n +
                        "' data-action-id='" +
                        n +
                        "' class='callToAction'"
                      : "") +
                    ">" +
                    (e.customCode
                      ? t.isImageResponsive
                        ? '<div class="webengage-webp13-custom-code-container">\n\t\t\t\t\t\t' +
                          e.customCode +
                          "\n\t\t\t\t\t</div>\n\t\t\t\t\t<img src=" +
                          s +
                          ' class="webengage-webp13-image" />\n\t\t\t\t'
                        : c
                        ? '<div class="webengage-webp13-custom-code-container">\n\t\t\t\t\t' +
                          e.customCode +
                          '\n\t\t\t\t</div>\n\t\t\t\t<picture>\n\t\t\t\t\t<source media="(max-width: 768px)" srcset=' +
                          c +
                          ">\n\t\t\t\t\t<img src=" +
                          s +
                          ' class="webengage-webp13-image " />\n\t\t\t\t</picture>'
                        : '<div class="webengage-webp13-custom-code-container">\n\t\t\t\t\t\t' +
                          e.customCode +
                          "\n\t\t\t\t\t</div>\n\t\t\t\t\t<img src=" +
                          s +
                          ' class="webengage-webp13-image" />\n\t\t\t\t'
                      : t.isImageResponsive
                      ? "<img src=" + s + ' class="webengage-webp13-image " />'
                      : c
                      ? '<picture>\n\t\t\t\t<source media="(max-width: 768px)" srcset=' +
                        c +
                        ">\n\t\t\t\t<img src=" +
                        s +
                        ' class="webengage-webp13-image " />\n\t\t\t</picture>'
                      : "<img src=" +
                        s +
                        ' class="webengage-webp13-image " />') +
                    "</div></div></div>"
                  );
                },
                getStyles: function (e) {
                  var t;
                  if (!0 === e.isPreview)
                    var n =
                        (t = e.config) && t.banner_image && t.banner_image.width
                          ? parseInt(t.banner_image.width) + "px"
                          : null,
                      i = t.show_rounded_corner || "false",
                      o = "max-width: 100%;",
                      a = t.webP13BannerId,
                      r = (t && t.css) || "";
                  else
                    (n =
                      (t = e.layoutAttributes) &&
                      t.banner_image &&
                      t.banner_image.width
                        ? parseInt(t.banner_image.width) + "px"
                        : null),
                      (i = t.show_rounded_corner || "false"),
                      (o = "max-width: 100%;"),
                      (a = t.webP13BannerId),
                      (r = (e && e.config && e.config.css) || "");
                  return (
                    n && (o = "max-width: " + n + ";"),
                    "#" +
                      a +
                      " .webengage-webp13-container {position: relative;overflow: hidden;width: 100%;height: 100%;" +
                      o +
                      "}\n#" +
                      a +
                      " .webengage-webp13-custom-code-container {position: absolute;top: 50%;left: 0;right: 0;-webkit-transform: perspective(1px) translateY(-50%);transform: perspective(1px) translateY(-50%);padding: 40px;z-index: 1;}\n#" +
                      a +
                      " .prime {width: 100%;height: 100%;}\n.callToAction {cursor: pointer;}\n#" +
                      a +
                      " .webengage-webp13-image {display: block;width: 100%;" +
                      o +
                      ("true" === i
                        ? "border-radius:5px;"
                        : "border-radius:none;") +
                      "}" +
                      r
                  );
                },
              };
            },
            {},
          ],
        "webengage/web-personalization-layouts/web-personalization-shopify-m~184fc482":
          [
            function (e, t, n) {
              "use strict";
              e("webengage/colors");
              var C = e("webengage/events"),
                I = e("webengage/logger"),
                T =
                  (e("webengage/util"),
                  e("webengage/comm"),
                  e("webengage/logger"),
                  e("webengage/weq"),
                  e("webengage/dom")),
                g = e("webengage/animate");
              t.exports = {
                getMarkUp: function (e) {
                  if (!e || !e.customCode)
                    throw new Error("WEB PERSONALIZATIONS LAYOUT DATA MISSING");
                  var t =
                    "we-" + (e.experimentId + "-" + e.id).replace(/~/g, "t_");
                  return (
                    "<div id=" +
                    t +
                    ' class="webengage-webp13-container"><div class="webengage-webp13-container-shopify" data-box-id="' +
                    t +
                    '">' +
                    e.customCode +
                    "</div></div>"
                  );
                },
                getStyles: function (e) {
                  return "";
                },
                getScripts: function (e) {
                  I.debug({ msg: "WEB PERSONALIZATIONS LAYOUT JS", ctx: e });
                  var t,
                    f = e.layoutAttributes,
                    b =
                      "we-" + (e.experimentId + "-" + e.id).replace(/~/g, "t_"),
                    w = (f.cta, f.boxStyle || "carousel"),
                    i = f.NavigationArrowMode || "static",
                    m = f.NavigationArrowType || "circleFull",
                    h = f.maxImageHeight || 300,
                    v = f.autoScrollInterval || 0,
                    l = function (e, t) {
                      I.debug({
                        msg: "WEB PERSONALIZATIONS LAYOUT SHOPIFY METHODS ADD CART",
                        ctx: { data: e },
                      }),
                        fetch((Z.Shopify.routes.root || "/") + "cart/add.js", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify(e),
                        })
                          .then(function (e) {
                            return e.ok
                              ? t(null, e.json())
                              : 422 === e.status
                              ? t(!0, null)
                              : t(!1, null);
                          })
                          .catch(function (e) {
                            return (
                              I.debug({ msg: "catch", ctx: {} }),
                              I.error({
                                msg: "FAILED TO ADD PRODUCT TO CART",
                                ctx: { message: e.message, stack: e.stack },
                              }),
                              t(e, null)
                            );
                          });
                    },
                    y = function () {
                      return {
                        get: function () {
                          return '\n\t\t\t\t\t\t<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">\n\t\t\t\t\t\t\t<path d="M24.8894 14.7514L10.649 0.511215C10.3196 0.181592 9.87994 0 9.41113 0C8.94232 0 8.50265 0.181592 8.17329 0.511215L7.12458 1.55966C6.44218 2.24284 6.44218 3.35321 7.12458 4.03535L19.0826 15.9934L7.11131 27.9646C6.78195 28.2943 6.6001 28.7337 6.6001 29.2022C6.6001 29.6713 6.78195 30.1107 7.11131 30.4406L8.16002 31.4888C8.48964 31.8184 8.92905 32 9.39786 32C9.86667 32 10.3063 31.8184 10.6357 31.4888L24.8894 17.2356C25.2195 16.905 25.4009 16.4635 25.3998 15.9941C25.4009 15.523 25.2195 15.0818 24.8894 14.7514Z" fill="black"/>\n\t\t\t\t\t\t</svg>';
                        },
                      };
                    },
                    x = function (c) {
                      I.debug({
                        msg: "WEB PERSONALIZATIONS LAYOUT ATTACHING BUTTON CLICK HANDLER",
                        ctx: { action: c },
                      });
                      var e = function (a) {
                          var r = a.querySelector(".we-add-to-cart");
                          if (r) {
                            var s = r.querySelector(".we-text-button-clam");
                            (r.doAction = !1),
                              (r.isBind = r.isBind || !1),
                              r &&
                                "boolean" == typeof r.isBind &&
                                !1 === r.isBind &&
                                ((r.isBind = !0),
                                C.bind(r, "click", function (e) {
                                  e.preventDefault
                                    ? e.preventDefault()
                                    : (e.returnValue = !1);
                                  var t = {
                                    items: [
                                      {
                                        id: a.getAttribute(
                                          "data-product-identifier"
                                        ),
                                        quantity: 1,
                                      },
                                    ],
                                  };
                                  if ("Add to Cart" === c) {
                                    (r.disabled = !0),
                                      console.log("buttonElement", r, {
                                        doAction: r.doAction,
                                      });
                                    var n = T.createElement(
                                        "span",
                                        '<svg class="we-svg-spinner" width="20px" height="20px" viewBox="25 25 50 50"><circle class="we-circle-spinner" r="20" cy="50" cx="50"></circle></svg>'
                                      ),
                                      i = T.createElement(
                                        "span",
                                        '<svg class="we-tick" width="20px" height="20px" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\n\t\t<path d="M10 0C4.486 0 0 4.486 0 10C0 15.514 4.486 20 10 20C15.514 20 20 15.514 20 10C20 4.486 15.514 0 10 0ZM10 18.1818C5.48848 18.1818 1.81818 14.5115 1.81818 10C1.81818 5.48855 5.48848 1.81818 10 1.81818C14.5115 1.81818 18.1818 5.48855 18.1818 10C18.1818 14.5115 14.5115 18.1818 10 18.1818Z" fill="white"/>\n\t\t<path d="M13.7498 6.46448L8.60712 11.6071L6.25015 9.25006C5.89518 8.89509 5.31955 8.89503 4.96451 9.25C4.60948 9.60503 4.60948 10.1806 4.96451 10.5356L7.96427 13.5355C8.13476 13.706 8.36597 13.8018 8.60706 13.8018H8.60712C8.84821 13.8018 9.07942 13.706 9.24991 13.5356L15.0354 7.75018C15.3905 7.39515 15.3905 6.81958 15.0354 6.46455C14.6804 6.10951 14.1048 6.10945 13.7498 6.46448Z" fill="white"/>\n\t\t</svg>'
                                      ),
                                      o = T.createElement("span", "");
                                    if (
                                      ((n.className = "we-text-button-clam"),
                                      (i.className = "we-text-button-clam"),
                                      (o.className = "we-text-button-clam"),
                                      r && !0 === r.doAction)
                                    )
                                      return void (Z.location = "/cart");
                                    s.remove(),
                                      r.appendChild(n),
                                      l(t, function (e, t) {
                                        (r.doAction = !0),
                                          I.debug({
                                            msg: "ADDED TO CART CALLED",
                                            ctx: { err: e, data: t },
                                          }),
                                          g.fadeOut(n, function () {
                                            n.remove(),
                                              r.appendChild(i),
                                              g.fadeIn(i, function () {
                                                g.fadeOut(i, function () {
                                                  "boolean" == typeof e &&
                                                  !0 === e
                                                    ? ((o.innerHTML =
                                                        "Out of Stock"),
                                                      (r.disabled = !0),
                                                      T.css.applyCss(r, {
                                                        "background-color":
                                                          "#D0D5DD",
                                                      }))
                                                    : ((o.innerHTML =
                                                        "View Cart"),
                                                      (r.disabled = !1)),
                                                    i.remove(),
                                                    r.appendChild(o),
                                                    g.fadeIn(o, function () {});
                                                });
                                              });
                                          });
                                      });
                                  }
                                  "Redirect to checkout" === c
                                    ? (I.debug({
                                        msg: "---REDIRECT -----",
                                        ctx: { action: c },
                                      }),
                                      setTimeout(function () {
                                        K.location.href = "/checkout";
                                      }, 1e3))
                                    : "Redirect to cart" === c &&
                                      (I.debug({
                                        msg: "---REDIRECT -----",
                                        ctx: { action: c },
                                      }),
                                      setTimeout(function () {
                                        K.location.href = "/cart";
                                      }, 1e3));
                                }));
                          }
                        },
                        t = !0,
                        n = !1,
                        i = $;
                      try {
                        for (
                          var o,
                            a = K.querySelectorAll(
                              "#" + b + " .webengage-recommendation-box-item"
                            )[Symbol.iterator]();
                          !(t = (o = a.next()).done);
                          t = !0
                        )
                          e(o.value);
                      } catch (e) {
                        (n = !0), (i = e);
                      } finally {
                        try {
                          !t && a.return && a.return();
                        } finally {
                          if (n) throw i;
                        }
                      }
                    },
                    o = function (e) {
                      var t = e.box,
                        n = e.type,
                        i = e.visible,
                        o = T.queryOne(
                          "left" === n ? ".we-left-arrow" : ".we-right-arrow",
                          t
                        );
                      o &&
                        (o.classList.add("we-animate"),
                        i
                          ? o.classList.remove("we-animate-hide")
                          : o.classList.add("we-animate-hide"));
                    },
                    a = function (e) {
                      var t = e.box,
                        n = e.type,
                        i = e.left,
                        o = t.querySelector(".we-ul-container");
                      return "left" === n
                        ? 0 < (isNaN(i) ? o.scrollLeft : i)
                        : (isNaN(i) ? o.scrollLeft : i) + o.clientWidth <
                            o.scrollWidth;
                    };
                  function E(e) {
                    var t = e.box,
                      n = e.left;
                    t &&
                      "carousel" === w &&
                      (t.clientWidth,
                      Z.innerWidth,
                      T.query(".we-left-arrow, .we-right-arrow", t).forEach(
                        function (e) {
                          t.clientWidth + 100 > Z.innerWidth || "static" === i
                            ? e.classList.add("static-arrow")
                            : e.classList.remove("static-arrow");
                        }
                      ),
                      o({
                        box: t,
                        type: "left",
                        visible: a({ box: t, type: "left", left: n }),
                      }),
                      o({
                        box: t,
                        type: "right",
                        visible: a({ box: t, type: "right", left: n }),
                      }));
                  }
                  function _(a, r, e, s) {
                    I.debug({
                      msg: "WEB PERSONALIZATIONS LAYOUT scrollLeft",
                      ctx: { element: a, offset: r, options: e },
                    }),
                      "function" == typeof (e = e || {}) && ((s = e), (e = {})),
                      "function" != typeof s && (s = function () {});
                    var c = Date.now(),
                      l = a.scrollLeft,
                      g =
                        e.ease ||
                        function (e) {
                          return 0.5 * (1 - Math.cos(Math.PI * e));
                        },
                      d = isNaN(e.duration) ? 350 : +e.duration,
                      u = !1;
                    return l === r
                      ? s(
                          new Error(
                            "Element already at target scroll position",
                            a.scrollLeft
                          )
                        )
                      : (requestAnimationFrame(function e(t) {
                          if (u)
                            return s(
                              new Error("Scroll cancelled"),
                              a.scrollLeft
                            );
                          var n = Date.now(),
                            i = Math.min(1, (n - c) / d),
                            o = g(i);
                          (a.scrollLeft = o * (r - l) + l),
                            i < 1
                              ? requestAnimationFrame(e)
                              : requestAnimationFrame(function () {
                                  return s(null, a.scrollLeft);
                                });
                        }),
                        function () {
                          u = !0;
                        });
                  }
                  function S(e) {
                    var t = e.querySelector(".we-ul-container"),
                      n = e.querySelector(".we-ul"),
                      i = void 0,
                      o = !0,
                      a = !1,
                      r = $;
                    try {
                      for (
                        var s,
                          c = t
                            .querySelectorAll(
                              ".webengage-recommendation-box-item"
                            )
                            [Symbol.iterator]();
                        !(o = (s = c.next()).done);
                        o = !0
                      ) {
                        i = s.value;
                        var l =
                            parseInt(Z.getComputedStyle(i).marginRight, 10) +
                            parseInt(Z.getComputedStyle(i).marginLeft, 10),
                          g = i.offsetLeft - t.scrollLeft,
                          d = Math.max(t.clientWidth, i.clientWidth + l);
                        if (
                          (Math.round(g) < 100 && (g = -20),
                          0 <= g + i.clientWidth - d)
                        )
                          break;
                      }
                    } catch (e) {
                      (a = !0), (r = e);
                    } finally {
                      try {
                        !o && c.return && c.return();
                      } finally {
                        if (a) throw r;
                      }
                    }
                    var u = Math.min(
                      i.offsetLeft - n.offsetLeft,
                      t.scrollWidth - t.clientWidth
                    );
                    _(t, u, null, function () {
                      return E({ box: e, left: u });
                    });
                  }
                  t = setInterval(function () {
                    var e = K.getElementById(b);
                    if (e)
                      try {
                        I.debug({
                          msg: "WEB PERSONALIZATIONS LAYOUT INIT SETUP",
                        }),
                          (function (e) {
                            I.debug({
                              msg: "WEB PERSONALIZATIONS LAYOUT SETUP",
                              ctx: e,
                            });
                            var d = e.box;
                            d.themeOptions = f;
                            var t = T.queryOne(".we-ul", d),
                              n = "true" === d.themeOptions.fullPage,
                              i = t.children[0];
                            i && i.currentStyle
                              ? i.currentStyle
                              : Z.getComputedStyle(i),
                              x(f.cta);
                            var o = T.queryOne(".we-left-arrow", d),
                              a = T.queryOne(".we-right-arrow", d),
                              r = (h || 300) / 2 - 20;
                            o &&
                              (T.queryOne("#" + b + " .we-link-media") ||
                                T.css.applyCss(o, {
                                  "margin-top": r + "px",
                                  "max-width": "50 px",
                                }),
                              (o.children[0].onclick = function (e) {
                                var t = T.queryOne(".we-ul-container", d),
                                  n = T.queryOne(".we-ul", d),
                                  i = void 0,
                                  o = !0,
                                  a = !1,
                                  r = $;
                                try {
                                  for (
                                    var s,
                                      c = T.query(
                                        ".webengage-recommendation-box-item",
                                        d
                                      )[Symbol.iterator]();
                                    !(o = (s = c.next()).done);
                                    o = !0
                                  ) {
                                    i = s.value;
                                    var l =
                                      parseInt(
                                        Z.getComputedStyle(i).marginRight,
                                        10
                                      ) +
                                      parseInt(
                                        Z.getComputedStyle(i).marginLeft,
                                        10
                                      );
                                    if (
                                      0 <=
                                      i.offsetLeft -
                                        t.scrollLeft +
                                        l +
                                        Math.max(
                                          t.clientWidth,
                                          i.clientWidth + l
                                        )
                                    )
                                      break;
                                  }
                                } catch (e) {
                                  (a = !0), (r = e);
                                } finally {
                                  try {
                                    !o && c.return && c.return();
                                  } finally {
                                    if (a) throw r;
                                  }
                                }
                                var g = Math.max(
                                  i.offsetLeft - n.offsetLeft,
                                  0
                                );
                                _(t, g, null, function () {
                                  return E({ box: d, left: g });
                                });
                              }),
                              0 <=
                                o.children[0].className.indexOf(
                                  "we-svg-arrow"
                                ) &&
                                (o.children[0].innerHTML = y().get(
                                  m || "strikingChevron"
                                ))),
                              a &&
                                (T.queryOne("#" + b + " .we-link-media") ||
                                  T.css.applyCss(a, {
                                    "margin-top": r + "px",
                                    "max-width": "50 px",
                                  }),
                                (a.children[0].onclick = function (e) {
                                  return S(d);
                                }),
                                0 <=
                                  a.children[0].className.indexOf(
                                    "we-svg-arrow"
                                  ) &&
                                  (a.children[0].innerHTML = y().get(
                                    m || "strikingChevron"
                                  )));
                            var s,
                              c,
                              l,
                              g = T.queryOne(".we-ul-container", d),
                              u =
                                ((s = function () {
                                  return E({ box: d });
                                }),
                                (l = !(c = 300)),
                                function () {
                                  l ||
                                    (s.apply($, arguments),
                                    (l = !0),
                                    setTimeout(function () {
                                      l = !1;
                                    }, c));
                                });
                            C.bind(Z, "wheel", u, { passive: !0 }),
                              C.bind(Z, "touchmove", u, { passive: !0 }),
                              C.bind(Z, "load", u),
                              C.bind(Z, "resize", u),
                              C.bind(g, "scroll", u, { passive: !0 }),
                              (g.updateArrows = u),
                              d.autoScrollInterval &&
                                clearInterval(d.autoScrollInterval);
                            var p = v || 0;
                            0 < p &&
                              "grid" !== w &&
                              ((d.onmouseenter = function () {
                                return (d.isHover = !0), d.isHover;
                              }),
                              (d.onmouseleave = function () {
                                return (d.isHover = !1), d.isHover;
                              }),
                              (d.autoScrollInterval = setInterval(function () {
                                var e;
                                d.isHover ||
                                  n ||
                                  (g.scrollLeft + g.clientWidth < g.scrollWidth
                                    ? S(d)
                                    : ((e = d),
                                      _(
                                        T.queryOne(".we-ul-container", e),
                                        0,
                                        null,
                                        function () {
                                          return E({ box: e, left: 0 });
                                        }
                                      )));
                              }, 1e3 * p)));
                          })({ box: e }),
                          clearInterval(t);
                      } catch (e) {
                        clearInterval(t),
                          I.error({
                            msg: "ERROR WHEN CALLING SETUP LAYOUT",
                            ctx: { message: e.message, stack: e.stack },
                          });
                      }
                  }, 200);
                },
              };
            },
            {},
          ],
        "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482":
          [
            function (e, t, n) {
              "use strict";
              var pe = e("webengage/colors"),
                R = e("webengage/events"),
                L = e("webengage/logger"),
                fe = e("webengage/util"),
                be = (e("webengage/comm"), e("webengage/logger")),
                f = (e("webengage/weq"), e("webengage/properties")),
                g = e("webengage/animate");
              function b(e) {
                return (Math.round(100 * e) / 100).toFixed(2);
              }
              function w(e) {
                e.containerHeight,
                  e.containerWidth,
                  e.marginHeight,
                  e.borderRadius,
                  e.showRoundedCorner;
                var t = e.showButton,
                  n = e.showVendor,
                  i = e.buttonText,
                  o = e.productCount,
                  a = e.currency,
                  r = (e.showTitle, e.title),
                  s = e.boxStyle,
                  c =
                    (e.navigationArrowMode, e.autoScrollInterval, e.isDecimal),
                  l = e.webP13BannerId,
                  g = e.data,
                  d = e.priceDisplayComparePrice;
                if (fe.isArray(g)) {
                  if (!s)
                    throw new Error("WEB PERSONALIZATIONS LAYOUT DATA MISSING");
                  var u =
                      '<div class="we-left-arrow webengage-recommendation-box-' +
                      ("grid" === s ? "grid" : "carousel") +
                      '-indicator indicator-left ">\n\t\t<div class="recomm-arrow arrow-left we-svg-arrow" style="margin-top: 50px; max-width: 50px;">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">\n\t\t\t<path d="M24.8894 14.7514L10.649 0.511215C10.3196 0.181592 9.87994 0 9.41113 0C8.94232 0 8.50265 0.181592 8.17329 0.511215L7.12458 1.55966C6.44218 2.24284 6.44218 3.35321 7.12458 4.03535L19.0826 15.9934L7.11131 27.9646C6.78195 28.2943 6.6001 28.7337 6.6001 29.2022C6.6001 29.6713 6.78195 30.1107 7.11131 30.4406L8.16002 31.4888C8.48964 31.8184 8.92905 32 9.39786 32C9.86667 32 10.3063 31.8184 10.6357 31.4888L24.8894 17.2356C25.2195 16.905 25.4009 16.4635 25.3998 15.9941C25.4009 15.523 25.2195 15.0818 24.8894 14.7514Z" fill="black"/>\n\t\t</svg>\n\t\t\t\n\t\t</div>\n\t</div>',
                    p =
                      '<div class="we-right-arrow webengage-recommendation-box-' +
                      ("grid" === s ? "grid" : "carousel") +
                      '-indicator indicator-right static-arrow ">\n\t\t<div class="recomm-arrow arrow-right we-svg-arrow" style="margin-top: 50px; max-width: 50px;">\n\t\t<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">\n\t\t<path d="M24.8894 14.7514L10.649 0.511215C10.3196 0.181592 9.87994 0 9.41113 0C8.94232 0 8.50265 0.181592 8.17329 0.511215L7.12458 1.55966C6.44218 2.24284 6.44218 3.35321 7.12458 4.03535L19.0826 15.9934L7.11131 27.9646C6.78195 28.2943 6.6001 28.7337 6.6001 29.2022C6.6001 29.6713 6.78195 30.1107 7.11131 30.4406L8.16002 31.4888C8.48964 31.8184 8.92905 32 9.39786 32C9.86667 32 10.3063 31.8184 10.6357 31.4888L24.8894 17.2356C25.2195 16.905 25.4009 16.4635 25.3998 15.9941C25.4009 15.523 25.2195 15.0818 24.8894 14.7514Z" fill="black"/>\n\t\t</svg>\t\n\t\t</div>\n\t\t</div>',
                    f = g.filter(function (e) {
                      return (
                        "" !== e.imageSrc ||
                        null !== e.imageSrc ||
                        e.imageSrc !== $
                      );
                    });
                  return (
                    '<div id="' +
                    l +
                    '" class="webengage webengage-webp13-container"><div class="webengage webengage-webp13-container-shopify" data-box-id="' +
                    l +
                    '"><webengage-box\n\t\t\t\t\t\tdata-layout-attributes=""\n\t\t\t\t\t\tclass="webengage we-recommendation-box webengage-recommendation-box we-animate" \n\t\t\t\t\t\tdata-box-style="' +
                    s +
                    '"\n\t\t\t\t\t\tstyle="display: block;">\n\t\t\t\t\t<h2 class="webengage we-box-title">' +
                    r +
                    '</h2>\n\t\t\t\t\t<div class="webengage webengage-recommendation-box-' +
                    ("grid" === s ? "grid" : "carousel") +
                    '-container">\n\t\t\t\t\t\t' +
                    ("carousel" === s ? u : "<div></div>") +
                    '\n\t\t\t\t\t\t<div class="webengage we-ul-container webengage-recommendation-box-' +
                    ("grid" === s ? "grid" : "carousel") +
                    ' we-drag-scroll v-align">\n\t\t\t\t\t\t\t\t\t\t<ul class="webengage we-ul webengage-recommendation-box-' +
                    ("grid" === s ? "grid" : "carousel-shelf") +
                    '">\n\n\t\t\t\t\t\t\t\t\t\t\t\t\t' +
                    f
                      .slice(0, o)
                      .map(function (e) {
                        if (e.imageSrc)
                          return (
                            '\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<li \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tclass="webengage webengage-recommendation-box-item"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tdata-product-identifier="' +
                            e.id +
                            '"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tdata-product-title="' +
                            e.title +
                            '" \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tdata-price="' +
                            e.price +
                            '"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tdata-original-price="' +
                            e.compareAtPrice +
                            '" \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tdata-display-url="' +
                            e.handle +
                            '?welayoutId=testlayout">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class="webengage we-link-media" data-product-identifier="' +
                            e.id +
                            '" href="/products/' +
                            e.handle +
                            '">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="webengage we-image-wrap">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img class="webengage we-image"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\talt="' +
                            e.title +
                            '" \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\ttitle="' +
                            e.title +
                            '" \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tloading="lazy"\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tsrc=' +
                            e.imageSrc +
                            '>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class="webengage we-link" data-product-identifier="' +
                            e.id +
                            '" href="/products/' +
                            e.handle +
                            '">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="webengage we-info-wrap">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="webengage we-title">' +
                            e.title +
                            "</div>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                            (n
                              ? '<div class="webengage we-product-vendor">' +
                                e.vendor +
                                "</div>"
                              : "") +
                            '\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="webengage we-price-wrap">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t' +
                            (d && e.compareAtPrice
                              ? '<span class="webengage we-price-strike"> \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t' +
                                a.replace(
                                  /{{.*[\w,.].*}}/g,
                                  c
                                    ? b(Number(e.compareAtPrice))
                                    : Number(e.compareAtPrice)
                                ) +
                                " \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>"
                              : "") +
                            '\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=" webengage we-price money" data-numeric-value="' +
                            e.price +
                            '" data-money-convertible="">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t' +
                            a.replace(
                              /{{.*[\w,.].*}}/g,
                              c ? b(Number(e.price)) : Number(e.price)
                            ) +
                            "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" +
                            (t
                              ? '<div class="webengage we-li-quick-actions">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="webengage we-add-to-cart-wrap">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class="webengage we-link href="javascript:void(0);">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button type="button" class="webengage we-button we-button--select we-add-to-cart">\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class="webengage we-text-button-clam" style="opacity: 1;"> ' +
                                i +
                                "</span>\x3c!--v-if--\x3e\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\x3c!--v-if--\x3e\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>"
                              : "") +
                            "\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</li>"
                          );
                      })
                      .join("") +
                    "\n\t\t\t\t\t\t\t\t\t\t\t\t</ul>\n\t\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t" +
                    ("carousel" === s ? p : "<div></div>") +
                    "\n\t\t\t\t\t</div>\n\t\t\t\t</webengage-box>\n\t\t\t\t</div>\n\t\t\t</div>"
                  );
                }
                throw new Error(
                  "WEB PERSONALIZATIONS RECOMMENDATION DATA MISSING"
                );
              }
              t.exports = {
                getMarkUp: function (e) {
                  be.debug({
                    msg: "PREVIEW GET MARKUP DATA FOR LAYOUT " + e.layoutId,
                    ctx: { data: e },
                  });
                  var t = pe.addHash(e.config),
                    n = (parseInt(t.maxImageHeight) || 320) + "px",
                    i = (parseInt(t.maxImageWidth) || 320) + "px",
                    o = (parseInt(t.imageMarginRight) || 30) + "px",
                    a = (parseInt(t.imageBorderRadius) || 4) + "px",
                    r = t.showRoundedCorner ? t.showRoundedCorner : "true",
                    s = t.buttonEnabled || !1,
                    c = t.text || " ",
                    l =
                      (t.layoutSettings,
                      t.imageSettings,
                      t.productDescriptionSettings,
                      t.priceSettings,
                      t.buttonSettings,
                      fe.flattenObject(t)[
                        "priceSettings.displayComparePrice"
                      ] || !1);
                  t.recommendationName;
                  var g = parseInt(t.numberOfProductsInCampaign) || 15,
                    d = t && t.currency ? t.currency : null,
                    u =
                      !t.currency || !t.currency.includes("amount_no_decimal"),
                    p = {
                      containerHeight: n,
                      containerWidth: i,
                      marginHeight: o,
                      borderRadius: a,
                      showRoundedCorner: r,
                      showButton: s,
                      showVendor: !1,
                      buttonText: c,
                      productCount: g,
                      currency: d,
                      showTitle: t.campaignHeadlineEnabled || !1,
                      title: t.campaignHeadlineValue || "",
                      boxStyle: t.boxStyle || "carousel",
                      navigationArrowMode: t.navigationArrowMode || "static",
                      autoScrollInterval: parseInt(t.autoScrollInterval) || 0,
                      isDecimal: u,
                      webP13BannerId:
                        "we-" +
                        (
                          t.id +
                          "-" +
                          (e.variationId ? e.variationId : "preview")
                        ).replace(/~/g, "t_"),
                      priceDisplayComparePrice: l,
                    };
                  return (
                    e.recommendationData
                      ? (p.data = e.recommendationData)
                      : (p.data = f.DUMMY_PRODUCT),
                    w(p)
                  );
                },
                getStyles: function (e) {
                  var t = pe.addHash(e.config),
                    n = t.buttonTextColor || "#333333",
                    i = t.buttonBackgroundColor || "#333333",
                    o = n,
                    a = t.buttonBorderColor || "#333333",
                    r = (pe.lighterColor(i, 0.05), pe.darkerColor(i, 0.1)),
                    s =
                      (pe.darkerColor(i, 0.3),
                      pe.darkerColor(o, 0.1),
                      pe.lighterColor(r, 0.05),
                      pe.isColorTooLight(t.borderColor),
                      parseInt(t.maxImageHeight),
                      parseInt(t.maxImageWidth),
                      (parseInt(t.imageMarginRight) || 30) + "px"),
                    c = (parseInt(t.imageBorderRadius) || 4) + "px",
                    l =
                      "we-" +
                      (
                        t.id +
                        "-" +
                        (e.variationId ? e.variationId : "preview")
                      ).replace(/~/g, "t_"),
                    g = t.mediumRowCount || 2,
                    d = t.largeRowCount || 4,
                    u = t.smallRowCount || 1,
                    p = t.css || "",
                    f = t.campaignHeadlineEnabled || !1,
                    b = fe.flattenObject(t),
                    w =
                      b["layoutSettings.background.color"] ||
                      t.primaryLayoutBackground,
                    m = b["layoutSettings.heading.font.family"] || null,
                    h =
                      ("regular" === b["layoutSettings.heading.font.variant"]
                        ? "400"
                        : b["layoutSettings.heading.font.variant"] &&
                          b["layoutSettings.heading.font.variant"].includes(
                            "italic"
                          )
                        ? "" +
                          b["layoutSettings.heading.font.variant"].split(
                            "italic"
                          )[0]
                        : b["layoutSettings.heading.font.variant"]) || null,
                    v =
                      b["layoutSettings.heading.font.variant"] &&
                      b["layoutSettings.heading.font.variant"].includes(
                        "italic"
                      )
                        ? "italic"
                        : null,
                    y = b["layoutSettings.heading.font.size"]
                      ? b["layoutSettings.heading.font.size"] + "px"
                      : null,
                    x = b["layoutSettings.heading.font.url"] || null,
                    E = b["layoutSettings.heading.color"] || "black",
                    _ = b["layoutSettings.heading.alignment"] || "center",
                    S = b.numberOfProductsInCampaign || 5,
                    C = b["imageSettings.background.color"] || "#FFFFFF",
                    I = void 0,
                    T = void 0,
                    k = b["imageSettings.fixedHeight"] || !1,
                    A = b["imageSettings.fixedWidth"] || !1;
                  (I = k ? (b["imageSettings.height"] || 300) + "px" : "auto"),
                    (T = A ? (b["imageSettings.width"] || 300) + "px" : "auto");
                  var O = b["productDescriptionSettings.font.family"] || null,
                    N =
                      ("regular" ===
                      b["productDescriptionSettings.font.variant"]
                        ? "400"
                        : b["productDescriptionSettings.font.variant"] &&
                          b["productDescriptionSettings.font.variant"].includes(
                            "italic"
                          )
                        ? "" +
                          b["productDescriptionSettings.font.variant"].split(
                            "italic"
                          )[0]
                        : b["productDescriptionSettings.font.variant"]) ||
                      "inherit",
                    P = b["productDescriptionSettings.font.size"]
                      ? b["productDescriptionSettings.font.size"] + "px"
                      : null,
                    D = b["productDescriptionSettings.font.url"] || null,
                    R = b["productDescriptionSettings.color"] || "#323232",
                    L =
                      b["productDescriptionSettings.font.variant"] &&
                      b["productDescriptionSettings.font.variant"].includes(
                        "italic"
                      )
                        ? "italic"
                        : null,
                    M = b["priceSettings.font.family"] || null,
                    z =
                      ("regular" === b["priceSettings.font.variant"]
                        ? "400"
                        : b["priceSettings.font.variant"] &&
                          b["priceSettings.font.variant"].includes("italic")
                        ? "" +
                          b["priceSettings.font.variant"].split("italic")[0]
                        : b["priceSettings.font.variant"]) || null,
                    W = b["priceSettings.font.size"]
                      ? b["priceSettings.font.size"] + "px"
                      : null,
                    F = b["priceSettings.font.url"] || null,
                    U = b["priceSettings.color"] || "#323232",
                    q = b["priceSettings.compareColor"] || "red",
                    j = b["priceSettings.displayComparePrice"] || !1,
                    B =
                      b["priceSettings.font.variant"] &&
                      b["priceSettings.font.variant"].includes("italic")
                        ? "italic"
                        : null,
                    V = b["buttonSettings.text.font.family"] || null,
                    H =
                      ("regular" === b["buttonSettings.text.font.variant"]
                        ? "400"
                        : b["buttonSettings.text.font.variant"] &&
                          b["buttonSettings.text.font.variant"].includes(
                            "italic"
                          )
                        ? "" +
                          b["buttonSettings.text.font.variant"].split(
                            "italic"
                          )[0]
                        : b["buttonSettings.text.font.variant"]) || null,
                    G = b["buttonSettings.text.font.size"]
                      ? b["buttonSettings.text.font.size"] + "px"
                      : null,
                    Y = b["buttonSettings.text.font.url"] || null,
                    Z = b["buttonSettings.text.color"] || n,
                    K =
                      b["buttonSettings.text.font.variant"] &&
                      b["buttonSettings.text.font.variant"].includes("italic")
                        ? "italic"
                        : null,
                    X = b["buttonSettings.button.color"] || i,
                    $ = b["buttonSettings.button.hoverColor"] || "#1d2939",
                    J = (b["buttonSettings.button.width"] || 320) + "px",
                    Q = (b["buttonSettings.button.width"] || "auto") + "px",
                    ee =
                      (b["buttonSettings.button.border.radius"] || 4) + "px" ||
                      "4px",
                    te =
                      (b["buttonSettings.button.border.width"] || "0") + "px",
                    ne =
                      b["buttonSettings.button.border.color"] || a || "#323232",
                    ie = b["buttonSettings.button.alignment"] || "center";
                  be.debug({
                    msg: "DESIGN CONFIG MAP",
                    ctx: {
                      buttonTextFontFamily: V,
                      buttonTextFontVariant: H,
                      buttonTextFontSize: G,
                      buttonTextFontUrl: Y,
                      BbuttonTextColor: Z,
                      BbuttonBackgroundColor: X,
                      BbuttonBackgroundHoverColor: $,
                      BbuttonWidth: J,
                      BbuttonHeight: Q,
                      BbuttonBorderRadius: ee,
                      BbuttonBorderWidth: te,
                      BbuttonBorderColor: ne,
                      BbuttonAlignment: ie,
                      DlayoutBackgroundColor: w,
                      headingFontFamily: m,
                      headingFontVariant: h,
                      headingFontSize: y,
                      headingFontUrl: x,
                      headingColor: E,
                      headingAlignment: _,
                      priceFontFamily: M,
                      priceFontVariant: z,
                      priceFontSize: W,
                      priceFontUrl: F,
                      priceColor: U,
                      priceCompareColor: q,
                      priceDisplayComparePrice: j,
                      productDescriptionFontFamily: O,
                      productDescriptionFontVariant: N,
                      productDescriptionFontSize: P,
                      productDescriptionFontUrl: D,
                      productDescriptionColor: R,
                      DimageBackgroundColor: C,
                      imageWidth: T,
                      imageHeight: I,
                    },
                  });
                  var oe = void 0,
                    ae = "",
                    re = "",
                    se = "",
                    ce = "",
                    le = "",
                    ge = void 0,
                    de = "",
                    ue = "";
                  return (
                    w && (oe = "background-color : " + w + ";"),
                    m && (ae = "font-family :  '" + m + "';"),
                    h && (ae += "font-weight: " + h + ";"),
                    v && (ae += "font-style: " + v + ";"),
                    y && (re = "font-size : " + y + ";"),
                    E && (se = "color : " + E + ";"),
                    _ && (ce = "text-align: " + _ + "; margin: 0 70px;"),
                    O && (de = "font-family: '" + O + "';"),
                    N && (de += "font-weight: " + N + ";"),
                    L && (de += "font-style: " + L + ";"),
                    P && (de += "font-size: " + P + ";"),
                    Z &&
                      X &&
                      ne &&
                      (ge =
                        "color: " +
                        Z +
                        "; background-color: " +
                        X +
                        "; border-color: " +
                        ne +
                        ";"),
                    M &&
                      (le =
                        "font-family: '" +
                        M +
                        "'; font-weight: " +
                        z +
                        "; font-style:" +
                        B +
                        ";"),
                    z && (le += "font-weight: " + z + ";"),
                    L && (le += "font-style: " + B + ";"),
                    V && (ue = "font-family:  '" + V + "';"),
                    H && (ue += "font-weight: " + H + ";"),
                    K && (ue += "font-style: " + K + ";"),
                    G && (ue += "font-size: " + G + ";"),
                    "@media only screen and (min-width: 481px) and (max-width: 767px) {div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item {cursor: pointer;width: 50%;min-width: calc(100%/" +
                      g +
                      ");}}@media only screen and (max-width: 468px) {div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item {cursor: pointer;width: 100%;min-width: calc(100%/" +
                      u +
                      ");}\ndiv[data-box-id=" +
                      l +
                      "] div.we-recommendation-box div.webengage-recommendation-box-carousel,div[data-box-id=" +
                      l +
                      "] webengage-box div.webengage-recommendation-box-carousel {margin: 0 20px;}}div[data-box-id=" +
                      l +
                      "] .we-circle-spinner {fill: none;stroke: " +
                      E +
                      ";stroke-width: 4;stroke-dasharray: 1, 200;stroke-dashoffset: 0;stroke-linecap: round;animation: dash4 1.5s ease-in-out infinite;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item {/* margin-right: " +
                      s +
                      "; *//* max-width: " +
                      T +
                      "; *//* flex-basis: " +
                      T +
                      "; *//* min-width: " +
                      T +
                      "; */}div[data-box-id=" +
                      l +
                      "] webengage-box {font-family : inherit;" +
                      oe +
                      "}div[data-box-id=" +
                      l +
                      "] .we-box-title {" +
                      ae +
                      re +
                      se +
                      ce +
                      (f && !0 === f ? "display: block;" : "display: none;") +
                      "}div[data-box-id=" +
                      l +
                      "] .we-add-to-cart {" +
                      ue +
                      ge +
                      (ne && te && ee
                        ? "border-radius: " +
                          ee +
                          "; -moz-border-radius: " +
                          ee +
                          "; -webkit-border-radius :" +
                          ee +
                          ";border-width: " +
                          te +
                          "; -moz-border-width : " +
                          te +
                          "; -webkit-border-width: " +
                          te +
                          ";border-style: solid; -moz-border-style: solid; -webkit-border-style: solid;"
                        : "-moz-border-radius:none; -webkit-border-radius:none; border-radius:none; border-width: none; -moz-border-width : none; -webkit-border-width: none;border-style: none; -moz-border-style: none; -webkit-border-style: none;") +
                      "\t/* text-align\t\t\t\t: " +
                      ie +
                      "; */-webkit-appearance\t: none;/* background: #fff; */background-image: none;/* border: thin solid #444; *//* border-radius: 3px; */box-sizing: border-box;/* color: #000; */cursor: pointer;display: inline-block;line-height: 2em;margin: 0;outline: none;padding: .1em .5em;width: 95%;}div[data-box-id=" +
                      l +
                      "] .we-add-to-cart:hover, div[data-box-id=" +
                      l +
                      "] .we-add-to-cart:active {background-color    : " +
                      $ +
                      ";}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] ul.webengage-recommendation-box-carousel-shelf {/* align-items: stretch;display: flex;flex: 0 0 100%;flex-direction: row;justify-content: center;margin-left: 70px;margin-right: 70px; */display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-orient: horizontal;-webkit-box-direction: normal;-ms-flex-direction: row;flex-direction: row;-webkit-box-pack: start;-ms-flex-pack: start;" +
                      (4 < S
                        ? "justify-content: flex-start;"
                        : "justify-content: center;") +
                      "width: 100%;padding: unset;}div[data-box-id=" +
                      l +
                      "] webengage-box,div[data-box-id=" +
                      l +
                      "] webengage-container {display: block}div[data-box-id=" +
                      l +
                      "] div.we-recommendation-box .webengage-recommendation-box-item {float: left}div[data-box-id=" +
                      l +
                      "] .we-link {text-decoration: none;color: inherit;}div[data-box-id=" +
                      l +
                      "] div.we-recommendation-box ul:after,div[data-box-id=" +
                      l +
                      '] div.we-recommendation-box ul:before {clear: both;content: "";display: table;font-size: 0;line-height: 0}div[data-box-id=' +
                      l +
                      "] div.we-recommendation-box,div[data-box-id=" +
                      l +
                      "] webengage-box {-webkit-touch-callout: none;box-sizing: border-box;clear: both;direction: ltr !important;display: block;margin: 10px auto;padding: 10px 0 0;position: relative;text-align: center;-webkit-user-select: none;-khtml-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;width: 100%}div[data-box-id=" +
                      l +
                      "] div.we-recommendation-box .webengage-recommendation-box-item,div[data-box-id=" +
                      l +
                      "] webengage-box .webengage-recommendation-box-item {/* cursor: pointer;display: inline-block;margin-bottom: 0;margin-left: 0;margin-top: 0;max-width: 200px;padding: 0;position: relative;transition: transform .5s;-webkit-transition: -webkit-transform .5s;width: 200px */cursor: pointer;width: 25%;min-width: calc(100%/" +
                      d +
                      ");/* margin-right: 24px;*/-webkit-transition: -webkit-transform .5s;transition: -webkit-transform .5s;-o-transition: transform .5s;transition: transform .5s;transition: transform .5s, -webkit-transform .5s;list-style-type: none;}div[data-box-id=" +
                      l +
                      "] div.we-recommendation-box .webengage-recommendation-box-item .we-link,div[data-box-id=" +
                      l +
                      "] webengage-box .webengage-recommendation-box-item .we-link {border: 0;display: inline-block;position: relative;text-decoration: none !important}div[data-box-id=" +
                      l +
                      "] div.we-recommendation-box .webengage-recommendation-box-item .we-link .spr-badge,div[data-box-id=" +
                      l +
                      "] webengage-box .webengage-recommendation-box-item .we-link .spr-badge {max-height: 40px}div[data-box-id=" +
                      l +
                      "] div.we-recommendation-box:not(.no-zoom) .webengage-recommendation-box-item:hover .we-image,div[data-box-id=" +
                      l +
                      "] webengage-box:not(.no-zoom) .webengage-recommendation-box-item:hover .we-image {opacity: .9;transform: scale(1.03);transition: all .3s ease}div[data-box-id=" +
                      l +
                      "] div.we-recommendation-box div.webengage-recommendation-box-carousel,div[data-box-id=" +
                      l +
                      "] webengage-box div.webengage-recommendation-box-carousel {/* -webkit-overflow-scrolling: touch;display: inline-flex;font-size: 12px;margin: 0 70px;box-sizing: border-box;justify-content: flex-start;overflow-x: auto !important;overflow-y: hidden;padding: 10px 0;position: relative;width: 100% */-webkit-overflow-scrolling: touch;display: -webkit-inline-box;display: -ms-inline-flexbox;display: inline-flex;-webkit-box-sizing: border-box;box-sizing: border-box;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;overflow-x: auto;overflow-y: hidden;padding: 10px 0;width: 100%;margin: 0 70px;scrollbar-width: none;/* Firefox */-ms-overflow-style: none;/* IE and Edge */}div[data-box-id=" +
                      l +
                      "] div.we-recommendation-box div.webengage-recommendation-box-carousel,div[data-box-id=" +
                      l +
                      "] webengage-box div.webengage-recommendation-box-carousel::-webkit-scrollbar {display: none;}\ndiv[data-box-id=" +
                      l +
                      "] div.we-recommendation-box div.webengage-recommendation-box-carousel-container,div[data-box-id=" +
                      l +
                      "] webengage-box div.webengage-recommendation-box-carousel-container {/*display: flex;margin: 0 0 10px !important;position: relative;width: 100%;flex-direction: row;*/margin: 0 0 10px !important;width: 100%;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;}div[data-box-id=" +
                      l +
                      "] div.we-recommendation-box ul.webengage-recommendation-box-carousel-shelf,div[data-box-id=" +
                      l +
                      "] webengage-box ul.webengage-recommendation-box-carousel-shelf {word-wrap: break-word;left: 0 !important;/* margin: 0 !important; */overflow-x: visible;padding: 0 !important;transition: transform .7s cubic-bezier(.45, .03, .51, .95);-webkit-transition: transform .7s cubic-bezier(.45, .03, .51, .95)}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link-media,div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link-media {/* width: 100%; */width: " +
                      T +
                      ";height: " +
                      I +
                      ";display: block;max-width: 100%;text-align: center;margin-left: auto;margin-right: auto;cursor: pointer;pointer-events: auto;margin: 0 auto;padding: 0;font-size: 0;line-height: 0;}\t\tdiv[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link,div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link {/* display: inline-flex;flex: 1 1 auto;flex-direction: column;justify-content: space-between;width: 100% */width: 100%;width: 250px;display: block;max-width: 100%;text-align: center;margin-left: auto;margin-right: auto;cursor: pointer;pointer-events: auto;margin: 0 auto;padding: 0;font-size: 0;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link-media .we-image-wrap,div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link-media .we-image-wrap {/* line-height: 0 */-webkit-box-align: stretch;-ms-flex-align: stretch;align-items: stretch;display: -webkit-inline-box;display: -ms-inline-flexbox;display: inline-flex;-webkit-box-flex: 1;-ms-flex: auto;flex: auto;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-ms-flex-pack: distribute;justify-content: space-around;width: 95%;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link-media .we-image-wrap .we-image,div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link-media .we-image-wrap .we-image {display: block;margin: 0 auto;width: " +
                      T +
                      ";height: " +
                      I +
                      ";max-width: 100%;max-height: 100%;-o-object-fit: contain;object-fit: contain;background-color: " +
                      C +
                      ";border-radius: " +
                      c +
                      ";max-height: " +
                      I +
                      ";max-width: " +
                      T +
                      ";}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link-media .we-image-wrap .we-image-secondary,div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link-media .we-image-wrap .we-image-secondary {left: 0;max-height: 100%;max-width: 100%;opacity: 0;position: absolute;visibility: hidden;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link .we-info-wrap,div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link .we-info-wrap {/* padding: 3px 0 */ display: -webkit-inline-box;display: -ms-inline-flexbox;display: inline-flex;/* flex: 1 1 auto; */-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-webkit-box-pack: start;-ms-flex-pack: start;justify-content: flex-start;text-align: left;width: 95%;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link .we-review-wrap,div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link .we-review-wrap {min-height: 25px;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item:hover .we-link-media .we-image-wrap:not(.disable-secondary-image) img.we-image:not(:only-of-type):not(.we-image-secondary),div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item:hover .we-link-media .we-image-wrap:not(.disable-secondary-image) img.we-image:not(:only-of-type):not(.we-image-secondary) {opacity: 0;visibility: hidden;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item:hover .we-link-media .we-image-wrap:not(.disable-secondary-image) .we-image-secondary,div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item:hover .we-link-media .we-image-wrap:not(.disable-secondary-image) .we-image-secondary {opacity: 1;visibility: visible;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item {display: inline-flex;flex-direction: column;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item:last-child {margin-right: 0 !important;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link-media .we-image-wrap {align-items: stretch;display: inline-flex;flex: auto;flex-direction: column;justify-content: space-around;position: relative;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link-media .we-image-wrap .we-image {width: 100%;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .we-link .we-info-wrap {display: inline-flex;/* flex: 1 1 auto; */flex-direction: column;justify-content: flex-start;text-align: left;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=carousel] ul:after,div[data-box-id=" +
                      l +
                      '] webengage-box[data-box-style=carousel] ul:before {clear: both;content: "";display: table;font-size: 0;line-height: 0;}div[data-box-id=' +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link {justify-content: space-between;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link-media .we-image-wrap {position: relative;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] .webengage-recommendation-box-item .we-link-media .we-image-wrap .we-image {max-width: 100%;min-width: 100%;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] ul.webengage-recommendation-box-grid {align-content: stretch;align-items: stretch;display: flex;flex: 1 1 auto;flex-direction: row;flex-wrap: wrap;justify-content: space-around;list-style-type: none;padding-top: 10px;transform: none;}div[data-box-id=" +
                      l +
                      "] webengage-box[data-box-style=grid] ul.webengage-recommendation-box-grid>li {display: flex;flex: 1 0 200px;flex-direction: column;margin-bottom: 50px;margin-right: 20px;max-height: none;max-width: none;position: relative;width: auto;}div[data-box-id=" +
                      l +
                      "] .we-original-product_price.we-original-product_price {margin-right: 5px;text-decoration: line-through !important;}div[data-box-id=" +
                      l +
                      "] .we-sale-sign-wrap {left: 0;position: absolute;text-align: center;top: 20px;width: 100%;}div[data-box-id=" +
                      l +
                      "] .we-sale-sign:before {display: block;line-height: 0;padding-top: 100%;width: 0;}div[data-box-id=" +
                      l +
                      "] .we-sale-sign {align-items: center;background-color: rgba(200, 0, 0, .6);border: 1px solid transparent;border-radius: 0 2px 2px 0;color: #fff;display: flex;font-size: 12px;font-weight: 300;justify-content: center;padding: 2px 10px;position: absolute;text-align: center;top: 0;white-space: pre;}div[data-box-id=" +
                      l +
                      "] .we-loyalty-point-wrap {bottom: 0;position: absolute;right: 0;width: 100%;}div[data-box-id=" +
                      l +
                      "] .we-loyalty-point {background-color: rgba(255, 204, 0, .6);border: 1px solid transparent;border-radius: 2px 0 0 2px;bottom: 10px;color: #111;font-size: 12px;font-weight: 300;line-height: 1.1;padding: 2px 10px;position: absolute;right: 0;}div[data-box-id=" +
                      l +
                      "] .we-product_title {line-height: 1.3em;margin: 0 0 2px;padding-top: 5px;text-decoration: none;}div[data-box-id=" +
                      l +
                      "] .we-box-product_title {margin: 10px auto 0;text-align: center;}div[data-box-id=" +
                      l +
                      "] .we-product_vendor {display: none;}div[data-box-id=" +
                      l +
                      "] .we-li-quick-actions {/* align-items: center;display: inline-flex;height: 60px;margin-top: 10px */-webkit-box-align: center;-ms-flex-align: center;align-items: center;display: -webkit-inline-box;display: -ms-inline-flexbox;display: inline-flex;height: 60px;margin-top: 10px;width: 100%;}div[data-box-id=" +
                      l +
                      "] .we-li-overlay {bottom: 0;height: 100%;left: 0;max-width: none !important;position: absolute;text-align: center;transition: opacity .3s ease-out;width: 100%;}div[data-box-id=" +
                      l +
                      "] .we-li-overlay-container {background-color: hsla(0, 0%, 78%, .08);bottom: 0;height: 100%;opacity: 0;position: relative;transition: opacity .3s ease-out !important;z-index: 1;}div[data-box-id=" +
                      l +
                      "] .we-li-overlay-container .we-add-to-cart-wrap {margin-bottom: 25px;transform: translateY(25px);transition: transform .3s ease-out !important}div[data-box-id=" +
                      l +
                      "] .we-li-overlay-container:hover {opacity: 1;}div[data-box-id=" +
                      l +
                      "] .we-li-overlay-container:hover .we-add-to-cart-wrap {transform: translateY(0);}div[data-box-id=" +
                      l +
                      "] .we-li-overlay-container>* {bottom: 0;left: 0;position: absolute !important;right: 0;}div[data-box-id=" +
                      l +
                      "] .we-add-to-cart-wrap {display: inline-block;font-size: 1rem;margin: auto;position: relative;width: 100%;}div[data-box-id=" +
                      l +
                      "] [data-box-type=Upsell] .we-add-to-cart-wrap {width: 100%;}div[data-box-id=" +
                      l +
                      "] .we-add-to-cart .button {text-align: center;text-decoration: none;}div[data-box-id=" +
                      l +
                      "] .we-add-to-cart.we-dropdown {appearance: none;-webkit-appearance: none;-moz-appearance: none;padding-right: 30px;}div[data-box-id=" +
                      l +
                      "] .we-add-to-cart-arrow {border-left: 1px solid #000;height: 90%;right: 0;top: 5%;width: 1.8em;}div[data-box-id=" +
                      l +
                      "] .we-add-to-cart-arrow,div[data-box-id=" +
                      l +
                      "] .we-add-to-cart-arrow:after {display: inline-block;pointer-events: none;position: absolute;}div[data-box-id=" +
                      l +
                      '] .we-add-to-cart-arrow:after {border-left: .4em solid transparent;border-right: .4em solid transparent;border-top: .4em solid #444;content: "";right: 50%;top: 50%;transform: translateX(50%) translateY(-50%);}div[data-box-id=' +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator {/* display: inline; */height: 100%;position: absolute;text-align: center;top: 0;transform: translateX(0);transition: .2s cubic-bezier(.175, .885, .32, 1.275);width: 40px;z-index: 10;}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator img {height: 40px !important;margin: 50% 0 !important;width: 40px !important}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator.indicator-left {left: 0;display: inline-flex;flex-direction: column;justify-content: center;}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator.indicator-right {right: 0;display: inline-flex;flex-direction: column;justify-content: center;\n}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator .recomm-arrow {/* background-color: hsla(0, 0%, 94%, .5); */cursor: pointer !important;display: inline-block;margin-top: 60px;padding: 20px 0;}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator .recomm-arrow svg {display: block;height: 40px;margin: auto;width: 40px;}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator .recomm-arrow svg path {fill: #000;}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator .recomm-arrow.arrow-left svg {transform: rotate(180deg);-ms-transform: rotate(180deg);-webkit-transform: rotate(180deg);}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box:hover .webengage-recommendation-box-carousel-indicator.indicator-left {-webkit-transform: translateX(-40px);transform: translateX(-40px);-webkit-transition-delay: 0s;transition-delay: 0s;}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box:hover .webengage-recommendation-box-carousel-indicator.indicator-right {-webkit-transform: translateX(40px);transform: translateX(40px);-webkit-transition-delay: 0s;transition-delay: 0s;}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box:hover .webengage-recommendation-box-carousel-indicator.static-arrow {-webkit-transform: none;transform: none;}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator .arrow-left,div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator:not(.static-arrow) .arrow-right {border-radius: 0 5px 5px 0;}div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator .arrow-right,div[data-box-id=" +
                      l +
                      "] .webengage-recommendation-box-carousel-indicator:not(.static-arrow) .arrow-left {border-radius: 5px 0 0 5px;}div[data-box-id=" +
                      l +
                      "] .webengage-paginator-wrap {display: none;}div[data-box-id=" +
                      l +
                      "] .we-notification {-webkit-animation: we-notification-fade 5s forwards;animation: we-notification-fade 5s forwards;background-color: rgba(50, 50, 50, .95);border-radius: 4px;box-shadow: 0 3px 5px -1px rgba(0, 0, 0, .2), 0 6px 10px 0 rgba(0, 0, 0, .14), 0 1px 18px 0 rgba(0, 0, 0, .12);color: hsla(0, 0%, 100%, .7);padding: 16px;position: fixed;right: 20px;text-align: center;top: 20px;width: 300px;z-index: 1000000;}div[data-box-id=" +
                      l +
                      "] .we-notification.we-notification-link:hover {cursor: pointer;text-decoration: underline;}@keyframes we-notification-fade {0% {opacity: 0;transform: translateY(-20px);}10% {opacity: 1;transform: none;}90% {opacity: 1;transform: none;}to {opacity: 0;transform: translateY(-20px);}}@-webkit-keyframes we-notification-fade {0% {opacity: 0;transform: translateY(-20px);}10% {opacity: 1;transform: none;}90% {opacity: 1;transform: none;}to {opacity: 0;transform: translateY(-20px);}}div[data-box-id=" +
                      l +
                      "] img[src*=curated-collection-variation] {display: none;}div[data-box-id=" +
                      l +
                      "] img[data-lazy-src] {will-change: contents;}div[data-box-id=" +
                      l +
                      "] .v-align {display: inline-block;float: none;vertical-align: middle !important;}div[data-box-id=" +
                      l +
                      "] .notransition {-webkit-transition: none !important;-moz-transition: none !important;-o-transition: none !important;-ms-transition: none !important;transition: none !important;}div[data-box-id=" +
                      l +
                      "] .we-animate {-webkit-transition: all .2s ease-out;-o-transition: all .2s ease-out;transition: all .2s ease-out;display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;-webkit-box-align: center;-ms-flex-align: center;align-items: center;}div[data-box-id=" +
                      l +
                      "] .we-animate-hide {opacity: 0;visibility: hidden;}div[data-box-id=" +
                      l +
                      "] .we-title {" +
                      de +
                      "color: " +
                      R +
                      ";line-height: 1.5em;height: 3em;overflow: hidden;/* white-space: nowrap; */text-overflow: ellipsis;width: 100%;display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;}div[data-box-id=" +
                      l +
                      "] .we-price-wrap {" +
                      le +
                      "font-size: " +
                      W +
                      ";color: " +
                      U +
                      ";/* font-size: 16px; */}div[data-box-id=" +
                      l +
                      "] .we-price-strike {text-decoration: line-through;color: " +
                      q +
                      ";/* display: " +
                      (!0 === j ? "block" : "none") +
                      " */}div[data-box-id=" +
                      l +
                      "] .we-text-button-clam {overflow: hidden;/* white-space: nowrap; */text-overflow: ellipsis;width: 100%;display: -webkit-box;-webkit-line-clamp: 1;-webkit-box-orient: vertical;}div[data-box-id=" +
                      l +
                      "] .we-svg-spinner {width: 1.5em;transform-origin: center;animation: rotate4 2s linear infinite;display: inline-block;vertical-align: -3px;} div[data-box-id=" +
                      l +
                      "] .we-tick {display: inline-block;vertical-align: -3px;}@keyframes rotate4 {100% {transform: rotate(360deg);}}@keyframes dash4 {0% {stroke-dasharray: 1, 200;stroke-dashoffset: 0;}50% {stroke-dasharray: 90, 200;stroke-dashoffset: -35px;}100% {stroke-dashoffset: -125px;}}" +
                      p
                  );
                },
                getScripts: function (e) {
                  L.debug({
                    msg: "WEB PERSONALIZATIONS LAYOUT JAVASCRIPT",
                    ctx: e,
                  });
                  var t,
                    h = e.dom || X.require("webengage/dom"),
                    v = e && e.data ? e.data : e,
                    n = e && e.data && e.data.config ? e.data.config : e.config,
                    y =
                      "we-" +
                      (
                        n.id +
                        "-" +
                        (e.variationId ? e.variationId : "preview")
                      ).replace(/~/g, "t_"),
                    x = n.cta,
                    E = n.boxStyle || "carousel",
                    i = n.NavigationArrowMode || "static",
                    _ = n.NavigationArrowType || "circleFull",
                    S = n.maxImageHeight || 300,
                    C = (n.autoScrollInterval, n.mediumRowCount || 2),
                    I = (n.largeRowCount, n.smallRowCount || 1),
                    o = n.numberOfProductsInCampaign || 5,
                    l = function (e, t) {
                      L.debug({
                        msg: "WEB PERSONALIZATIONS LAYOUT SHOPIFY METHODS ADD CART",
                        ctx: { data: e },
                      }),
                        fetch((Z.Shopify.routes.root || "/") + "cart/add.js", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify(e),
                        })
                          .then(function (e) {
                            return e.ok
                              ? t(null, e.json())
                              : 422 === e.status
                              ? t(!0, null)
                              : t(!1, null);
                          })
                          .catch(function (e) {
                            return (
                              L.debug({ msg: "catch", ctx: {} }),
                              L.error({
                                msg: "FAILED TO ADD PRODUCT TO CART",
                                ctx: { message: e.message, stack: e.stack },
                              }),
                              t(e, null)
                            );
                          });
                    },
                    T = function () {
                      return {
                        get: function () {
                          return '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none"><path d="M24.8894 14.7514L10.649 0.511215C10.3196 0.181592 9.87994 0 9.41113 0C8.94232 0 8.50265 0.181592 8.17329 0.511215L7.12458 1.55966C6.44218 2.24284 6.44218 3.35321 7.12458 4.03535L19.0826 15.9934L7.11131 27.9646C6.78195 28.2943 6.6001 28.7337 6.6001 29.2022C6.6001 29.6713 6.78195 30.1107 7.11131 30.4406L8.16002 31.4888C8.48964 31.8184 8.92905 32 9.39786 32C9.86667 32 10.3063 31.8184 10.6357 31.4888L24.8894 17.2356C25.2195 16.905 25.4009 16.4635 25.3998 15.9941C25.4009 15.523 25.2195 15.0818 24.8894 14.7514Z" fill="black"/></svg>';
                        },
                      };
                    },
                    k = function (c) {
                      var e = function (a) {
                          var r = a.querySelector(".we-add-to-cart");
                          if (r) {
                            var s = r.querySelector(".we-text-button-clam");
                            (r.doAction = !1),
                              (r.isBind = r.isBind || !1),
                              r &&
                                "boolean" == typeof r.isBind &&
                                !1 === r.isBind &&
                                ((r.isBind = !0),
                                R.bind(r, "click", function (e) {
                                  e.preventDefault();
                                  var t = {
                                    items: [
                                      {
                                        id: a.getAttribute(
                                          "data-product-identifier"
                                        ),
                                        quantity: 1,
                                      },
                                    ],
                                  };
                                  if ("Add to Cart" === c) {
                                    r.disabled = !0;
                                    var n = h.createElement(
                                        "span",
                                        '<svg class="we-svg-spinner" width="20px" height="20px" viewBox="25 25 50 50"><circle class="we-circle-spinner" r="20" cy="50" cx="50"></circle></svg>'
                                      ),
                                      i = h.createElement(
                                        "span",
                                        '<svg class="we-tick" width="20px" height="20px" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10 0C4.486 0 0 4.486 0 10C0 15.514 4.486 20 10 20C15.514 20 20 15.514 20 10C20 4.486 15.514 0 10 0ZM10 18.1818C5.48848 18.1818 1.81818 14.5115 1.81818 10C1.81818 5.48855 5.48848 1.81818 10 1.81818C14.5115 1.81818 18.1818 5.48855 18.1818 10C18.1818 14.5115 14.5115 18.1818 10 18.1818Z" fill="white"/><path d="M13.7498 6.46448L8.60712 11.6071L6.25015 9.25006C5.89518 8.89509 5.31955 8.89503 4.96451 9.25C4.60948 9.60503 4.60948 10.1806 4.96451 10.5356L7.96427 13.5355C8.13476 13.706 8.36597 13.8018 8.60706 13.8018H8.60712C8.84821 13.8018 9.07942 13.706 9.24991 13.5356L15.0354 7.75018C15.3905 7.39515 15.3905 6.81958 15.0354 6.46455C14.6804 6.10951 14.1048 6.10945 13.7498 6.46448Z" fill="white"/></svg>'
                                      ),
                                      o = h.createElement("span", "");
                                    if (
                                      ((n.className = "we-text-button-clam"),
                                      (i.className = "we-text-button-clam"),
                                      (o.className = "we-text-button-clam"),
                                      r && !0 === r.doAction)
                                    )
                                      return void (Z.location = "/cart");
                                    s.remove(),
                                      r.appendChild(n),
                                      l(t, function (e, t) {
                                        (r.doAction = !0),
                                          L.debug({
                                            msg: "ADDED TO CART CALLED",
                                            ctx: t,
                                          }),
                                          g.fadeOut(n, function () {
                                            n.remove(),
                                              r.appendChild(i),
                                              g.fadeIn(i, function () {
                                                g.fadeOut(i, function () {
                                                  "boolean" == typeof e &&
                                                  !0 === e
                                                    ? ((o.innerHTML =
                                                        "Out of Stock"),
                                                      (r.disabled = !0),
                                                      h.css.applyCss(r, {
                                                        "background-color":
                                                          "#D0D5DD",
                                                      }))
                                                    : ((o.innerHTML =
                                                        "View Cart"),
                                                      (r.disabled = !1)),
                                                    i.remove(),
                                                    r.appendChild(o),
                                                    g.fadeIn(o, function () {});
                                                });
                                              });
                                          });
                                      });
                                  }
                                  "Redirect to checkout" === c
                                    ? (Z.location = "/checkout")
                                    : "Redirect to cart" === c &&
                                      (Z.location = "/cart");
                                }));
                          }
                        },
                        t = !0,
                        n = !1,
                        i = $;
                      try {
                        for (
                          var o,
                            a = K.querySelectorAll(
                              "#" + y + " .webengage-recommendation-box-item"
                            )[Symbol.iterator]();
                          !(t = (o = a.next()).done);
                          t = !0
                        )
                          e(o.value);
                      } catch (e) {
                        (n = !0), (i = e);
                      } finally {
                        try {
                          !t && a.return && a.return();
                        } finally {
                          if (n) throw i;
                        }
                      }
                    },
                    a = function (e) {
                      var t = e.box,
                        n = e.type,
                        i = e.visible,
                        o = h.queryOne(
                          "left" === n ? ".we-left-arrow" : ".we-right-arrow",
                          t
                        );
                      o &&
                        (o.classList.add("we-animate"),
                        i
                          ? o.classList.remove("we-animate-hide")
                          : o.classList.add("we-animate-hide"));
                    },
                    r = function (e) {
                      var t = e.box,
                        n = e.type,
                        i = e.left,
                        o = t.querySelector(".we-ul-container");
                      return "left" === n
                        ? 0 < (isNaN(i) ? o.scrollLeft : i)
                        : (isNaN(i) ? o.scrollLeft : i) + o.clientWidth <
                            o.scrollWidth;
                    };
                  function A(e) {
                    var t = e.box,
                      n = e.left;
                    t &&
                      "carousel" === E &&
                      (t.clientWidth,
                      Z.innerWidth,
                      K.querySelectorAll(
                        ".we-left-arrow, .we-right-arrow"
                      ).forEach(function (e) {
                        t.clientWidth + 100 > Z.innerWidth || "static" === i
                          ? e.classList.add("static-arrow")
                          : e.classList.remove("static-arrow");
                      }),
                      a({
                        box: t,
                        type: "left",
                        visible: r({ box: t, type: "left", left: n }),
                      }),
                      a({
                        box: t,
                        type: "right",
                        visible: r({ box: t, type: "right", left: n }),
                      }));
                  }
                  function O(a, r, e, s) {
                    L.debug({
                      msg: "WEB PERSONALIZATIONS LAYOUT scrollLeft",
                      ctx: { element: a, offset: r, options: e },
                    }),
                      "function" == typeof (e = e || {}) && ((s = e), (e = {})),
                      "function" != typeof s && (s = function () {});
                    var c = Date.now(),
                      l = a.scrollLeft,
                      g =
                        e.ease ||
                        function (e) {
                          return 0.5 * (1 - Math.cos(Math.PI * e));
                        },
                      d = isNaN(e.duration) ? 350 : +e.duration,
                      u = !1;
                    return l === r
                      ? s(
                          new Error(
                            "Element already at target scroll position",
                            a.scrollLeft
                          )
                        )
                      : (requestAnimationFrame(function e(t) {
                          if (u)
                            return s(
                              new Error("Scroll cancelled"),
                              a.scrollLeft
                            );
                          var n = Date.now(),
                            i = Math.min(1, (n - c) / d),
                            o = g(i);
                          (a.scrollLeft = o * (r - l) + l),
                            i < 1
                              ? requestAnimationFrame(e)
                              : requestAnimationFrame(function () {
                                  return s(null, a.scrollLeft);
                                });
                        }),
                        function () {
                          u = !0;
                        });
                  }
                  function N(e) {
                    var t = e.querySelector(".we-ul-container"),
                      n = e.querySelector(".we-ul"),
                      i = void 0,
                      o = !0,
                      a = !1,
                      r = $;
                    try {
                      for (
                        var s,
                          c = t
                            .querySelectorAll(
                              ".webengage-recommendation-box-item"
                            )
                            [Symbol.iterator]();
                        !(o = (s = c.next()).done);
                        o = !0
                      ) {
                        i = s.value;
                        var l =
                            parseInt(Z.getComputedStyle(i).marginRight, 10) +
                            parseInt(Z.getComputedStyle(i).marginLeft, 10),
                          g = i.offsetLeft - t.scrollLeft,
                          d = Math.max(t.clientWidth, i.clientWidth + l);
                        if (
                          (Math.round(g) < 100 && (g = -20),
                          0 <= g + i.clientWidth - d)
                        )
                          break;
                      }
                    } catch (e) {
                      (a = !0), (r = e);
                    } finally {
                      try {
                        !o && c.return && c.return();
                      } finally {
                        if (a) throw r;
                      }
                    }
                    var u = Math.min(
                      i.offsetLeft - n.offsetLeft,
                      t.scrollWidth - t.clientWidth
                    );
                    O(t, u, null, function () {
                      return A({ box: e, left: u });
                    });
                  }
                  function P(e) {
                    e
                      ? (h.css.applyCss(
                          h.queryOne(
                            "div[data-box-id=" +
                              y +
                              "] webengage-box div.webengage-recommendation-box-carousel"
                          ),
                          { margin: "0 70px" }
                        ),
                        h.css.applyCss(
                          h.queryOne(
                            "div[data-box-id=" +
                              y +
                              "] webengage-box .we-box-title"
                          ),
                          { margin: "0 70px" }
                        ))
                      : (h.css.applyCss(
                          h.queryOne(
                            "div[data-box-id=" +
                              y +
                              "] webengage-box div.webengage-recommendation-box-carousel"
                          ),
                          { margin: "0 40px" }
                        ),
                        h.css.applyCss(
                          h.queryOne(
                            "div[data-box-id=" +
                              y +
                              "] webengage-box .we-box-title"
                          ),
                          { margin: "0 40px" }
                        ));
                  }
                  function D(e) {
                    4 <= o
                      ? h.css.applyCss(
                          h.queryOne(
                            "div[data-box-id=" +
                              y +
                              "] webengage-box[data-box-style=carousel] ul.webengage-recommendation-box-carousel-shelf"
                          ),
                          { "justify-content": "flex-start" }
                        )
                      : (1 !== o && 2 !== o && 3 !== o) ||
                        h.css.applyCss(
                          h.queryOne(
                            "div[data-box-id=" +
                              y +
                              "] webengage-box[data-box-style=carousel] ul.webengage-recommendation-box-carousel-shelf"
                          ),
                          {
                            "justify-content":
                              !0 === e ? "center" : "flex-start",
                          }
                        );
                  }
                  t = setInterval(function () {
                    var e = K.getElementsByTagName("webengage-box");
                    if (e && 0 < e.length)
                      try {
                        !(function (e) {
                          L.debug({
                            msg: "WEB PERSONALIZATIONS LAYOUT SETUP ",
                            ctx: e,
                          });
                          var d = e.box;
                          d.themeOptions = v;
                          var t = d.querySelector(".we-ul"),
                            n = !(
                              !d.themeOptions ||
                              !d.themeOptions.fullPage ||
                              "true" !== d.themeOptions.fullPage
                            ),
                            i = t.children[0];
                          i.currentStyle || Z.getComputedStyle(i), k(x);
                          var o = Z.matchMedia("(max-width: 768px)"),
                            a = Z.matchMedia("(max-width: 461px)");
                          function r(e) {
                            if (((Z.isTabletMq = !0), e.matches)) {
                              D(!1);
                              for (
                                var t = h.query(
                                    "div[data-box-id=" +
                                      y +
                                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .webengage-recommendation-box-item"
                                  ),
                                  n = 0;
                                n < t.length;
                                n++
                              ) {
                                var i = t[n];
                                h.css.applyCss(i, {
                                  cursor: "pointer",
                                  width: "100%",
                                  "min-width": "calc(100%/" + C + ")",
                                });
                              }
                              be.debug({
                                msg: "PREVIEW WEB PERSONALIZATION TABLET MEDIA QUERY APPLIED ",
                              });
                            } else
                              be.debug({
                                msg: "PREVIEW WEB PERSONALIZATION TABLET MEDIA QUERY REMOVED ",
                              });
                          }
                          function s(e) {
                            if (((Z.isMobileMq = !0), e.matches)) {
                              for (
                                var t = h.query(
                                    "div[data-box-id=" +
                                      y +
                                      "] webengage-box[data-box-style=carousel] .webengage-recommendation-box-item .webengage-recommendation-box-item"
                                  ),
                                  n = 0;
                                n < t.length;
                                n++
                              ) {
                                var i = t[n];
                                h.css.applyCss(i, {
                                  cursor: "pointer",
                                  width: "100%",
                                  "min-width": "calc(100%/" + I + ")",
                                });
                              }
                              P(!1),
                                D(!1),
                                be.debug({
                                  msg: "PREVIEW WEB PERSONALIZATION MOBILE MEDIA QUERY APPLIED ",
                                });
                            } else
                              P(!0),
                                D(!0),
                                be.debug({
                                  msg: "PREVIEW WEB PERSONALIZATION MOBILE MEDIA QUERY REMOVED ",
                                });
                          }
                          o.addListener(r), a.addListener(s), r(o), s(a);
                          var c = h.queryOne(".we-left-arrow"),
                            l = h.queryOne(".we-right-arrow"),
                            g = (S || 300) / 2 - 20;
                          c &&
                            (h.queryOne("#" + y + " .we-link-media") ||
                              h.css.applyCss(c, {
                                "margin-top": g + "px",
                                "max-width": "50 px",
                              }),
                            (c.children[0].onclick = function (e) {
                              var t = K.querySelector(".we-ul-container"),
                                n = K.querySelector(".we-ul"),
                                i = void 0,
                                o = !0,
                                a = !1,
                                r = $;
                              try {
                                for (
                                  var s,
                                    c = K.querySelectorAll(
                                      ".webengage-recommendation-box-item"
                                    )[Symbol.iterator]();
                                  !(o = (s = c.next()).done);
                                  o = !0
                                ) {
                                  i = s.value;
                                  var l =
                                    parseInt(
                                      Z.getComputedStyle(i).marginRight,
                                      10
                                    ) +
                                    parseInt(
                                      Z.getComputedStyle(i).marginLeft,
                                      10
                                    );
                                  if (
                                    0 <=
                                    i.offsetLeft -
                                      t.scrollLeft +
                                      l +
                                      Math.max(t.clientWidth, i.clientWidth + l)
                                  )
                                    break;
                                }
                              } catch (e) {
                                (a = !0), (r = e);
                              } finally {
                                try {
                                  !o && c.return && c.return();
                                } finally {
                                  if (a) throw r;
                                }
                              }
                              var g = Math.max(i.offsetLeft - n.offsetLeft, 0);
                              O(t, g, null, function () {
                                return A({ box: d, left: g });
                              });
                            }),
                            0 <=
                              c.children[0].className.indexOf("we-svg-arrow") &&
                              (c.children[0].innerHTML = T().get(
                                _ || "strikingChevron"
                              ))),
                            l &&
                              (h.queryOne("#" + y + " .we-link-media") ||
                                h.css.applyCss(l, {
                                  "margin-top": g + "px",
                                  "max-width": "50 px",
                                }),
                              (l.children[0].onclick = function (e) {
                                return N(d);
                              }),
                              0 <=
                                l.children[0].className.indexOf(
                                  "we-svg-arrow"
                                ) &&
                                (l.children[0].innerHTML = T().get(
                                  _ || "strikingChevron"
                                )));
                          var u,
                            p,
                            f,
                            b = K.querySelector(".we-ul-container"),
                            w =
                              ((u = function () {
                                return A({ box: d });
                              }),
                              (f = !(p = 300)),
                              function () {
                                f ||
                                  (u.apply($, arguments),
                                  (f = !0),
                                  setTimeout(function () {
                                    f = !1;
                                  }, p));
                              });
                          R.bind(Z, "wheel", w, { passive: !0 }),
                            R.bind(Z, "touchmove", w, { passive: !0 }),
                            R.bind(Z, "load", w),
                            R.bind(Z, "resize", w),
                            R.bind(b, "scroll", w, { passive: !0 }),
                            (b.updateArrows = w),
                            d.autoScrollInterval &&
                              clearInterval(d.autoScrollInterval);
                          var m = d.themeOptions.config.autoScrollInterval || 0;
                          0 < m &&
                            "grid" !== E &&
                            ((d.onmouseenter = function () {
                              return (d.isHover = !0), d.isHover;
                            }),
                            (d.onmouseleave = function () {
                              return (d.isHover = !1), d.isHover;
                            }),
                            (d.autoScrollInterval = setInterval(function () {
                              var e;
                              d.isHover ||
                                n ||
                                (b.scrollLeft + b.clientWidth < b.scrollWidth
                                  ? N(d)
                                  : ((e = d),
                                    O(
                                      h.queryOne(".we-ul-container", e),
                                      0,
                                      null,
                                      function () {
                                        return A({ box: e, left: 0 });
                                      }
                                    )));
                            }, 1e3 * m)));
                        })({ box: e[0] }),
                          clearInterval(t);
                      } catch (e) {
                        clearInterval(t),
                          L.error({
                            msg: "ERROR WHEN CALLING SETUP LAYOUT",
                            ctx: { message: e.message, stack: e.stack },
                          });
                      }
                  }, 200);
                },
                getRecommendations: function (e) {
                  return [
                    {
                      product_id: "8161523826961",
                      title: "Demo Product",
                      vendor: "WebEngage Product Demo",
                      price: 799,
                      handle: "<Random>",
                      imageSrc:
                        "https://static-webengage-implement.s3.amazonaws.com/Frame+427322838+(1).png",
                      compareAtPrice: 899,
                    },
                  ];
                },
                getFontFace: function (e) {
                  var t = e.config,
                    n = fe.flattenObject(t);
                  L.debug({
                    msg: "WEB PERSONALIZATIONS LAYOUT FONTFACE CONFIG",
                    ctx: n,
                  });
                  var i = n["layoutSettings.heading.font.family"] || "Inter",
                    o =
                      ("regular" === n["layoutSettings.heading.font.variant"]
                        ? "400"
                        : n["layoutSettings.heading.font.variant"] &&
                          n["layoutSettings.heading.font.variant"].includes(
                            "italic"
                          )
                        ? "italic" === n["layoutSettings.heading.font.variant"]
                          ? "1,400"
                          : "1," +
                            n["layoutSettings.heading.font.variant"].split(
                              "italic"
                            )[0]
                        : n["layoutSettings.heading.font.variant"]) || "400",
                    a =
                      n["layoutSettings.heading.font.variant"] &&
                      n["layoutSettings.heading.font.variant"].includes(
                        "italic"
                      )
                        ? "ital"
                        : "",
                    r = n["productDescriptionSettings.font.family"] || "Inter",
                    s =
                      ("regular" ===
                      n["productDescriptionSettings.font.variant"]
                        ? "400"
                        : n["productDescriptionSettings.font.variant"] &&
                          n["productDescriptionSettings.font.variant"].includes(
                            "italic"
                          )
                        ? "italic" ===
                          n["productDescriptionSettings.font.variant"]
                          ? "1,400"
                          : "1," +
                            n["productDescriptionSettings.font.variant"].split(
                              "italic"
                            )[0]
                        : n["productDescriptionSettings.font.variant"]) ||
                      "400",
                    c =
                      n["productDescriptionSettings.font.variant"] &&
                      n["productDescriptionSettings.font.variant"].includes(
                        "italic"
                      )
                        ? "ital"
                        : "",
                    l = n["priceSettings.font.family"] || "Inter",
                    g =
                      ("regular" === n["priceSettings.font.variant"]
                        ? "400"
                        : n["priceSettings.font.variant"] &&
                          n["priceSettings.font.variant"].includes("italic")
                        ? "italic" === n["priceSettings.font.variant"]
                          ? "1,400"
                          : "1," +
                            n["priceSettings.font.variant"].split("italic")[0]
                        : n["priceSettings.font.variant"]) || "400",
                    d =
                      n["priceSettings.font.variant"] &&
                      n["priceSettings.font.variant"].includes("italic")
                        ? "ital"
                        : "",
                    u = n["buttonSettings.text.font.family"] || "Inter",
                    p =
                      ("regular" === n["buttonSettings.text.font.variant"]
                        ? "400"
                        : n["buttonSettings.text.font.variant"] &&
                          n["buttonSettings.text.font.variant"].includes(
                            "italic"
                          )
                        ? "italic" === n["buttonSettings.text.font.variant"]
                          ? "1,400"
                          : "1," +
                            n["buttonSettings.text.font.variant"].split(
                              "italic"
                            )[0]
                        : n["buttonSettings.text.font.variant"]) || "400",
                    f =
                      n["buttonSettings.text.font.variant"] &&
                      n["buttonSettings.text.font.variant"].includes("italic")
                        ? "ital"
                        : "",
                    b =
                      "?family=" +
                      i.replace(/ /g, "+") +
                      ("" !== a ? ":" + a + "," : ":") +
                      "wght@" +
                      o;
                  return (
                    (b +=
                      "&family=" +
                      r.replace(/ /g, "+") +
                      ("" !== c ? ":" + c + "," : ":") +
                      "wght@" +
                      s),
                    (b +=
                      "&family=" +
                      l.replace(/ /g, "+") +
                      ("" !== d ? ":" + d + "," : ":") +
                      "wght@" +
                      g),
                    '<div id="we-dynamicLinks" style="visibility:none"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="https://fonts.googleapis.com/css2' +
                      (b +=
                        "&family=" +
                        u.replace(/ /g, "+") +
                        ("" !== f ? ":" + f + "," : ":") +
                        "wght@" +
                        p) +
                      '" /></div>'
                  );
                },
              };
            },
            {},
          ],
        "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h":
          [
            function (e, t, n) {
              "use strict";
              t.exports = {
                getMarkUp: e("./web-personalization-shopify-~184fc482")
                  .getMarkUp,
                getStyles: e("./web-personalization-shopify-~184fc482")
                  .getStyles,
                getScripts: e("./web-personalization-shopify-~184fc482")
                  .getScripts,
                getFontFace: e("./web-personalization-shopify-~184fc482")
                  .getFontFace,
              };
            },
            {
              "./web-personalization-shopify-~184fc482":
                "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482",
            },
          ],
        "webengage/web-personalization-layouts/web-personalization-shopify-~483856a":
          [
            function (e, t, n) {
              "use strict";
              t.exports = {
                getMarkUp: e("./web-personalization-shopify-~184fc482")
                  .getMarkUp,
                getStyles: e("./web-personalization-shopify-~184fc482")
                  .getStyles,
                getScripts: e("./web-personalization-shopify-~184fc482")
                  .getScripts,
                getFontFace: e("./web-personalization-shopify-~184fc482")
                  .getFontFace,
              };
            },
            {
              "./web-personalization-shopify-~184fc482":
                "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482",
            },
          ],
        "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76":
          [
            function (e, t, n) {
              "use strict";
              t.exports = {
                getMarkUp: e("./web-personalization-shopify-~184fc482")
                  .getMarkUp,
                getStyles: e("./web-personalization-shopify-~184fc482")
                  .getStyles,
                getScripts: e("./web-personalization-shopify-~184fc482")
                  .getScripts,
                getFontFace: e("./web-personalization-shopify-~184fc482")
                  .getFontFace,
              };
            },
            {
              "./web-personalization-shopify-~184fc482":
                "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482",
            },
          ],
        "webengage/web-personalization-layouts/web-personalization-~48381b0": [
          function (e, t, n) {
            "use strict";
            t.exports = {
              getMarkUp: function (e) {
                if (!e || !e.layoutAttributes)
                  throw new Error("WEB PERSONALIZATIONS LAYOUT DATA MISSING");
                var t,
                  n,
                  i = e.layoutAttributes,
                  o = "we-" + (e.id + "-" + e.experimentId).replace(/~/g, "t_");
                if (e.actions && e.actions.length)
                  for (var a = 0, r = e.actions.length; a < r; a++)
                    if (e.actions[a].isPrime) {
                      e.actions[a].actionText,
                        (t = e.actions[a].actionEId),
                        (n = e.actions[a].actionLink);
                      break;
                    }
                var s = i.banner_image && i.banner_image.imageUrl,
                  c = i.banner_image && i.banner_image.mImageUrl;
                return (
                  "<div id=" +
                  o +
                  '><div class="webengage-webp13-container prime"><div ' +
                  (n
                    ? "id='" +
                      t +
                      "' data-action-id='" +
                      t +
                      "' class='callToAction'"
                    : "") +
                  ">" +
                  (e.customCode
                    ? i.isImageResponsive
                      ? '<div class="webengage-webp13-custom-code-container">\n\t\t\t\t\t\t' +
                        e.customCode +
                        "\n\t\t\t\t\t</div>\n\t\t\t\t\t<img src=" +
                        s +
                        ' class="webengage-webp13-image" />\n\t\t\t\t'
                      : c
                      ? '<div class="webengage-webp13-custom-code-container">\n\t\t\t\t\t' +
                        e.customCode +
                        '\n\t\t\t\t</div>\n\t\t\t\t<picture>\n\t\t\t\t\t<source media="(max-width: 768px)" srcset=' +
                        c +
                        ">\n\t\t\t\t\t<img src=" +
                        s +
                        ' class="webengage-webp13-image " />\n\t\t\t\t</picture>'
                      : '<div class="webengage-webp13-custom-code-container">\n\t\t\t\t\t\t' +
                        e.customCode +
                        "\n\t\t\t\t\t</div>\n\t\t\t\t\t<img src=" +
                        s +
                        ' class="webengage-webp13-image" />\n\t\t\t\t'
                    : i.isImageResponsive
                    ? "<img src=" + s + ' class="webengage-webp13-image " />'
                    : c
                    ? '<picture>\n\t\t\t\t<source media="(max-width: 768px)" srcset=' +
                      c +
                      ">\n\t\t\t\t<img src=" +
                      s +
                      ' class="webengage-webp13-image " />\n\t\t\t</picture>'
                    : "<img src=" + s + ' class="webengage-webp13-image " />') +
                  "</div></div></div>"
                );
              },
              getStyles: function (e) {
                var t = e.layoutAttributes,
                  n = parseInt(t.banner_image.width) + "px",
                  i = t.show_rounded_corner || "false",
                  o = "",
                  a = "max-width: 100%;",
                  r = "we-" + (e.id + "-" + e.experimentId).replace(/~/g, "t_");
                return (
                  (o =
                    "true" === i
                      ? "border-radius:5px;"
                      : "border-radius:none;"),
                  parseInt(t.banner_image.width) &&
                    (a = "max-width: " + n + ";"),
                  "#" +
                    r +
                    " .webengage-webp13-container {position: relative;overflow: hidden;width: 100%;height: 100%;" +
                    a +
                    "}\n#" +
                    r +
                    " .webengage-webp13-custom-code-container {position: absolute;top: 50%;left: 0;right: 0;-webkit-transform: perspective(1px) translateY(-50%);transform: perspective(1px) translateY(-50%);padding: 40px;z-index: 1;}\n#" +
                    r +
                    " .prime {width: 100%;height: 100%;}\n.callToAction {cursor: pointer;}\n#" +
                    r +
                    " .webengage-webp13-image {display: block;width: 100%;" +
                    a +
                    o +
                    "}"
                );
              },
            };
          },
          {},
        ],
        "webengage/web-personalization-prep": [
          function (p, e, t) {
            "use strict";
            var m = p("webengage/logger"),
              h = p("webengage/dom"),
              v = X.require("webengage/animate"),
              f = p("webengage/events"),
              y = p("webengage/comm"),
              x = p("webengage/weq"),
              E = p("webengage/util"),
              _ = p("webengage/properties"),
              S = X.require("webengage/async"),
              C = X.require("webengage/xpath"),
              I = p("webengage/logger"),
              a = p("webengage/load");
            function r(b, t) {
              function n(e, t, n, i, o) {
                console.time("--- prepare > appendWebPersonalizationHTML_ ---"),
                  I.debug({ msg: "WEB PERSONALIZATIONS HTML", ctx: e });
                var a = e.data;
                (a.layoutId = e.layoutEId),
                  (a.selectorEnabled = a.config.selectorEnabled
                    ? a.config.selectorEnabled
                    : null),
                  null === a.selectorEnabled && delete a.selectorEnabled,
                  (a.recommendationData = e.slug_data || null),
                  (a.variationId = e.variationId || null);
                var r,
                  s = a.layoutAttributes,
                  c = s.dom_id.operation || "after",
                  l = s.dom_id.value,
                  g = s.dom_id.type;
                e.config;
                switch (g) {
                  case "id":
                  case "css_selector":
                  case "CSS_SELECTOR":
                  case "ID":
                    "" != l && (r = h.queryOne(l));
                    break;
                  case "xpath":
                    "" != l && (r = C.getXPathElement(l));
                    break;
                  default:
                    "" != l && (r = h.queryOne(l));
                }
                if (!r)
                  return 10 <= X.webPersonalization.retryAttempt
                    ? (m.debug({
                        msg: "WEB PERSONALIZATION WONT BE ATTEMPTED MAX RETRY EXCEEDED",
                        ctx: {
                          retryAttempt: X.webPersonalization.retryAttempt,
                        },
                      }),
                      void o(
                        new Error(
                          "WEB PERSONALIZATIONS MAX RETRY ATTEMPT BREACHED"
                        ),
                        null
                      ))
                    : (a && a.selectorEnabled && !0 === a.selectorEnabled
                        ? (E.sendPostMessage({
                            type: "WE_CW",
                            action:
                              _.CW_POST_MESSAGE_EVENT_NAME
                                .PREVIEW_ADVANCE_CSS_SELECTOR_PLACED_FAILED,
                            data: {},
                          }),
                          m.debug({
                            msg: "SEND POST MESSAGE TO PARENT ðŸš€",
                            ctx: {
                              mode: _.CW_POST_MESSAGE_EVENT_NAME
                                .PREVIEW_ADVANCE_CSS_SELECTOR_PLACED_FAILED,
                            },
                          }))
                        : (E.sendPostMessage({
                            type: "WE_CW",
                            action:
                              _.CW_POST_MESSAGE_EVENT_NAME
                                .PREVIEW_SELECTOR_PLACED_FAILED,
                            data: {},
                          }),
                          m.debug({
                            msg: "SEND POST MESSAGE TO PARENT ðŸš€",
                            ctx: {
                              mode: _.CW_POST_MESSAGE_EVENT_NAME
                                .PREVIEW_SELECTOR_PLACED_FAILED,
                            },
                          })),
                      (X.webPersonalization[e.layoutEId] = !1),
                      void o(
                        new Error("WEB PERSONALIZATIONS DOM ELEMENT MISSING"),
                        null
                      ));
                (X.webPersonalization[e.layoutEId] = !0),
                  E.isPropertyPersonalized(r, c, a) &&
                    o(new Error(l + " - PROPERTY ALREADY PERSONALISED"), null);
                var d = r.parentNode,
                  u = w[e.layoutId].getMarkUp(a),
                  p = h.createElement("div", u);
                switch (
                  ((function (e, t) {
                    if (
                      ((t.actionMap = {}),
                      t.actions && E.isArray(t.actions) && 0 < t.actions.length)
                    )
                      for (var n = 0; n < t.actions.length; n++) {
                        var i = t.actions[n],
                          o =
                            ((s = i.actionLink),
                            void 0,
                            (c = '<a href="' + s + '"></a>'),
                            (l = h.createElement("div", c)),
                            (g = h.queryOne("a", l)),
                            E.trim(g.href));
                        if (i.actionText) var a = E.trim(i.actionText);
                        (t.actionMap[o + "-" + a] = {
                          actionEId: i.actionEId,
                          actionTarget: i.actionTarget,
                        }),
                          (t.actionsTarget = i.actionTarget);
                        var r = h.queryOne(
                          '[data-action-id="' + i.actionEId + '"]',
                          e
                        );
                        r &&
                          (r.setAttribute("data-action-link", o),
                          r.setAttribute("data-action-target", i.actionTarget),
                          r.setAttribute("data-action-is-prime", "true"));
                      }
                    var s, c, l, g;
                    var d = h.query(
                      ".webengage-webp13-custom-code-container a",
                      e
                    );
                    if (d && 0 < d.length)
                      for (var u = 0; u < d.length; u++) {
                        var p = d[u].href,
                          f = d[u].innerHTML,
                          b = t.actionMap[p + "-" + f];
                        b || ((b = {}).actionEId = E.sha1(p)),
                          b &&
                            b.actionEId &&
                            d[u].setAttribute("data-action-id", b.actionEId);
                      }
                  })(p, a),
                  c)
                ) {
                  case "replace":
                    (p.id = r.id),
                      (p.style.opacity = 0),
                      console.time("--- animate fadeOut ---"),
                      v.fadeOut(r, function () {
                        console.timeEnd("--- animate fadeOut ---"),
                          d.replaceChild(p, r),
                          v.fadeIn(p),
                          t(p),
                          n(i, p);
                      });
                    break;
                  case "before":
                    (p.style.opacity = 0),
                      d.insertBefore(p, r),
                      v.fadeIn(p),
                      t(p),
                      n(i, p);
                    break;
                  case "after":
                    (p.style.opacity = 0),
                      d.insertBefore(p, r.nextSibling),
                      v.fadeIn(p),
                      t(p),
                      n(i, p);
                    break;
                  default:
                    r.innerHTML = p;
                }
                I.debug({ msg: "WEB PERSONALIZATIONS APPLIED" }),
                  console.log("[SDK] WEBP APPLIED"),
                  console.timeEnd(
                    "--- prepare > appendWebPersonalizationHTML_ ---"
                  );
                var f = setInterval(function () {
                  var e = K.getElementsByClassName(
                    "webengage-webp13-container"
                  )[0];
                  e &&
                    (e.scrollIntoView({
                      block: "center",
                      behavior: "smooth",
                      inline: "center",
                    }),
                    clearInterval(f));
                }, 100);
                o(null, e),
                  a.selectorEnabled
                    ? (E.sendPostMessage({
                        type: "WE_CW",
                        action:
                          _.CW_POST_MESSAGE_EVENT_NAME
                            .PREVIEW_ADVANCE_CSS_SELECTOR_PLACED_SUCCESS,
                        data: {},
                      }),
                      m.debug({
                        msg: "SEND POST MESSAGE TO PARENT ðŸš€",
                        ctx: {
                          mode: _.CW_POST_MESSAGE_EVENT_NAME
                            .PREVIEW_ADVANCE_CSS_SELECTOR_PLACED_SUCCESS,
                        },
                      }))
                    : (E.sendPostMessage({
                        type: "WE_CW",
                        action:
                          _.CW_POST_MESSAGE_EVENT_NAME
                            .PREVIEW_SELECTOR_PLACED_SUCCESS,
                        data: {},
                      }),
                      m.debug({
                        msg: "SEND POST MESSAGE TO PARENT ðŸš€",
                        ctx: {
                          mode: _.CW_POST_MESSAGE_EVENT_NAME
                            .PREVIEW_SELECTOR_PLACED_SUCCESS,
                        },
                      }));
              }
              function s(e, t) {
                var n = !1;
                if (t && t.length)
                  for (var i = 0; i < t.length; i++) {
                    var o = t[i];
                    if (o.actionEId === e && o.isPrime) {
                      n = !0;
                      break;
                    }
                  }
                return n;
              }
              console.time("--- prepare ---"),
                (X.webPersonalization.retryAttempt += 1);
              var e,
                w = {
                  "6ic378c": p(
                    "webengage/web-personalization-layouts/web-personalization-6ic378c.js"
                  ),
                  "~48381b0": p(
                    "webengage/web-personalization-layouts/web-personalization-~48381b0.js"
                  ),
                  i78ece1: p(
                    "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1.js"
                  ),
                  "1af572eg": p(
                    "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg.js"
                  ),
                  "2341ibfc": p(
                    "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc.js"
                  ),
                  "~20cc4d8h": p(
                    "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h.js"
                  ),
                  "~184fc482": p(
                    "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482.js"
                  ),
                  "~fg00e76": p(
                    "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76.js"
                  ),
                  "~483856a": p(
                    "webengage/web-personalization-layouts/web-personalization-shopify-~483856a.js"
                  ),
                };
              if (X.hideDom && "function" != typeof X.hideDom.abort)
                I.debug({
                  msg: "FLICKER TIMEOUT ELAPSED FOR BANNER WEB PERSONALIZATION",
                });
              else {
                var i = function (e) {
                    var t = h.query("[data-action-id]", e);
                    if (t && t.length)
                      for (var n = 0; n < t.length; n++) {
                        !(function (r) {
                          f.bind(r, "click", function (e) {
                            if (
                              (e.preventDefault
                                ? e.preventDefault()
                                : (e.returnValue = !1),
                              b.opened)
                            ) {
                              var t,
                                n,
                                i = r.getAttribute("data-action-id"),
                                o = r.tagName,
                                a = s(i, b.data.actions);
                              (n =
                                "A" === o
                                  ? ((t = r.getAttribute("href")),
                                    r.getAttribute("target") || "_top")
                                  : ((t = r.getAttribute("data-action-link")),
                                    r.getAttribute("data-action-target"))),
                                "function" == typeof b.click &&
                                  b.click(i, t, a),
                                b.events && b.events.click(i, t, a, n);
                            }
                          });
                        })(t[n]);
                      }
                  },
                  o = function (e, n) {
                    I.debug({ msg: "WEB PERSONALIZATION INIT CALLBACK" }),
                      "function" == typeof e && e();
                    try {
                      var t = b.getBuffer();
                      (b.show = function () {
                        I.debug({
                          msg: "ENTERED WEB PERSONALIZATION SHOW METHOD",
                        });
                        var e = b.data,
                          t = e && e.layoutAttributes;
                        t && t.dom_id && t.dom_id.value;
                        void 0 !== Z &&
                        "IntersectionObserver" in Z &&
                        "IntersectionObserverEntry" in Z &&
                        "isIntersecting" in
                          Z.IntersectionObserverEntry.prototype
                          ? new IntersectionObserver(
                              function (e) {
                                !0 === e[0].isIntersecting &&
                                  (b.opened ||
                                    (b.events &&
                                      "function" == typeof b.events.open &&
                                      b.events.open(),
                                    "function" == typeof b.open && b.open(),
                                    (b.opened = !0)));
                              },
                              { threshold: [0.1] }
                            ).observe(n)
                          : b.opened ||
                            (b.events &&
                              "function" == typeof b.events.open &&
                              b.events.open(),
                            "function" == typeof b.open && b.open(),
                            (b.opened = !0));
                      }),
                        t.show && b.show(),
                        t.close && b.hide(),
                        t.minimize && b.minimize(),
                        t.maximize && b.maximize();
                    } catch (e) {
                      b && b.error && b.error(e.stack);
                    }
                  },
                  a = h.queryOne("head");
                ["i78ece1"].includes(b.layoutId) && (b.data.isPreview = !0);
                try {
                  !(function (e, t) {
                    console.time(
                      "--- prepare > appendWebPersonalizationDynamicStyles_ ---"
                    );
                    var n = e.data;
                    n.variationId = e.variationId || null;
                    var i = w[e.layoutId].getStyles(n),
                      o = h.queryOne("#we-dynamicStyles", t);
                    o && o.remove(),
                      h.css.createStyleNode(i, { id: "we-dynamicStyles" }, t),
                      console.timeEnd(
                        "--- prepare > appendWebPersonalizationDynamicStyles_ ---"
                      );
                  })(b, a),
                    [
                      "1af572eg",
                      "2341ibfc",
                      "~20cc4d8h",
                      "~184fc482",
                      "~fg00e76",
                      "~483856a",
                    ].includes(b.layoutId) &&
                      ((e = b),
                      console.time("--- prepare > applyScript ---"),
                      (e.data.variationId = e.variationId || null),
                      w[e.layoutId].getScripts(e),
                      console.timeEnd("--- prepare > applyScript ---"),
                      (function (e, t) {
                        var n = e.data;
                        n.variationId = e.variationId || null;
                        var i = w[e.layoutId].getFontFace(n),
                          o = h.queryOne("#we-dynamicLinks", t);
                        o && o.remove(), t && (t.innerHTML += i);
                      })(b, a));
                  var r =
                      b.catalogData &&
                      b.catalogData &&
                      b.catalogData.contents &&
                      Array.isArray(b.catalogData.contents) &&
                      0 < b.catalogData.contents.length,
                    c =
                      x.get("webengage.ruleData") &&
                      Array.isArray(
                        x.get("webengage.ruleData").CART_VARIANT_ID
                      ) &&
                      0 < x.get("webengage.ruleData").CART_VARIANT_ID.length;
                  if (["1af572eg", "2341ibfc"].includes(b.layoutEId)) {
                    if (r) {
                      var l;
                      l =
                        b &&
                        b.config &&
                        "boolean" == typeof b.config.excludeOutOfStock &&
                        !0 === b.config.excludeOutOfStock
                          ? b.catalogData.contents.filter(function (e) {
                              return 0 < e.inventoryQuantity && e.imageSrc;
                            })
                          : b.catalogData.contents.filter(function (e) {
                              return e.imageSrc;
                            });
                      try {
                        l.length >= b.config.numberOfProductsInCampaignMax
                          ? (b.slug_data = l.slice(
                              0,
                              b.config.numberOfProductsInCampaignMax
                            ))
                          : l.length >= b.config.numberOfProductsInCampaign
                          ? (b.slug_data = l.slice(
                              0,
                              b.config.numberOfProductsInCampaign
                            ))
                          : (b.slug_data = l.slice(0, l.length));
                      } catch (e) {
                        b.slug_data = l;
                      }
                      if (0 === b.slug_data.length)
                        for (
                          var g = 0;
                          g < b.config.numberOfProductsInCampaign;
                          g++
                        )
                          b.slug_data.push(_.DUMMY_PRODUCT[0]);
                    } else {
                      b.slug_data = [];
                      for (
                        var d = 0;
                        d < b.config.numberOfProductsInCampaign;
                        d++
                      )
                        b.slug_data.push(_.DUMMY_PRODUCT[0]);
                    }
                    n(b, i, o, X.hideDom && X.hideDom.abort, t);
                  } else if (
                    ["~20cc4d8h", "~184fc482", "~fg00e76", "~483856a"].includes(
                      b.layoutId
                    )
                  ) {
                    if (((b.variantIds = []), c))
                      b.variantIds.push(
                        x.get("webengage.ruleData").CART_VARIANT_ID
                      );
                    else if (r) {
                      var u = b.catalogData.contents[0].id;
                      b.variantIds.push(u);
                    }
                    !(function (o, e, a) {
                      var t = o.config.catalog_slug,
                        n = o.config.recommendationName,
                        i = void 0,
                        r =
                          o &&
                          o.catalogData &&
                          E.isArray(o.catalogData.contents) &&
                          0 < o.catalogData.contents.length;
                      if (
                        ((o.slug_data = null),
                        o && o.config && o.config.numberOfProductsInCampaign)
                      ) {
                        o.slug_data = [];
                        for (
                          var s = 0;
                          s < b.config.numberOfProductsInCampaign;
                          s++
                        )
                          b.slug_data.push(_.DUMMY_PRODUCT[0]);
                      }
                      if (
                        (t ||
                          I.warn({ msg: "CATALOG SLUG IS MISSING", ctx: o }),
                        n ||
                          I.warn({
                            msg: "RECOMMENDATION SLUG IS MISSING",
                            ctx: o,
                          }),
                        ["~20cc4d8h", "~184fc482", "~fg00e76"].includes(
                          o.layoutEId
                        ) && !(i = n))
                      )
                        return a(o);
                      if (
                        ["1af572eg", "2341ibfc", "~483856a"].includes(
                          o.layoutEId
                        ) &&
                        !(i = t)
                      )
                        return a(o);
                      I.debug({
                        msg: "FETCHING ACTUAL DATA",
                        ctx: { slug: i },
                      });
                      var c =
                          "https://p.webengage.com:443/users/" +
                          e +
                          "/catalog/" +
                          i,
                        l = x.get("webengage.personalization.host"),
                        g = x.get("webengage.personalization.scheme"),
                        d = x.get("webengage.personalization.port");
                      l &&
                        g &&
                        d &&
                        (c =
                          g +
                          "://" +
                          l +
                          ":" +
                          d +
                          "/users/" +
                          e +
                          "/catalog/" +
                          i);
                      var u = {
                          productIds: [].concat(
                            (function (e) {
                              if (Array.isArray(e)) {
                                for (
                                  var t = 0, n = Array(e.length);
                                  t < e.length;
                                  t++
                                )
                                  n[t] = e[t];
                                return n;
                              }
                              return Array.from(e);
                            })(o.variantIds)
                          ),
                        },
                        p = void 0;
                      if (["~483856a"].includes(o.layoutEId)) {
                        if (
                          !(
                            o &&
                            o.config &&
                            Array.isArray(o.config.productIds) &&
                            0 < o.config.productIds.length
                          )
                        )
                          return (o.slug_data = o.slug_data.slice(0, 1)), a(o);
                        if (r)
                          return (
                            (o.slug_data = []),
                            o.config.productIds.forEach(function (t) {
                              var e = o.catalogData.contents.filter(function (
                                e
                              ) {
                                return e.id == t;
                              });
                              0 < e.length && o.slug_data.push(e[0]);
                            }),
                            a(o)
                          );
                        I.debug({
                          msg: "NO DATA FOR CATALOG RECEIVED FROM POST MESSAGE FETCH CATALOG DATA ",
                          ctx: { slug: i },
                        });
                      }
                      ["~184fc482", "~fg00e76"].includes(o.layoutEId) &&
                        0 === u.productIds.length &&
                        r &&
                        ((p = o.catalogData.contents[0].id),
                        u.productIds.push(p)),
                        (u.filters = []),
                        "boolean" == typeof o.config.excludeOutOfStock &&
                          !0 === o.config.excludeOutOfStock &&
                          u.filters.push({
                            attribute_name:
                              _.P13_FILTERS.PRODUCT_SLUG.AVAILABLE,
                            operation: "GREATER THAN",
                            value: 0,
                          }),
                        "boolean" == typeof o.config.showSameCategory &&
                          !0 === o.config.showSameCategory &&
                          u.filters.push({
                            attribute_name:
                              _.P13_FILTERS.PRODUCT_SLUG.PRODUCT_CATEGORY,
                            operation: "CONTAINS",
                            value: x.get("webengage.ruleData")
                              .CART_CATEGORY || [p.productType],
                          }),
                        0 === u.filters.length && delete u.filters,
                        u &&
                          u.productIds &&
                          0 === u.productIds.length &&
                          I.debug({
                            msg: "P13 PREVIEW API CALLED WITH NO PRODUCTID'S FOR FILTER",
                            ctx: { slug: i },
                          }),
                        ["~20cc4d8h"].includes(o.layoutEId) &&
                          delete u.productIds;
                      var f = E.stringify(E.transit.encode(u));
                      try {
                        y.raw(
                          E.addParamsToURL(c, {
                            pageSize: b.config.numberOfProductsInCampaignMax,
                          }),
                          f,
                          function (e) {
                            !(function (e) {
                              I.debug({
                                msg: "XHR CALLBACK RECEIVED",
                                ctx: { entity: o, data: e },
                              });
                              var t = [];
                              if (e && e.content && 0 < e.content.length) {
                                for (var n = 0; n < e.content.length; n++) {
                                  var i = e.content[n];
                                  t.push(i);
                                }
                                return (
                                  0 < t.length
                                    ? (o.slug_data = t)
                                    : I.debug({
                                        msg: "PREVIEW WEB PERSONALIZATION DATA NOT FOUND SEND DUMMY PRODUCT",
                                      }),
                                  a(o)
                                );
                              }
                              a(o);
                            })(E.parseJSON(e));
                          }
                        );
                      } catch (e) {
                        I.error({ msg: "P13 PREVIEW API ERROR ", ctx: e });
                      }
                    })(b, x.get("webengage.licenseCode"), function (e) {
                      n(b, i, o, X.hideDom && X.hideDom.abort, t);
                    });
                  } else n(b, i, o, X.hideDom && X.hideDom.abort, t);
                  (function (e, t) {
                    var n = e.data,
                      i =
                        (n.layoutAttributes.banner_image &&
                          n.layoutAttributes.banner_image.imageUrl &&
                          n.layoutAttributes.banner_image.imageUrl.trim()) ||
                        "",
                      o = [];
                    if (i) {
                      var a = K.createElement("IMG");
                      (a.src = i), o.push(a);
                    }
                    o.length
                      ? S.mapParallel(
                          o,
                          function (e, t) {
                            f.bind(e, "load", function () {
                              t();
                            }),
                              f.bind(e, "error", function () {
                                t();
                              });
                          },
                          t
                        )
                      : "function" == typeof t && t();
                  })(b, function () {});
                } catch (e) {
                  I.error({ msg: e.message });
                }
              }
              console.timeEnd("--- prepare ---");
            }
            e.exports = {
              prepare: function (t, n) {
                try {
                  if (
                    ((X.webPersonalization.layout =
                      X.webPersonalization.layout || {}),
                    Z.webengage.webPersonalization,
                    (t.data = {}),
                    (t.data.config = t.config || {}),
                    (t.data.layoutAttributes = t.layoutAttributes || {}),
                    (t.parentDom = h),
                    t.dom || (t.dom = h),
                    "function" != typeof t.getBuffer)
                  ) {
                    var e = { show: !1, hide: !1 };
                    (t.show = function () {
                      e.show = !0;
                    }),
                      (t.hide = function () {
                        e.hide = !0;
                      }),
                      (t.minimize = function () {
                        e.minimize = !0;
                      }),
                      (t.getBuffer = function () {
                        return e;
                      });
                  }
                  (t.baseURL =
                    ("http:" == location.protocol ? "http:" : "https:") +
                    "//ssl.widgets.webengage.com/"),
                    (t.appHost = "webengage.com");
                  var i = t.layoutId || t.layoutEId,
                    o =
                      t.baseURL + "js/web-personalization-shopify-" + i + ".js";
                  return (
                    (t.layoutId = t.layoutEId),
                    X.webPersonalization.layout &&
                    X.webPersonalization.layout[i]
                      ? r(t, n)
                      : a.script(o)(function (e) {
                          try {
                            if (e) throw n(e, null);
                            (X.webPersonalization.layout[i] = p(
                              "webengage/web-personalization-layouts/web-personalization-shopify-" +
                                i
                            )),
                              r(t, n);
                          } catch (e) {
                            f.publish("error", e),
                              t.error && t.error(e.stack),
                              n(e, null);
                          }
                        }),
                    t
                  );
                } catch (e) {
                  m.error({ msg: "WEB PERSONALIZATION PREP ERROR", ctx: e }),
                    t.error && t.error(e.stack);
                }
              },
            };
          },
          {
            "webengage/web-personalization-layouts/web-personalization-6ic378c.js":
              "webengage/web-personalization-layouts/web-personalization-6ic378c",
            "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-1af572eg",
            "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-2341ibfc",
            "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1",
            "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~184fc482",
            "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~20cc4d8h",
            "webengage/web-personalization-layouts/web-personalization-shopify-~483856a.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~483856a",
            "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-~fg00e76",
            "webengage/web-personalization-layouts/web-personalization-~48381b0.js":
              "webengage/web-personalization-layouts/web-personalization-~48381b0",
          },
        ],
        "webengage/web-personalization": [
          function (x, e, t) {
            "use strict";
            var w = x("webengage/dom"),
              f = X.require("webengage/animate"),
              s = x("webengage/engagement"),
              l = x("webengage/events"),
              E = x("webengage/comm"),
              _ = x("webengage/state"),
              S = x("webengage/weq"),
              C = x("webengage/util"),
              I = x("webengage/properties"),
              g = X.require("webengage/async"),
              b = X.require("webengage/xpath"),
              T = x("webengage/logger");
            function n(s) {
              function c(e, t) {
                var n = !1;
                if (t && t.length)
                  for (var i = 0; i < t.length; i++) {
                    var o = t[i];
                    if (o.actionEId === e && o.isPrime) {
                      n = !0;
                      break;
                    }
                  }
                return n;
              }
              s.events.prepare();
              var e,
                t,
                n,
                i,
                o,
                a,
                p = {
                  "~48381b0": x(
                    "webengage/web-personalization-layouts/web-personalization-~48381b0.js"
                  ),
                  "6ic378c": x(
                    "webengage/web-personalization-layouts/web-personalization-6ic378c.js"
                  ),
                  "~184fc482": x(
                    "webengage/web-personalization-layouts/web-personalization-shopify-m~184fc482.js"
                  ),
                  i78ece1: x(
                    "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1.js"
                  ),
                  "2341ibfc": x(
                    "webengage/web-personalization-layouts/web-personalization-shopify-m~184fc482.js"
                  ),
                  "1af572eg": x(
                    "webengage/web-personalization-layouts/web-personalization-shopify-m~184fc482.js"
                  ),
                  "~fg00e76": x(
                    "webengage/web-personalization-layouts/web-personalization-shopify-m~184fc482.js"
                  ),
                  "~483856a": x(
                    "webengage/web-personalization-layouts/web-personalization-shopify-m~184fc482.js"
                  ),
                  "~20cc4d8h": x(
                    "webengage/web-personalization-layouts/web-personalization-shopify-m~184fc482.js"
                  ),
                };
              if (X.hideDom && "function" != typeof X.hideDom.abort)
                T.debug({
                  msg: "FLICKER TIMEOUT ELAPSED FOR BANNER WEB PERSONALIZATION",
                });
              else {
                var r = w.queryOne("head");
                T.debug({
                  msg:
                    "STARTING TO CREATE A " +
                    s.layoutId +
                    " WEB PERSONALIZATION",
                }),
                  ["i78ece1"].includes(s.layoutId) && (s.data.isPreview = !1);
                try {
                  (i = r),
                    (o = (n = s).data),
                    (a = p[n.layoutId].getStyles(o)),
                    w.css.createStyleNode(a, { id: "we-dynamicStyles" }, i),
                    [
                      "1af572eg",
                      "2341ibfc",
                      "~20cc4d8h",
                      "~184fc482",
                      "~fg00e76",
                      "~483856a",
                    ].includes(s.layoutId) &&
                      ((t = (e = s).data), p[e.layoutId].getScripts(t)),
                    (function (e, t, n, i) {
                      var o,
                        a = e.data,
                        r = a.layoutAttributes,
                        s = r.dom_id.op || "replace",
                        c = r.dom_id.value,
                        l = r.dom_id.type;
                      switch (((a.layoutId = e.layoutId), l)) {
                        case "id":
                        case "css_selector":
                        case "CSS_SELECTOR":
                        case "ID":
                          "" != c && (o = w.queryOne(c));
                          break;
                        case "xpath":
                          "" != c && (o = b.getXPathElement(c));
                          break;
                        default:
                          "" != c && (o = w.queryOne(c));
                      }
                      if (o) {
                        if (C.isPropertyPersonalized(o, s, a))
                          throw new Error(
                            c + " - PROPERTY ALREADY PERSONALISED"
                          );
                        var g = o.parentNode,
                          d = p[e.layoutId].getMarkUp(a),
                          u = w.createElement("div", d);
                        switch (
                          ((function (e, t) {
                            if (
                              ((t.actionMap = {}),
                              t.actions &&
                                C.isArray(t.actions) &&
                                0 < t.actions.length)
                            )
                              for (var n = 0; n < t.actions.length; n++) {
                                var i = t.actions[n],
                                  o =
                                    ((s = i.actionLink),
                                    (c = '<a href="' + s + '"></a>'),
                                    (l = w.createElement("div", c)),
                                    (g = w.queryOne("a", l)),
                                    C.trim(g.href));
                                if (i.actionText) var a = C.trim(i.actionText);
                                (t.actionMap[o + "-" + a] = {
                                  actionEId: i.actionEId,
                                  actionTarget: i.actionTarget,
                                }),
                                  (t.actionsTarget = i.actionTarget);
                                var r = w.queryOne(
                                  '[data-action-id="' + i.actionEId + '"]',
                                  e
                                );
                                r &&
                                  (r.setAttribute("data-action-link", o),
                                  r.setAttribute(
                                    "data-action-target",
                                    i.actionTarget
                                  ),
                                  r.setAttribute(
                                    "data-action-is-prime",
                                    "true"
                                  ));
                              }
                            var s,
                              c,
                              l,
                              g,
                              d = w.query(
                                ".webengage-webp13-custom-code-container a",
                                e
                              );
                            if (d && 0 < d.length)
                              for (var u = 0; u < d.length; u++) {
                                var p = d[u].href,
                                  f = d[u].innerHTML,
                                  b = t.actionMap[p + "-" + f];
                                b || ((b = {}).actionEId = C.sha1(p)),
                                  b &&
                                    b.actionEId &&
                                    d[u].setAttribute(
                                      "data-action-id",
                                      b.actionEId
                                    );
                              }
                          })(u, a),
                          s)
                        ) {
                          case "replace":
                            e.events.render(),
                              (u.id = o.id),
                              (u.style.opacity = 0),
                              f.fadeOut(o, function () {
                                g.replaceChild(u, o),
                                  f.fadeIn(u),
                                  t(u),
                                  n(i, u);
                              });
                            break;
                          case "before":
                            e.events.render(),
                              (u.style.opacity = 0),
                              g.insertBefore(u, o),
                              f.fadeIn(u),
                              t(u),
                              n(i, u);
                            break;
                          case "after":
                            e.events.render(),
                              (u.style.opacity = 0),
                              g.insertBefore(u, o.nextSibling),
                              f.fadeIn(u),
                              t(u),
                              n(i, u);
                            break;
                          default:
                            e.events.render(), (o.innerHTML = u);
                        }
                        T.debug({ msg: "WEB PERSONALIZATIONS APPLIED" });
                      } else
                        T.debug({
                          msg:
                            "WEB PERSONALIZATIONS DOM ELEMENT MISSING for layout: " +
                            e.layoutId,
                        });
                    })(
                      s,
                      function (e) {
                        var t = w.query("[data-action-id]", e);
                        if (t && t.length)
                          for (var n = 0; n < t.length; n++)
                            !(function (r) {
                              l.bind(r, "click", function (e) {
                                if (
                                  (e.preventDefault
                                    ? e.preventDefault()
                                    : (e.returnValue = !1),
                                  s.opened)
                                ) {
                                  var t,
                                    n,
                                    i = r.getAttribute("data-action-id"),
                                    o = r.tagName,
                                    a = c(i, s.data.actions);
                                  (n =
                                    "A" === o
                                      ? ((t = r.getAttribute("href")),
                                        r.getAttribute("target") || "_top")
                                      : ((t =
                                          r.getAttribute("data-action-link")),
                                        r.getAttribute("data-action-target"))),
                                    "function" == typeof s.click &&
                                      s.click(i, t, a),
                                    s.events && s.events.click(i, t, a, n);
                                }
                              });
                            })(t[n]);
                      },
                      function (e, n) {
                        T.debug({ msg: "WEB PERSONALIZATION INIT CALLBACK" }),
                          "function" == typeof e && e();
                        try {
                          var t = s.getBuffer();
                          (s.show = function () {
                            T.debug({
                              msg: "ENTERED WEB PERSONALIZATION SHOW METHOD",
                            });
                            var e = s.data,
                              t = e && e.layoutAttributes;
                            t && t.dom_id && t.dom_id.value,
                              void 0 !== Z &&
                              "IntersectionObserver" in Z &&
                              "IntersectionObserverEntry" in Z &&
                              "isIntersecting" in
                                Z.IntersectionObserverEntry.prototype
                                ? new IntersectionObserver(
                                    function (e) {
                                      !0 === e[0].isIntersecting &&
                                        (s.opened ||
                                          (s.events &&
                                            "function" ==
                                              typeof s.events.open &&
                                            s.events.open(),
                                          "function" == typeof s.open &&
                                            s.open(),
                                          (s.opened = !0)));
                                    },
                                    { threshold: [0.1] }
                                  ).observe(n)
                                : s.opened ||
                                  (s.events &&
                                    "function" == typeof s.events.open &&
                                    s.events.open(),
                                  "function" == typeof s.open && s.open(),
                                  (s.opened = !0));
                          }),
                            t.show && s.show(),
                            t.close && s.hide(),
                            t.minimize && s.minimize(),
                            t.maximize && s.maximize();
                        } catch (e) {
                          s && s.error && s.error(e.stack);
                        }
                      },
                      X.hideDom && X.hideDom.abort
                    ),
                    (function (e, t) {
                      var n = e.data,
                        i =
                          (n.layoutAttributes.banner_image &&
                            n.layoutAttributes.banner_image.imageUrl &&
                            n.layoutAttributes.banner_image.imageUrl.trim()) ||
                          "",
                        o = [];
                      if (i) {
                        var a = K.createElement("IMG");
                        (a.src = i), o.push(a);
                      }
                      o.length
                        ? g.mapParallel(
                            o,
                            function (e, t) {
                              l.bind(e, "load", function () {
                                t();
                              }),
                                l.bind(e, "error", function () {
                                  t();
                                });
                            },
                            t
                          )
                        : "function" == typeof t && t();
                    })(s, function () {});
                } catch (e) {
                  T.debug({ msg: e.message });
                }
              }
            }
            function i(e) {
              return (
                e.dynamicElementDataFetch
                  ? (e.dynamicElementDataFetch = !1)
                  : X.hideDom && "function" != typeof X.hideDom.abort
                  ? T.debug({
                      msg: "FLICKER TIMEOUT ELAPSED FOR BANNER WEB PERSONALIZATION",
                    })
                  : (l.subscribe(
                      "webPersonalization.click." + e.instance.id,
                      function (e) {
                        var t = e.actionTarget,
                          n = e.actionLink;
                        "_blank" !== t ? (Z.location.href = n) : Z.open(n, t);
                      }
                    ),
                    n(e.instance)),
                e
              );
            }
            function o(e, t, n, i, o) {
              var a,
                r = {};
              return (
                (r.activity = s.util.getActivity()),
                e.data &&
                  (C.copy(r, {
                    webPersonalizationId: (a = e).id,
                    licenseCode: S.get("webengage.licenseCode"),
                    propertyType: a.data.layoutAttributes.dom_id.type,
                    propertyName:
                      a.data.layoutAttributes.dom_id.xpathVariableName,
                    propertyValue: a.data.layoutAttributes.dom_id.value,
                    operation: a.data.layoutAttributes.dom_id.op,
                  }),
                  (r.isWebPersonalizationClickable = !(
                    !e.data.actions || !e.data.actions.length
                  ))),
                t && (r.actionId = t),
                n && (r.actionLink = n),
                i && (r.primeAction = !0),
                (r.actionTarget = o || "_top"),
                r
              );
            }
            function a(a, r, s) {
              if (X.hideDom && "function" != typeof X.hideDom.abort)
                T.debug({
                  msg: "FLICKER TIMEOUT ELAPSED FOR BANNER WEB PERSONALIZATION",
                });
              else {
                var e = a.webPersonalizationEncId,
                  t = _.getForever(),
                  n = _.getSession(),
                  i =
                    webengage_fs_configurationMap.webPersonalizationRuleList ||
                    [],
                  o = (n.upf && n.upf.journey) || {},
                  c = {};
                t.cuid && (c.cuid = t.cuid);
                for (var l = 0; l < i.length; l++)
                  if (e === i[l].webPersonalizationEncId) {
                    i[l].journeyId &&
                      o[i[l].journeyId] &&
                      ((c.journey_id = i[l].journeyId),
                      (c.context_id = o[i[l].journeyId].id));
                    break;
                  }
                for (
                  var g =
                      "https://p.webengage.com:443/users/" +
                      r +
                      "/" +
                      t.luid +
                      "/templates/multi-id",
                    d = [],
                    u = x("webengage/profile").getPersonalizationContext(
                      a[0].webPersonalizationEncId,
                      a[0].instance.tokens
                    ),
                    p = 0;
                  p < a.length;
                  p++
                )
                  d.push("WEB_PERSONALIZATION-" + a[p].webPersonalizationEncId);
                if (
                  ((u.templateIds = d),
                  !0 === S.get("webengage.isShopifyClient"))
                ) {
                  u.filters = {};
                  for (var f = 0; f < a.length; f++) {
                    var b =
                      "WEB_PERSONALIZATION-" + a[f].webPersonalizationEncId;
                    (u.filters[b] = []),
                      ("~fg00e76" !== a[f].variations[0].layout &&
                        "~483856a" !== a[f].variations[0].layout &&
                        "~184fc482" !== a[f].variations[0].layout &&
                        "~20cc4d8h" !== a[f].variations[0].layout) ||
                        (!0 === a[f].variations[0].showSameCategory &&
                          u.filters[b].push({
                            attribute_name:
                              I.P13_FILTERS.PRODUCT_SLUG.PRODUCT_CATEGORY,
                            operation: "CONTAINS",
                            value:
                              S.get("webengage.ruleData") &&
                              Array.isArray(
                                S.get("webengage.ruleData").CART_CATEGORY
                              )
                                ? S.get(
                                    "webengage.ruleData"
                                  ).CART_CATEGORY.filter(function (e) {
                                    return e;
                                  })
                                : [],
                          }),
                        !0 === a[f].variations[0].excludeOutOfStock &&
                          u.filters[b].push({
                            attribute_name:
                              I.P13_FILTERS.PRODUCT_SLUG.AVAILABLE,
                            operation: "GREATER THAN",
                            value: 0,
                          }),
                        "~483856a" !== a[f].variations[0].layout &&
                          (u.filters[b].push({
                            attribute_name:
                              I.P13_FILTERS.PRODUCT_SLUG.PRODUCT_ID,
                            operation: "NOT CONTAINS",
                            value:
                              S.get("webengage.ruleData") &&
                              Array.isArray(
                                S.get("webengage.ruleData").CART_PRODUCT_ID
                              )
                                ? S.get("webengage.ruleData").CART_PRODUCT_ID
                                : [],
                          }),
                          u.filters[b].push({
                            attribute_name:
                              I.P13_FILTERS.PRODUCT_SLUG.VARIANT_ID,
                            operation: "NOT CONTAINS",
                            value:
                              S.get("webengage.ruleData") &&
                              Array.isArray(
                                S.get("webengage.ruleData").CART_VARIANT_ID
                              )
                                ? S.get("webengage.ruleData").CART_VARIANT_ID
                                : [],
                          })));
                  }
                }
                var w = S.get("webengage.personalization.host"),
                  m = S.get("webengage.personalization.scheme"),
                  h = S.get("webengage.personalization.port");
                w &&
                  m &&
                  h &&
                  (g =
                    m +
                    "://" +
                    w +
                    ":" +
                    h +
                    "/users/" +
                    r +
                    "/" +
                    t.luid +
                    "/templates/multi-id");
                var v = C.stringify(C.transit.encode(u));
                try {
                  E.raw(C.addParamsToURL(g, c), v, function (e) {
                    y(C.parseJSON(e));
                  });
                } catch (e) {
                  (c.c = C.compress.compressToBase64(v)),
                    E.jsonp(C.addParamsToURL(g, c), y, "p");
                }
              }
              function y(e) {
                for (var t = [], n = 0; n < e.length; n++) {
                  var i = e[n].value;
                  if (i && i.templateData && i.status && i.status.success)
                    if (
                      ((i = i.templateData),
                      ("~48381b0" != a[n].layout && "i78ece1" != a[n].layout) ||
                        (i.layoutAttributes.banner_image &&
                          i.layoutAttributes.banner_image.imageUrl))
                    ) {
                      var o = S.get("webengage.direction");
                      ("ltr" !== o && "rtl" !== o) || (i.direction = o),
                        (i.licenseCode = r),
                        (i.webengageHost = "//webengage.com"),
                        T.debug({
                          msg: "WEB PERSONALIZATION DATA",
                          ctx: { id: i.id, data: i },
                        }),
                        t.push(i);
                    } else
                      a[n].clearEntity(),
                        T.warn({
                          msg: "WEB PERSONALIZATION BANNER IMAGE MISSING",
                          ctx: { id: i.id, data: i },
                        });
                  else
                    a[n].clearEntity(),
                      T.warn({
                        msg: "WEB PERSONALIZATION INVALID DATA",
                        ctx: {
                          id: a[n].webPersonalizationEId,
                          data: e[n].reason,
                        },
                      });
                }
                s(t);
              }
            }
            function r(e) {
              if (e && e.instance && e.instance.id)
                for (var t = 0; t < I.instanceCallbacks.length; t++) {
                  var n = I.instanceCallbacks[t];
                  l.desubscribe(
                    "webPersonalization." + n + "." + e.instance.id
                  );
                }
            }
            function c(e) {
              if (e && e.instance) {
                var t = e.instance;
                t.clear && t.clear(),
                  (t.opened = null),
                  (t.layoutId = null),
                  (t.baseURL = null),
                  (t.appHost = null),
                  (t.dom = null),
                  (t.parentDom = null),
                  t.reset(),
                  r(e);
              }
            }
            function d(e) {
              for (
                var t, n = w.query(".webengage-webp13-container"), i = 0;
                i < n.length;
                i++
              )
                w.remove(n[i]);
              (t = e) &&
                t.length &&
                C.mapArray(t, function (e) {
                  r(e);
                });
            }
            e.exports = function () {
              var e = new s("webPersonalization", {
                methods: {
                  prepare: i,
                  getCallbackData: o,
                  getData: a,
                  clear: d,
                  clearEntity: c,
                },
              });
              return T.debug({ msg: "WEB PERSONALIZATION INIT" }), e;
            };
          },
          {
            "webengage/web-personalization-layouts/web-personalization-6ic378c.js":
              "webengage/web-personalization-layouts/web-personalization-6ic378c",
            "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-i78ece1",
            "webengage/web-personalization-layouts/web-personalization-shopify-m~184fc482.js":
              "webengage/web-personalization-layouts/web-personalization-shopify-m~184fc482",
            "webengage/web-personalization-layouts/web-personalization-~48381b0.js":
              "webengage/web-personalization-layouts/web-personalization-~48381b0",
          },
        ],
        "webengage/web-push/commons": [
          function (e, t, n) {
            "use strict";
            var a = e("webengage/properties"),
              i = e("webengage/ua"),
              r = e("webengage/events"),
              s = e("webengage/weq"),
              o = e("webengage/state"),
              c = e("webengage/util"),
              l = e("webengage/tracker"),
              g = e("webengage/rules"),
              d = null;
            function u(e, t) {
              var n = 0,
                i = !1,
                o = Z.setInterval(function () {
                  e() && (Z.clearInterval(o), t(i)),
                    50 < n++ && (Z.clearInterval(o), t((i = !0)));
                }, 10);
            }
            function p(t) {
              "function" === c.type(t) &&
                ("PushManager" in Z &&
                (("http:" === Z.location.protocol &&
                  (("Chrome" === i.browser && 69 <= i.version) ||
                    ("Firefox" === i.browser && 63 <= i.version) ||
                    ("Opera" === i.browser && 56 <= i.version) ||
                    ("Safari" === i.browser && 16 <= i.version))) ||
                  "serviceWorker" in navigator) &&
                (!(
                  ("Chrome" !== i.browser &&
                    "Firefox" !== i.browser &&
                    "Opera" !== i.browser &&
                    "Safari" !== i.browser) ||
                  ("Android" !== i.os &&
                    "Desktop" !== i.device &&
                    "Mac" !== i.os &&
                    "iOS" != i.os)
                ) ||
                  ("Edge" === i.browser &&
                    webengage_fs_configurationMap &&
                    webengage_fs_configurationMap.config &&
                    webengage_fs_configurationMap.config.webPushConfig &&
                    webengage_fs_configurationMap.config.webPushConfig
                      .vapidPublicKey)) &&
                ("Safari" !== i.browser ||
                  (s.get("webengage.safariWebPush") &&
                    ("iOS" !== i.os ||
                      navigator.standalone ||
                      Z.matchMedia("(display-mode: standalone)").matches)))
                  ? (function (t) {
                      var n;
                      if (
                        "storage" in navigator &&
                        "estimate" in navigator.storage
                      )
                        navigator.storage.estimate().then(function (e) {
                          n = e.quota < 12e7;
                        });
                      else if (Z.webkitRequestFileSystem)
                        Z.webkitRequestFileSystem(
                          Z.TEMPORARY,
                          1,
                          function () {
                            n = !1;
                          },
                          function (e) {
                            n = !0;
                          }
                        );
                      else if (
                        Z.indexedDB &&
                        /Firefox/.test(Z.navigator.userAgent)
                      ) {
                        var i;
                        try {
                          i = Z.indexedDB.open("test");
                        } catch (e) {
                          n = !0;
                        }
                        void 0 === n &&
                          u(
                            function () {
                              return "done" === i.readyState;
                            },
                            function (e) {
                              e || (n = !i.result);
                            }
                          );
                      } else if (
                        Z.localStorage &&
                        /Safari/.test(Z.navigator.userAgent)
                      ) {
                        try {
                          Z.localStorage.setItem("test", 1);
                        } catch (e) {
                          n = !0;
                        }
                        void 0 === n &&
                          ((n = !1), Z.localStorage.removeItem("test"));
                      }
                      u(
                        function () {
                          return void 0 !== n;
                        },
                        function (e) {
                          t(n);
                        }
                      );
                    })(function (e) {
                      t(!e);
                    })
                  : t(!1));
            }
            t.exports = {
              ready: function (e) {
                d = e;
              },
              getContext: function () {
                return l.base();
              },
              getPersonalizationContext: function () {
                return {
                  screen: {
                    system: { screen_name: s.get("webengage.screenName") },
                    custom: s.get("webengage.tokens") || {},
                  },
                };
              },
              incrementPromptViews: function () {
                var e = o.getSession();
                (e.wp_pvc = (e.wp_pvc || 0) + 1), o.setSession(e);
              },
              canPrompt: function () {
                var e = o.getSession();
                return !(
                  e.wp_pvc &&
                  "number" === c.type(d.maxPromptsPerSession) &&
                  e.wp_pvc >= d.maxPromptsPerSession
                );
              },
              base64Encode: function (e) {
                return btoa(
                  encodeURIComponent(e).replace(
                    /%([0-9A-F]{2})/g,
                    function (e, t) {
                      return String.fromCharCode("0x" + t);
                    }
                  )
                );
              },
              isPushNotificationsSupported: p,
              ifPushReady: function t(n) {
                p(function (e) {
                  e && ((t.result = !0), n());
                });
              },
              ifRules: function n(i) {
                if (!0 !== s.get("webengage.webpush.disablePrompt")) {
                  var e = d.pageRuleCode || "true",
                    o = d.eventRuleCode || "true";
                  d.sessionRuleCode &&
                    (d.ecp
                      ? (o += " && " + d.sessionRuleCode)
                      : (e += " && " + d.sessionRuleCode)),
                    g.evaluate(
                      null,
                      e,
                      s.get("webengage.ruleData") || {}
                    )(function (e, t) {
                      t &&
                        g.evaluate(
                          null,
                          o
                        )(function (e, t) {
                          if (t) return (n.result = !0), i();
                          n.subscriber &&
                            r.unsubscribe(
                              a.CHANNEL_PROFILE_UPDATED,
                              n.subscriber
                            ),
                            (n.subscriber = function () {
                              g.evaluate(
                                null,
                                o
                              )(function (e, t) {
                                if (t)
                                  return (
                                    (n.result = !0),
                                    r.unsubscribe(
                                      a.CHANNEL_PROFILE_UPDATED,
                                      n.subscriber
                                    ),
                                    i()
                                  );
                              });
                            }),
                            r.subscribe(
                              a.CHANNEL_PROFILE_UPDATED,
                              n.subscriber
                            );
                        });
                    });
                }
              },
              eventsCallbackHook: function (e) {
                var t = s.get("webengage.webpush." + e),
                  n = l.base();
                "function" == typeof t && c.guard(t, !0)(n);
              },
              canShowNative: function () {
                return !(
                  ("Firefox" === i.browser && 72 <= i.version) ||
                  ("Edge" === i.browser && 84 <= i.version) ||
                  ("Safari" === i.browser && 16 <= i.version)
                );
              },
              canShowOnsite: function (e) {
                if (Notification.permission === a.WP_PERMISSION_DEFAULT) {
                  var t = o.getForever();
                  return (
                    "box" !== e ||
                    !t.wp_dts ||
                    "number" !== c.type(d.reOptInDuration) ||
                    (!(
                      -1 === d.reOptInDuration ||
                      t.wp_dts + d.reOptInDuration > new Date().getTime()
                    ) &&
                      (delete t.wp_dts, o.setForever(t), !0))
                  );
                }
              },
            };
          },
          {},
        ],
        "webengage/web-push": [
          function (i, e, t) {
            "use strict";
            var o = i("webengage/events"),
              a = i("webengage/state"),
              r = (i("webengage/logger"), i("webengage/properties")),
              s = i("webengage/web-push/commons"),
              c = null;
            e.exports = {
              init: function () {
                var n = webengage_fs_configurationMap.config.webPushConfig;
                n &&
                  webengage_fs_configurationMap.config.enableWebPush &&
                  s.ifPushReady(function () {
                    (c = n.singleOptIn
                      ? i("webengage/web-push/one-step")
                      : n.reverseDoubleOptIn
                      ? i("webengage/web-push/reverse-two-step")
                      : i("webengage/web-push/two-step")),
                      s.ready(n),
                      c.ready(n),
                      o.subscribe(r.SYSTEM_CATEGORY_EVENT, function (e) {
                        (e !== r.EVENTS_NEW_SESSION &&
                          e !== r.EVENTS_USER_LOGGED_IN) ||
                          c.contextChange(e);
                      }),
                      1 === a.getSession().pvc &&
                        c.contextChange(r.EVENTS_NEW_SESSION),
                      s.ifRules(function () {
                        c.showOptin();
                      });
                    var e = a.getForever(),
                      t = n.singleOptIn ? "one-step" : "two-step";
                    (e.wp_optin_type && e.wp_optin_type === t) ||
                      ((e.wp_optin_type = t), a.setForever(e));
                  });
              },
              isSubscribed: function () {
                var e = a.getForever();
                return (
                  e.wp_status === r.WP_PERMISSION_GRANTED && !!e.interface_id
                );
              },
              prompt: function () {
                c && c.prompt();
              },
              onSubscribe: function (e) {
                o.subscribe(r.CHANNEL_WP_SUBSCRIBED, e);
              },
              isPushNotificationsSupported: s.isPushNotificationsSupported,
            };
          },
          {},
        ],
        "webengage/web-push/one-step-layouts": [
          function (a, e, t) {
            "use strict";
            var r = a("webengage/dom"),
              s = a("webengage/events"),
              c = a("webengage/properties"),
              l = a("webengage/web-push/commons"),
              g = a("webengage/colors"),
              n = a("webengage/ua"),
              i = a("webengage/state"),
              d = null,
              u = 425,
              o = n.browser;
            function p() {
              return a(
                "../../../makeup/make-up-widget/sass/web-push/web-push-prompt.scss"
              );
            }
            function f() {
              var e = r.iframe.get("webpush-onsite");
              e && r.iframe.remove(e);
            }
            e.exports = {
              showHint: function () {
                if (l.canShowOnsite() && !r.iframe.get("webpush-hint")) {
                  var e = {
                    height: "100%",
                    width: "100%",
                    visibility: "visible",
                    display: "block",
                    position: "fixed",
                    top: "0px",
                    left: "0px",
                    background: "rgba(0,0,0,0.8)",
                  };
                  (e["z-index"] = r.css.getMaxZIndex() + 1),
                    r.iframe.create({
                      name: "webpush-hint",
                      css: e,
                      onload: function (e) {
                        var t = r.iframe.getDoc(e),
                          n = K.createElement("div");
                        (n.id = "hint-container"),
                          t.body.appendChild(n),
                          (n.innerHTML =
                            '<div class="wrapper"><div class="hint-content"><div class="hint-arrow"></div><div>' +
                            d.optInNotificationContent.nativeText +
                            "</div></div></div>"),
                          r.css.createStyleNode(
                            ".wrapper {width: 100%;height: 100%;}\n.hint-content {margin: auto;top: 190px;left: 340px;position: absolute;width: auto;max-width: 315px;color: #ffffff;font-size: larger;font-family: 'Open Sans', Arial, Helvetica, sans-serif;font-weight: 400;line-height: 1.5;display: flex;flex-direction: column;}\n.hint-arrow {width: 60px;height: 80px;background-size: contain;transform: rotate(160deg);background-image: url(https://d107ygk0jso0v4.cloudfront.net/frontline/images/web-push/arrow-c47dab6df794cf360eca22ec228d8686.png);background-repeat: no-repeat;}\n" +
                              ("Edge" === o
                                ? ".hint-content {bottom: 190px;}\n.hint-arrow {order: 2;transform: rotate(-10deg);margin-left: auto;}"
                                : "") +
                              "\n",
                            {},
                            t.head
                          );
                      },
                    });
                }
              },
              showBell: function () {
                var e;
                if (l.canShowOnsite() && !r.iframe.get("webpush-onsite")) {
                  var t = d.optInNotificationContent.position.split("-"),
                    n = {
                      height: "48px",
                      width: "48px",
                      visibility: "visible",
                      display: "block",
                      position: "fixed",
                    };
                  (n["z-index"] = r.css.getMaxZIndex()),
                    (n[t[0]] = "20px"),
                    (n[t[1]] = "20px");
                  var i = r.iframe.create({
                    name: "webpush-onsite",
                    css: n,
                    onload: function (e) {
                      var t = r.iframe.getDoc(e),
                        n = r.createElement(
                          "div",
                          '<?xml version="1.0" encoding="UTF-8" standalone="no"?><svg width="23px" height="26px" viewBox="0 0 23 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\x3c!-- Generator: Sketch 39.1 (31720) - http://www.bohemiancoding.com/sketch --\x3e<title>Group</title><desc>Created with Sketch.</desc><defs></defs><g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g id="WEBNOTIF-Normal" transform="translate(-31.000000, -712.000000)"><g id="Group-2" transform="translate(20.000000, 703.000000)"><g id="Group" transform="translate(11.000000, 9.000000)"><path d="M21.5983248,23.3571429 L1.4016752,23.3571429 C0.848501423,23.3571429 0.36137146,23.0463344 0.130218192,22.5462298 C-0.100707377,22.0461252 -0.0205438677,21.4757429 0.339280986,21.0577044 L2.37046946,18.6986433 C3.74623012,17.1010742 4.50391191,15.062343 4.50391191,12.9578683 L4.50391191,8.96428571 C4.50391191,5.12418038 7.64235884,2 11.5,2 C15.3576411,2 18.496088,5.12418038 18.496088,8.96428571 L18.496088,12.9578683 C18.496088,15.062343 19.2537698,17.1010742 20.6295305,18.6986433 L22.660719,21.0577044 C23.0205439,21.4757429 23.1007074,22.0461251 22.8697818,22.5462298 C22.6386284,23.0463344 22.1514985,23.3571429 21.5983248,23.3571429 L21.5983248,23.3571429 Z" id="Combined-Shape" fill="' +
                            (g.isColorTooLight(
                              d.optInNotificationContent.chickletBgColor
                            )
                              ? g.darkerColor(
                                  d.optInNotificationContent.chickletBgColor,
                                  0.1
                                )
                              : g.lighterColor(
                                  d.optInNotificationContent.chickletBgColor,
                                  0.1
                                )) +
                            '"></path><path d="M8.70156475,23.2142857 L1.4016752,23.2142857 C0.848501423,23.2142857 0.36137146,22.9034773 0.130218192,22.4033726 C-0.100707377,21.903268 -0.0205438677,21.3328857 0.339280986,20.9148472 L2.37046946,18.5557861 C3.74623012,16.9582171 4.50391191,14.9194859 4.50391191,12.8150112 L4.50391191,8.82142857 C4.50391191,5.62383597 6.6799915,2.92263847 9.63539251,2.10824493 L9.63437649,1.85714286 C9.63437649,0.833129886 10.4713109,0 11.5,0 C12.5286891,0 13.3656235,0.833129886 13.3656235,1.85714286 L13.3646074,2.10824493 C16.3200085,2.92263847 18.496088,5.62383597 18.496088,8.82142857 L18.496088,12.8150112 C18.496088,14.9194859 19.2537698,16.9582171 20.6295305,18.5557861 L22.660719,20.9148472 C23.0205439,21.3328857 23.1007074,21.903268 22.8697818,22.4033726 C22.6386284,22.9034773 22.1514985,23.2142857 21.5983248,23.2142857 L14.2984352,23.2142857 C14.2984352,24.7504185 13.0431475,26 11.5,26 C9.9568524,26 8.70156475,24.7504185 8.70156475,23.2142857 Z M10.1525735,2.93590829 C7.45551362,3.54741566 5.43672366,5.95406457 5.43672366,8.82142857 L5.43672366,12.8150112 C5.43672366,15.1409738 4.5993338,17.3943917 3.07873224,19.1601737 L1.04754377,21.5192348 C0.866948148,21.7287075 0.948478087,21.9520089 0.977856153,22.0154855 C1.00700657,22.0787353 1.12429123,22.2857143 1.4016752,22.2857143 L21.5983248,22.2857143 C21.8757087,22.2857143 21.9929934,22.0787353 22.0221438,22.0154855 C22.0515219,21.9520089 22.1330518,21.7287075 21.9524561,21.5192348 L19.9212677,19.1601737 C18.4006662,17.3943918 17.5632763,15.1409738 17.5632763,12.8150112 L17.5632763,8.82142857 C17.5632763,5.95397896 15.5443658,3.54727195 12.8471849,2.93585352 C12.8304821,2.93406813 12.8138079,2.93139282 12.7971913,2.92785647 C11.9299679,2.7392404 11.0700321,2.7392404 10.2028086,2.92785647 C10.1861432,2.93146651 10.1693735,2.93414529 10.1525735,2.93590829 Z M11.5,1.85714286 C11.8083562,1.85714286 12.1203562,1.87867954 12.432584,1.92107282 L12.4328117,1.85714286 C12.4328117,1.34502304 12.0144584,0.928571429 11.5,0.928571429 C10.9855416,0.928571429 10.5671882,1.34502304 10.5671882,1.85714286 L10.567416,1.92107282 C10.8796437,1.87867954 11.1916438,1.85714286 11.5,1.85714286 Z M9.63437649,23.2142857 C9.63437649,24.2382987 10.4713109,25.0714286 11.5,25.0714286 C12.5286891,25.0714286 13.3656235,24.2382987 13.3656235,23.2142857 L9.63437649,23.2142857 Z M6.83594127,9.28571429 C6.57837045,9.28571429 6.3695354,9.07782855 6.3695354,8.82142857 C6.3695354,6.00533621 8.67104796,3.71428571 11.5,3.71428571 C11.7575708,3.71428571 11.9664058,3.92217145 11.9664058,4.17857143 C11.9664058,4.4349714 11.7575708,4.64285714 11.5,4.64285714 C9.18550641,4.64285714 7.30234714,6.51745608 7.30234714,8.82142857 C7.30234714,9.07782855 7.09351209,9.28571429 6.83594127,9.28571429 Z" id="Combined-Shape" fill="' +
                            d.optInNotificationContent.chickletBorderColor +
                            '"></path></g></g></g></g></svg>'
                        );
                      r.addClass(n, "webpush-prompt"),
                        (n.style.cursor = "pointer"),
                        s.publish(
                          c.SYSTEM_CATEGORY_EVENT,
                          c.EVENTS_WP_PROMPT_VIEW
                        ),
                        s.bind(n, "click", function () {
                          s.publish(
                            c.SYSTEM_CATEGORY_EVENT,
                            c.EVENTS_WP_PROMPT_ALLOWED
                          ),
                            a("webengage/web-push/one-step").prompt(!0),
                            f();
                        }),
                        r.css.createStyleNode(p(), {}, t.head),
                        r.css.createStyleNode(
                          ".webpush-prompt {border            : 1px solid " +
                            d.optInNotificationContent.chickletBorderColor +
                            ";background-color  : " +
                            d.optInNotificationContent.chickletBgColor +
                            ";border-radius     : 50%;padding           : 10px 11.5px;display           : inline-block;position          : absolute;}",
                          {},
                          t.head
                        ),
                        t.body.appendChild(n),
                        l.incrementPromptViews();
                    },
                  });
                  if (r.css.getDocumentWidth() >= u) {
                    var o = K.createElement("div");
                    r.addClass(o, "webpush-onsite-bell-launcher"),
                      r.css.createStyleNode(
                        ".webpush-onsite-bell-launcher {opacity\t\t\t\t\t: 0;z-index\t\t\t\t\t: 16776271;transition\t\t\t\t: transform 175ms ease-in-out,opacity 175ms ease-in-out;width\t\t\t\t\t: fit-content;float\t\t\t\t\t: " +
                          (e =
                            d.optInNotificationContent.position.split("-"))[1] +
                          ";margin-" +
                          e[1] +
                          "\t: 60px !important;background-color  \t\t: rgba(61, 64, 78, 0.95);padding\t\t\t\t\t: 10px !important;border-radius\t\t\t: 5px;color\t\t\t\t\t: #ffffff;font-family\t\t\t\t: 'Open Sans', Arial, Helvetica, sans-serif !important;position\t\t\t\t: fixed;" +
                          e[0] +
                          "\t\t\t: 26.5px;" +
                          e[1] +
                          "\t\t\t: 20px;font-size\t\t\t\t: small !important;}\n#webpush-onsite:hover+.webpush-onsite-bell-launcher {opacity\t\t\t\t\t: 1}\n.we-bell-beak {display: inline-block;text-decoration: none;border-radius: 2px;}.we-bell-beak:after {content: '';display: block;position: absolute;width: 0;height: 0;border-bottom: 10px solid transparent;border-top: 10px solid transparent;top: calc(50% - 9px);" +
                          ("left" === e[1]
                            ? "border-right: 10px solid rgba(61, 64, 78, 0.95);border-left: 10px solid transparent;right: 100%;"
                            : "right" === e[1]
                            ? "border-left: 10px solid rgba(61, 64, 78, 0.95);border-right: 10px solid transparent;left: 100%;"
                            : void 0),
                        {},
                        o
                      ),
                      (o.innerHTML +=
                        '<div class="we-bell-beak"></div><div class="webpush-onsite-bell-message-body">' +
                        (d.optInNotificationContent.text ||
                          "Subscribe to our web push notifications") +
                        "</div>"),
                      i.insertAdjacentElement("afterend", o);
                  }
                }
              },
              showBox: function () {
                if (l.canShowOnsite("box") && !r.iframe.get("webpush-onsite")) {
                  var e = d.optInNotificationContent.position.split("-"),
                    t = {
                      height: "116px",
                      width: "350px",
                      visibility: "visible",
                      display: "block",
                      position: "fixed",
                    };
                  "middle" === e[1]
                    ? ((t.top = "0px"),
                      (t.left = "0px"),
                      (t.right = "0px"),
                      (t.margin = "auto"))
                    : ((t[e[0]] = "20px"), (t[e[1]] = "20px")),
                    r.css.getDocumentWidth() < u &&
                      (((t = {
                        width: "100%",
                        height: "116px",
                        position: "fixed",
                      })[e[0]] = "0px"),
                      (t[e[1]] = "0px")),
                    d.optInNotificationContent.enableOverlay &&
                      (((t = {
                        width: "100%",
                        height: "100%",
                        position: "fixed",
                      })[e[0]] = "0px"),
                      (t[e[1]] = "0px")),
                    (t["z-index"] = r.css.getMaxZIndex() + 1),
                    r.iframe.create({
                      name: "webpush-onsite",
                      css: t,
                      onload: function (e) {
                        var t = r.iframe.getDoc(e),
                          n = K.createElement("div");
                        (n.id = "webpush-prompt"),
                          t.body.appendChild(n),
                          (n.innerHTML =
                            "<div class='backdrop'></div><div class='wrapper'><div class=\"table content-table\"><div class='tablerow'>" +
                            (d.appIcon
                              ? "<div class='image-container tablecell'><div class='main-img' align='center'><img class=\"image-img img-circle\" src='" +
                                d.appIcon +
                                "'/></div></div>"
                              : "") +
                            "<div id='webpush-prompt' class='container tablecell'><div class='description-container'><div class='description'>" +
                            d.optInNotificationContent.text +
                            '</div></div></div></div></div>\n<div class="button-group-custom clearfix"><button id="deny" class="button close" >' +
                            d.optInNotificationContent.denyText +
                            '</button><button id="allow" class="button" >' +
                            d.optInNotificationContent.allowText +
                            "</button></div></div>"),
                          r.css.createStyleNode(p(), {}, t.head),
                          r.css.createStyleNode(
                            (function () {
                              var e =
                                  d.optInNotificationContent.position.split(
                                    "-"
                                  ),
                                t = "5px";
                              r.css.getDocumentWidth() < u && (t = "0px");
                              var n = g.isColorTooLight(
                                  d.optInNotificationContent.promptBgColor
                                )
                                  ? g.darkerColor(
                                      d.optInNotificationContent.promptBgColor,
                                      0.1
                                    )
                                  : g.lighterColor(
                                      d.optInNotificationContent.promptBgColor,
                                      0.1
                                    ),
                                i = d.optInNotificationContent.promptBgColor,
                                o = d.optInNotificationContent.promptTextColor;
                              return (
                                ".wrapper {background : " +
                                d.optInNotificationContent.promptBgColor +
                                ";border-radius: " +
                                t +
                                ";}\n" +
                                (d.optInNotificationContent.enableOverlay &&
                                r.css.getDocumentWidth() >= u
                                  ? ".backdrop {background : #000000;opacity : 0.5;width: 100%;height: 100%;position: fixed;}\n.wrapper {" +
                                    e[0] +
                                    " : 20px;" +
                                    e[1] +
                                    " : 20px;position : absolute;width : 350px;}"
                                  : d.optInNotificationContent.enableOverlay &&
                                    r.css.getDocumentWidth() < u
                                  ? ".backdrop {background : #000000;opacity : 0.5;width: 100%;height: 100%;position: fixed;}\n.wrapper {" +
                                    e[0] +
                                    " : 0;" +
                                    e[1] +
                                    " : 0;position : absolute;width : 100%;}"
                                  : "") +
                                "\n" +
                                ("middle" === e[1]
                                  ? ".wrapper {top: 0;left: 0;right: 0;margin: auto;border-radius: 0;}"
                                  : "") +
                                "\n.button,.button:hover,.button:active,.button:focus,.button:visited {background-color  : " +
                                n +
                                ";border-color      : " +
                                n +
                                ";color             : " +
                                o +
                                ";fonbt-size        : 16px;}\n.button-group-custom > .button:first-child {border-right-color: " +
                                i +
                                ";border-bottom-left-radius: " +
                                t +
                                ";}.button-group-custom > .button:first-child + .button {border-left-color: " +
                                i +
                                ";border-bottom-right-radius: " +
                                t +
                                ";}\n.description {color : " +
                                o +
                                ";font-size : 14px;}"
                              );
                            })(),
                            {},
                            t.head
                          ),
                          d.optInNotificationContent &&
                            !d.optInNotificationContent.enableOverlay &&
                            r.css.applyCss(e, {
                              height: Math.max(116, r.css.getHeight(n)) + "px",
                            }),
                          s.bind(r.queryOne("#allow", t), "click", function () {
                            s.publish(
                              c.SYSTEM_CATEGORY_EVENT,
                              c.EVENTS_WP_PROMPT_ALLOWED
                            ),
                              a("webengage/web-push/one-step").prompt(!0),
                              f();
                          }),
                          s.bind(r.queryOne("#deny", t), "click", function () {
                            s.publish(
                              c.SYSTEM_CATEGORY_EVENT,
                              c.EVENTS_WP_PROMPT_DENIED
                            );
                            var e = i.getForever();
                            (e.wp_dts = new Date().getTime()),
                              i.setForever(e),
                              f();
                          }),
                          d.optInNotificationContent.enableOverlay &&
                            d.optInNotificationContent.hideOnOverlayClick &&
                            s.bind(
                              r.queryOne(".backdrop", t),
                              "click",
                              function () {
                                f();
                              }
                            ),
                          l.incrementPromptViews();
                      },
                    }),
                    s.publish(c.SYSTEM_CATEGORY_EVENT, c.EVENTS_WP_PROMPT_VIEW);
                }
              },
              closeHint: function () {
                var e = r.iframe.get("webpush-hint");
                e && r.iframe.remove(e);
              },
              ready: function (e) {
                d = e;
              },
            };
          },
          {
            "../../../makeup/make-up-widget/sass/web-push/web-push-prompt.scss":
              "makeup/make-up-widget/sass/web-push/web-push-prompt.scss",
          },
        ],
        "webengage/web-push/one-step": [
          function (e, t, n) {
            "use strict";
            var i,
              c = e("webengage/util"),
              o = e("webengage/weq"),
              a = e("webengage/dom"),
              l = e("webengage/events"),
              g = e("webengage/state"),
              d = e("webengage/logger"),
              u = e("webengage/properties"),
              p = e("webengage/web-push/commons"),
              r = e("webengage/web-push/one-step-layouts"),
              s = e("webengage/ua"),
              f = null,
              b = "";
            function w() {
              var e = g.getForever();
              return e.wp_origin && e.wp_origin !== Z.location.origin
                ? (d.debug(
                    "Service worker is already registered on other domain, web push opt-in is disabled"
                  ),
                  !1)
                : "https:" !== location.protocol
                ? (d.debug("Page is not on HTTPS, web push opt-in is disabled"),
                  !1)
                : !(
                    !a.queryOne("head > link[rel=manifest]") &&
                    !f.vapidPublicKey
                  ) ||
                  (d.error(
                    "A link tag with rel=manifest was not found in <head>"
                  ),
                  !1);
            }
            function m(t) {
              !1 !== o.get("webengage.webpush.registerServiceWorker")
                ? navigator.serviceWorker
                    .register(
                      c.addParamsToURL(f.swPath || "/service-worker.js", {
                        _: "277",
                      })
                    )
                    .then(function () {
                      return (
                        d.debug("Service worker registered"),
                        navigator.serviceWorker.ready
                      );
                    })
                    .then(function (e) {
                      d.debug("Service worker ready"), t(e);
                    })
                    .catch(function (e) {
                      l.publish("error", e),
                        d.error("Failure in service worker registration", {
                          error: e,
                        });
                    })
                : navigator.serviceWorker
                    .getRegistration()
                    .then(function (e) {
                      if (!e)
                        return (
                          d.error(
                            "No service worker is registered in the root scope"
                          ),
                          void t(null)
                        );
                      d.debug("Retrieved service worker registration"), t(e);
                    })
                    .catch(function (e) {
                      l.publish("error", e),
                        d.error(
                          "Failure in retrieving service worker registration",
                          { error: e }
                        );
                    });
            }
            function h() {
              return "/apps/webengage/service-worker" !== f.swPath
                ? navigator.serviceWorker.ready
                : new Promise(function (n, i) {
                    navigator.serviceWorker
                      .getRegistration("/apps/webengage/")
                      .then(function (t) {
                        if (t) {
                          var e = t.installing || t.waiting || t.active;
                          if (e) {
                            if ("activated" === e.state) return void n(t);
                            e.addEventListener("statechange", function (e) {
                              "activated" === e.target.state && n(t);
                            });
                          }
                        } else
                          i(
                            new Error(
                              "No active service worker found in the given scope"
                            )
                          );
                      });
                  });
            }
            function v(e, t) {
              var r = p.getContext();
              r.eventName = e;
              var n = globalThis ? globalThis.localStorage : Z.localStorage;
              function s() {
                "/apps/webengage/service-worker" === f.swPath
                  ? h()
                      .then(function (e) {
                        e.active && e.active.postMessage(c.stringify(r));
                      })
                      .catch(function (e) {
                        l.publish("error", e),
                          d.error("Service worker not ready", { error: e });
                      })
                  : navigator.serviceWorker.controller
                  ? navigator.serviceWorker.controller.postMessage(
                      c.stringify(r)
                    )
                  : navigator.serviceWorker.addEventListener(
                      "controllerchange",
                      function (e) {
                        navigator.serviceWorker.controller.postMessage(
                          c.stringify(r)
                        );
                      }
                    );
              }
              if (
                (n.getItem(u.WP_AUTH_TOKEN_KEY) &&
                  (r[u.WP_AUTH_TOKEN_KEY] = n.getItem(u.WP_AUTH_TOKEN_KEY)),
                d.debug("Sending context to service worker", { payload: r }),
                e === u.EVENTS_WP_REGISTER)
              ) {
                r.icon = f.appIcon;
                var i = Z.location.origin + Z.location.pathname;
                i && (r.opt_in_url = i.substr(0, 1e3)),
                  t
                    ? ((r.hideSubscriptionMessage = f.hideSubscriptionMessage),
                      (r.p13n = p.getPersonalizationContext()))
                    : (r.hideSubscriptionMessage = !0),
                  h()
                    .then(function (e) {
                      var o, a;
                      (a = function (e, t) {
                        var n = g.getForever(),
                          i = c.sha1(e.endpoint),
                          o =
                            0 ===
                            e.endpoint.indexOf(
                              "https://android.googleapis.com/gcm/send"
                            );
                        n.interface_id
                          ? n.interface_id !== i &&
                            (l.publish(
                              u.SYSTEM_CATEGORY_EVENT,
                              u.EVENTS_WP_UNREGISTER
                            ),
                            l.publish(
                              u.SYSTEM_CATEGORY_EVENT,
                              u.EVENTS_USER_DELETE_DEVICE,
                              {},
                              { interface_id: n.interface_id }
                            ))
                          : l.publish(u.CHANNEL_WP_SUBSCRIBED),
                          (n.interface_id = i),
                          (n.wp_origin = Z.location.origin),
                          (n.wp_status = u.WP_PERMISSION_GRANTED),
                          (b = n.wp_origin),
                          g.setForever(n),
                          p.eventsCallbackHook("onPushRegistered"),
                          t && !o && (r.wp_vapid = !0),
                          s();
                      }),
                        (o = e).pushManager
                          .getSubscription()
                          .then(function (e) {
                            if (e) a(e);
                            else {
                              var t = setTimeout(function () {
                                  l.publish(
                                    "error",
                                    null,
                                    "",
                                    "Timeout on pushManager.subscribe()"
                                  ),
                                    d.error(
                                      "Timeout on pushManager.subscribe()"
                                    );
                                }, 15e3),
                                n = { userVisibleOnly: !0 },
                                i = !1;
                              f.vapidPublicKey &&
                                (n = {
                                  userVisibleOnly: (i = !0),
                                  applicationServerKey: c.urlBase64ToUint8Array(
                                    f.vapidPublicKey
                                  ),
                                }),
                                o.pushManager
                                  .subscribe(n)
                                  .then(function (e) {
                                    clearTimeout(t), a(e, i);
                                  })
                                  .catch(function (e) {
                                    clearTimeout(t),
                                      l.publish("error", e),
                                      d.error(
                                        "Error during pushManager.subscribe()",
                                        { error: e }
                                      );
                                  });
                            }
                          })
                          .catch(function (e) {
                            l.publish("error", e),
                              d.error(
                                "Error during pushManager.getSubscription()",
                                { error: e }
                              );
                          });
                    })
                    .catch(function (e) {
                      l.publish("error", e),
                        d.error("Service worker not ready", { error: e });
                    });
              } else s();
            }
            function y() {
              if (Notification.permission === u.WP_PERMISSION_DEFAULT) {
                var e = g.getForever();
                delete e.wp_origin,
                  g.setForever(e),
                  (b = ""),
                  m(function (e) {
                    p.eventsCallbackHook("onWindowViewed"),
                      v(u.EVENTS_WP_WINDOW_VIEW),
                      p.incrementPromptViews(),
                      "Desktop" === s.device &&
                        "Safari" !== s.browser &&
                        "native" === f.optInNotificationContent.layoutType &&
                        f.optInNotificationContent.nativeOverlay &&
                        r.showHint(),
                      Notification.requestPermission(function (e) {
                        var t = g.getForever();
                        "Desktop" === s.device &&
                          "Safari" !== s.browser &&
                          "native" === f.optInNotificationContent.layoutType &&
                          f.optInNotificationContent.nativeOverlay &&
                          r.closeHint(),
                          e === Notification.permission &&
                            (e === u.WP_PERMISSION_GRANTED &&
                            t.wp_status !== u.WP_PERMISSION_GRANTED
                              ? ((t.wp_status = u.WP_PERMISSION_GRANTED),
                                g.setForever(t),
                                p.eventsCallbackHook("onWindowAllowed"),
                                v(u.EVENTS_WP_WINDOW_ALLOWED),
                                h()
                                  .then(function () {
                                    v(u.EVENTS_WP_REGISTER, !0);
                                  })
                                  .catch(function (e) {
                                    l.publish("error", e),
                                      d.error(
                                        "serviceWorker.ready() threw exception",
                                        { error: e }
                                      );
                                  }))
                              : e === u.WP_PERMISSION_DENIED &&
                                ((t.wp_origin = Z.location.origin),
                                (t.wp_status = u.WP_PERMISSION_DENIED),
                                (b = t.wp_origin),
                                g.setForever(t),
                                p.eventsCallbackHook("onWindowDenied"),
                                v(u.EVENTS_WP_WINDOW_DENIED)));
                      });
                  });
              }
            }
            function x() {
              switch (f.optInNotificationContent.alternateLayout) {
                case "box":
                  r.showBox();
                  break;
                case "bell":
                  r.showBell();
                  break;
                case "custom":
                  break;
                default:
                  r.showBox();
              }
            }
            t.exports = {
              ready: function (e) {
                d.debug("Service worker is supported"),
                  (f = e),
                  r.ready(e),
                  (b = g.getForever().wp_origin),
                  (i = !1);
              },
              contextChange: function (e) {
                var t = g.getForever();
                b && !t.wp_origin && (t.wp_origin = b),
                  e === u.EVENTS_NEW_SESSION &&
                    -1 === f.reOptInDuration &&
                    delete t.wp_dts,
                  delete t.wp_status,
                  g.setForever(t),
                  t.wp_origin &&
                    t.wp_origin === Z.location.origin &&
                    (this.showOptin(!0), (i = !0));
              },
              showOptin: function (e) {
                var t = g.getForever();
                if (w() && p.canPrompt() && (e || !i))
                  switch (
                    (Notification.permission !== u.WP_PERMISSION_GRANTED ||
                      (t.wp_status && t.interface_id) ||
                      m(function () {
                        v(u.EVENTS_WP_REGISTER);
                      }),
                    t.wp_status !== u.WP_PERMISSION_GRANTED ||
                      (Notification.permission !== u.WP_PERMISSION_DENIED &&
                        Notification.permission !== u.WP_PERMISSION_DEFAULT) ||
                      (l.publish(u.SYSTEM_CATEGORY_EVENT, u.EVENTS_WP_OPT_OUT, {
                        source: "web-sdk",
                      }),
                      p.eventsCallbackHook("onPushUnregistered"),
                      l.publish(
                        u.SYSTEM_CATEGORY_EVENT,
                        u.EVENTS_WP_UNREGISTER
                      ),
                      l.publish(
                        u.SYSTEM_CATEGORY_EVENT,
                        u.EVENTS_USER_DELETE_DEVICE,
                        null,
                        { interface_id: t.interface_id }
                      ),
                      delete t.interface_id,
                      (t.wp_status = Notification.permission),
                      g.setForever(t)),
                    f.optInNotificationContent.layoutType)
                  ) {
                    case "native":
                      p.canShowNative() ? y() : x();
                      break;
                    case "box":
                      r.showBox();
                      break;
                    case "bell":
                      r.showBell();
                      break;
                    case "custom":
                      break;
                    default:
                      p.canShowNative() ? y() : x();
                  }
              },
              prompt: function (e) {
                (e || w()) && y();
              },
            };
          },
          {},
        ],
        "webengage/web-push/reverse-two-step": [
          function (r, e, t) {
            "use strict";
            var s = r("webengage/util"),
              c = r("webengage/events"),
              a = r("webengage/state"),
              l = r("webengage/dom"),
              g = r("webengage/colors"),
              d = r("webengage/logger"),
              o = r("webengage/callback-frame"),
              u = r("webengage/properties"),
              p = r("webengage/web-push/commons"),
              f = "_webPushFrame",
              b = null,
              w = "";
            function m() {
              if (!l.iframe.get("webpush-modal")) {
                var e = {
                  height: "100%",
                  width: "100%",
                  visibility: "visible",
                  display: "block",
                  position: "fixed",
                  top: "0px",
                  left: "0px",
                };
                (e["z-index"] = l.css.getMaxZIndex()),
                  l.iframe.create({
                    name: "webpush-modal",
                    css: e,
                    onload: function (e) {
                      var t,
                        n,
                        i = l.iframe.getDoc(e),
                        o = l.createElement(
                          "div",
                          '<div class="backdrop"></div><div class="wrapper-outer"><div class=\'wrapper\'><div class="table content-table"><div class=\'tablerow\'>' +
                            (b.appIcon
                              ? "<div class='image-container tablecell'><div class='main-img' align='center'><img class=\"image-img img-circle\" src='" +
                                b.appIcon +
                                "'/></div></div>"
                              : "") +
                            "<div class='container tablecell'><div class='description-container'><div class='description'><strong>Thank you for subscribing</strong>\nPlease click anywhere to close this message</div></div></div></div></div><div><button class=\"button\">Close</button></div><div class=\"cross\"><span>âœ•</span></div></div></div>"
                        );
                      l.addClass(o, "webpush-modal"),
                        c.bind(i, "click", function () {
                          !(function () {
                            h();
                            var e = p.getContext();
                            (e.image = b.childWindowContent.imageURL),
                              (e.bg = b.childWindowContent.bgColor),
                              (e.textColor = b.childWindowContent.textColor),
                              (e.text = b.childWindowContent.text),
                              (e.icon = b.appIcon),
                              (e.hideSubscriptionMessage =
                                b.hideSubscriptionMessage),
                              (e.p13n = p.getPersonalizationContext()),
                              Z.open(
                                w +
                                  "/subscribe?v=277#environment=" +
                                  encodeURIComponent(
                                    p.base64Encode(s.stringify(e))
                                  ),
                                "_blank",
                                "centerscreen,height=500,width=500"
                              );
                          })();
                        }),
                        l.css.createStyleNode(
                          r(
                            "../../../makeup/make-up-widget/sass/web-push/web-push-prompt.scss"
                          ),
                          {},
                          i.head
                        ),
                        l.css.createStyleNode(
                          ((t = g.isColorTooLight(
                            b.optInNotificationContent.promptBgColor
                          )
                            ? g.darkerColor(
                                b.optInNotificationContent.promptBgColor,
                                0.1
                              )
                            : g.lighterColor(
                                b.optInNotificationContent.promptBgColor,
                                0.1
                              )),
                          b.optInNotificationContent.promptBgColor,
                          (n = b.optInNotificationContent.promptTextColor),
                          ".webpush-modal {cursor: pointer;width: 100%;height: 100%;}\n.wrapper-outer {margin: 0 auto;width: 100%;height: 100%;top: 0;left: 0;position: absolute;}\n.backdrop {height: 100%;width: 100%;opacity: 0.6;background-color: #000;position: fixed;top: 0;left: 0;}\n.wrapper {background : " +
                            b.optInNotificationContent.promptBgColor +
                            ";border-radius: 3px;margin-top: 150px;width: 400px;margin: 0 auto;position: relative;}\n.main-img img {max-height: none;max-width: 100px;}\n.button, .button:hover {width: 100% !important;border-radius: 0 0 3px 3px;background-color  : " +
                            t +
                            ";border-color      : " +
                            t +
                            ";color             : " +
                            n +
                            ";}\n.description-container {padding: 0 10px 0 12px;}\n.description {font-size: 16px;color : " +
                            n +
                            ";}\n.description strong {font-weight: 700;display: block;margin-bottom: 12px;}\n.cross {position: absolute;top: 8px;right: 8px;color: " +
                            n +
                            ";}"),
                          {},
                          i.head
                        ),
                        i.body.appendChild(o);
                      var a =
                        Math.max(
                          l.css.getWindowHeight() / 2 -
                            l.css.getElementHeight(l.queryOne(".wrapper", i)) /
                              2,
                          10
                        ) + "px";
                      l.css.applyCss(l.queryOne(".wrapper", i), {
                        "margin-top": a,
                      }),
                        425 < l.css.getDocumentWidth() &&
                          l.css.applyCss(l.queryOne(".wrapper", i), {
                            transform: "scale(1.2)",
                          });
                    },
                  });
              }
            }
            function h(e) {
              var t = p.getContext();
              t.requestPermission = e || !1;
              var n = globalThis ? globalThis.localStorage : Z.localStorage;
              n.getItem(u.WP_AUTH_TOKEN_KEY) &&
                (t[u.WP_AUTH_TOKEN_KEY] = n.getItem(u.WP_AUTH_TOKEN_KEY)),
                d.debug("Sending context to embed frame", { payload: t });
              var i = l.iframe.get(f);
              i
                ? i.ready
                  ? i.contentWindow.postMessage(s.stringify(t), "*")
                  : setTimeout(function () {
                      h(e);
                    }, 500)
                : l.iframe.create({
                    name: f,
                    src: w + "/embed?v=277#name=" + o.getName(),
                    onload: function (e) {
                      (e.ready = !0),
                        e.contentWindow.postMessage(s.stringify(t), "*");
                    },
                  });
            }
            e.exports = {
              ready: function (e) {
                var t = a.getForever();
                (w = "https://" + (b = e).subDomain + ".webengagepush.com"),
                  o.onMessage(w, "web-push", function (e) {
                    var t,
                      n = a.getForever(),
                      i = s.parseJSON(e);
                    if (
                      (d.debug("Message received from push origin frame", {
                        payload: i,
                      }),
                      i.event &&
                        (c.publish(u.SYSTEM_CATEGORY_EVENT, i.event),
                        i.event === u.EVENTS_WP_WINDOW_VIEW &&
                          p.incrementPromptViews()),
                      i.permission === u.WP_PERMISSION_DENIED ||
                        i.permission === u.WP_PERMISSION_DEFAULT)
                    )
                      (n.wp_status === u.WP_PERMISSION_GRANTED ||
                        n.interface_id) &&
                        (c.publish(
                          u.SYSTEM_CATEGORY_EVENT,
                          u.EVENTS_WP_UNREGISTER
                        ),
                        c.publish(
                          u.SYSTEM_CATEGORY_EVENT,
                          u.EVENTS_USER_UPDATE,
                          {},
                          { opt_in_push: !1 }
                        ),
                        delete n.interface_id,
                        delete n.wp_dts);
                    else if (i.permission === u.WP_PERMISSION_GRANTED)
                      if (i.interfaceId && i.subscription)
                        (n.interface_id = i.interfaceId),
                          c.publish(
                            u.SYSTEM_CATEGORY_EVENT,
                            u.EVENTS_WP_REGISTER,
                            { subscription: i.subscription }
                          ),
                          c.publish(
                            u.SYSTEM_CATEGORY_EVENT,
                            u.EVENTS_USER_UPDATE,
                            {},
                            { opt_in_push: !0 }
                          );
                      else if (i.endpoint)
                        (n.interface_id = s.sha1(i.endpoint)),
                          (t = l.iframe.get("webpush-modal")) &&
                            l.iframe.remove(t),
                          c.publish(u.CHANNEL_WP_SUBSCRIBED);
                      else {
                        delete n.interface_id;
                        var o = a.getSession();
                        p.ifRules.result &&
                          !o.wp_rsm &&
                          ((o.wp_rsm = new Date().getTime()),
                          a.setSession(o),
                          m());
                      }
                    (n.wp_status = i.permission), a.setForever(n);
                  }),
                  t.wp_status || h();
              },
              contextChange: function (e) {
                var t = a.getForever();
                e === u.EVENTS_NEW_SESSION && delete t.wp_status,
                  a.setForever(t),
                  h();
              },
              showOptin: function () {
                var e = a.getForever();
                (e.wp_status &&
                  e.wp_status !== u.WP_PERMISSION_DEFAULT &&
                  (e.wp_status !== u.WP_PERMISSION_GRANTED ||
                    e.interface_id)) ||
                  h(p.canPrompt());
              },
              prompt: function () {
                var e = a.getForever();
                (e.wp_status === u.WP_PERMISSION_GRANTED && e.interface_id) ||
                  h(!0);
              },
            };
          },
          {
            "../../../makeup/make-up-widget/sass/web-push/web-push-prompt.scss":
              "makeup/make-up-widget/sass/web-push/web-push-prompt.scss",
          },
        ],
        "webengage/web-push/two-step": [
          function (o, e, t) {
            "use strict";
            var a = o("webengage/util"),
              s = o("webengage/events"),
              c = o("webengage/state"),
              l = o("webengage/dom"),
              g = o("webengage/colors"),
              r = o("webengage/logger"),
              i = o("webengage/callback-frame"),
              d = o("webengage/properties"),
              u = o("webengage/web-push/commons"),
              n = o("webengage/ua"),
              p = 0,
              f = -1,
              b = "_webPushFrame",
              w = 425,
              m = null,
              h = "";
            function v(i) {
              if (
                (function () {
                  var e = c.getForever();
                  if (e.wp_dts && "number" === a.type(m.reOptInDuration)) {
                    if (
                      m.reOptInDuration === f ||
                      e.wp_dts + m.reOptInDuration > new Date().getTime()
                    )
                      return !1;
                    delete e.wp_dts, c.setForever(e);
                  }
                  return !0;
                })() &&
                !l.iframe.get("webpush-bubble")
              ) {
                var e = m.optInNotificationContent.position.split("-"),
                  t = {
                    height: "48px",
                    width: "48px",
                    visibility: "visible",
                    display: "block",
                    position: "fixed",
                  };
                (t["z-index"] = l.css.getMaxZIndex()),
                  (t[e[0]] = "20px"),
                  (t[e[1]] = "20px");
                l.iframe.create({
                  name: "webpush-bubble",
                  css: t,
                  onload: function (e) {
                    var t = l.iframe.getDoc(e),
                      n = l.createElement(
                        "div",
                        '<?xml version="1.0" encoding="UTF-8" standalone="no"?><svg width="23px" height="26px" viewBox="0 0 23 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\x3c!-- Generator: Sketch 39.1 (31720) - http://www.bohemiancoding.com/sketch --\x3e<title>Group</title><desc>Created with Sketch.</desc><defs></defs><g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g id="WEBNOTIF-Normal" transform="translate(-31.000000, -712.000000)"><g id="Group-2" transform="translate(20.000000, 703.000000)"><g id="Group" transform="translate(11.000000, 9.000000)"><path d="M21.5983248,23.3571429 L1.4016752,23.3571429 C0.848501423,23.3571429 0.36137146,23.0463344 0.130218192,22.5462298 C-0.100707377,22.0461252 -0.0205438677,21.4757429 0.339280986,21.0577044 L2.37046946,18.6986433 C3.74623012,17.1010742 4.50391191,15.062343 4.50391191,12.9578683 L4.50391191,8.96428571 C4.50391191,5.12418038 7.64235884,2 11.5,2 C15.3576411,2 18.496088,5.12418038 18.496088,8.96428571 L18.496088,12.9578683 C18.496088,15.062343 19.2537698,17.1010742 20.6295305,18.6986433 L22.660719,21.0577044 C23.0205439,21.4757429 23.1007074,22.0461251 22.8697818,22.5462298 C22.6386284,23.0463344 22.1514985,23.3571429 21.5983248,23.3571429 L21.5983248,23.3571429 Z" id="Combined-Shape" fill="' +
                          (g.isColorTooLight(
                            m.optInNotificationContent.chickletBgColor
                          )
                            ? g.darkerColor(
                                m.optInNotificationContent.chickletBgColor,
                                0.1
                              )
                            : g.lighterColor(
                                m.optInNotificationContent.chickletBgColor,
                                0.1
                              )) +
                          '"></path><path d="M8.70156475,23.2142857 L1.4016752,23.2142857 C0.848501423,23.2142857 0.36137146,22.9034773 0.130218192,22.4033726 C-0.100707377,21.903268 -0.0205438677,21.3328857 0.339280986,20.9148472 L2.37046946,18.5557861 C3.74623012,16.9582171 4.50391191,14.9194859 4.50391191,12.8150112 L4.50391191,8.82142857 C4.50391191,5.62383597 6.6799915,2.92263847 9.63539251,2.10824493 L9.63437649,1.85714286 C9.63437649,0.833129886 10.4713109,0 11.5,0 C12.5286891,0 13.3656235,0.833129886 13.3656235,1.85714286 L13.3646074,2.10824493 C16.3200085,2.92263847 18.496088,5.62383597 18.496088,8.82142857 L18.496088,12.8150112 C18.496088,14.9194859 19.2537698,16.9582171 20.6295305,18.5557861 L22.660719,20.9148472 C23.0205439,21.3328857 23.1007074,21.903268 22.8697818,22.4033726 C22.6386284,22.9034773 22.1514985,23.2142857 21.5983248,23.2142857 L14.2984352,23.2142857 C14.2984352,24.7504185 13.0431475,26 11.5,26 C9.9568524,26 8.70156475,24.7504185 8.70156475,23.2142857 Z M10.1525735,2.93590829 C7.45551362,3.54741566 5.43672366,5.95406457 5.43672366,8.82142857 L5.43672366,12.8150112 C5.43672366,15.1409738 4.5993338,17.3943917 3.07873224,19.1601737 L1.04754377,21.5192348 C0.866948148,21.7287075 0.948478087,21.9520089 0.977856153,22.0154855 C1.00700657,22.0787353 1.12429123,22.2857143 1.4016752,22.2857143 L21.5983248,22.2857143 C21.8757087,22.2857143 21.9929934,22.0787353 22.0221438,22.0154855 C22.0515219,21.9520089 22.1330518,21.7287075 21.9524561,21.5192348 L19.9212677,19.1601737 C18.4006662,17.3943918 17.5632763,15.1409738 17.5632763,12.8150112 L17.5632763,8.82142857 C17.5632763,5.95397896 15.5443658,3.54727195 12.8471849,2.93585352 C12.8304821,2.93406813 12.8138079,2.93139282 12.7971913,2.92785647 C11.9299679,2.7392404 11.0700321,2.7392404 10.2028086,2.92785647 C10.1861432,2.93146651 10.1693735,2.93414529 10.1525735,2.93590829 Z M11.5,1.85714286 C11.8083562,1.85714286 12.1203562,1.87867954 12.432584,1.92107282 L12.4328117,1.85714286 C12.4328117,1.34502304 12.0144584,0.928571429 11.5,0.928571429 C10.9855416,0.928571429 10.5671882,1.34502304 10.5671882,1.85714286 L10.567416,1.92107282 C10.8796437,1.87867954 11.1916438,1.85714286 11.5,1.85714286 Z M9.63437649,23.2142857 C9.63437649,24.2382987 10.4713109,25.0714286 11.5,25.0714286 C12.5286891,25.0714286 13.3656235,24.2382987 13.3656235,23.2142857 L9.63437649,23.2142857 Z M6.83594127,9.28571429 C6.57837045,9.28571429 6.3695354,9.07782855 6.3695354,8.82142857 C6.3695354,6.00533621 8.67104796,3.71428571 11.5,3.71428571 C11.7575708,3.71428571 11.9664058,3.92217145 11.9664058,4.17857143 C11.9664058,4.4349714 11.7575708,4.64285714 11.5,4.64285714 C9.18550641,4.64285714 7.30234714,6.51745608 7.30234714,8.82142857 C7.30234714,9.07782855 7.09351209,9.28571429 6.83594127,9.28571429 Z" id="Combined-Shape" fill="' +
                          m.optInNotificationContent.chickletBorderColor +
                          '"></path></g></g></g></g></svg>'
                      );
                    l.addClass(n, "webpush-bubble"),
                      s.bind(n, "click", E),
                      l.css.createStyleNode(
                        o(
                          "../../../makeup/make-up-widget/sass/web-push/web-push-prompt.scss"
                        ),
                        {},
                        t.head
                      ),
                      l.css.createStyleNode(
                        (function () {
                          var e =
                              m.optInNotificationContent.position.split("-"),
                            t = "320px",
                            n = "60px",
                            i = "5px";
                          l.css.getDocumentWidth() < w &&
                            ((t = "100%"), (i = n = "0px"));
                          var o = g.isColorTooLight(
                              m.optInNotificationContent.promptBgColor
                            )
                              ? g.darkerColor(
                                  m.optInNotificationContent.promptBgColor,
                                  0.1
                                )
                              : g.lighterColor(
                                  m.optInNotificationContent.promptBgColor,
                                  0.1
                                ),
                            a = m.optInNotificationContent.promptBgColor,
                            r = m.optInNotificationContent.promptTextColor,
                            s = {
                              "bottom-left":
                                "border-left: 20px solid transparent; border-top: 20px solid transparent; border-right: 20px solid " +
                                o +
                                "; bottom : 0px; left: -35px",
                              "bottom-right":
                                "border-right: 20px solid transparent; border-top: 20px solid transparent; border-left: 20px solid " +
                                o +
                                "; bottom : 0px; right: -35px",
                              "top-left":
                                "border-left: 20px solid transparent; border-bottom: 20px solid transparent; border-right: 20px solid " +
                                m.optInNotificationContent.promptBgColor +
                                "; top : 0px; left: -35px",
                              "top-right":
                                "border-right: 20px solid transparent; border-bottom: 20px solid transparent; border-left: 20px solid " +
                                m.optInNotificationContent.promptBgColor +
                                "; top : 0px; right: -35px",
                            };
                          return (
                            ".webpush-bubble {background-color  : transparent;border-radius     : 50%;padding           : 10px 11.5px;display           : inline-block;border            : 1px solid " +
                            m.optInNotificationContent.chickletBorderColor +
                            ";position          : absolute;" +
                            e[0] +
                            "    : 0px;" +
                            e[1] +
                            "    : 0px;}\n.webpush-bubble-active {background-color  : " +
                            m.optInNotificationContent.chickletBgColor +
                            ";}\n.wrapper {background : " +
                            m.optInNotificationContent.promptBgColor +
                            ";border-radius: " +
                            i +
                            ";}\n.webpush-prompt {position        : absolute;width           : " +
                            t +
                            ";" +
                            e[0] +
                            "  : 0px;" +
                            e[1] +
                            "  : " +
                            n +
                            ";}\n.we-beak {" +
                            s[m.optInNotificationContent.position] +
                            "}\n.button,.button:hover,.button:active,.button:focus,.button:visited {background-color  : " +
                            o +
                            ";border-color      : " +
                            o +
                            ";color             : " +
                            r +
                            ";}\n.button-group-custom > .button:first-child {border-right-color: " +
                            a +
                            ";border-bottom-left-radius: " +
                            i +
                            ";}.button-group-custom > .button:first-child + .button {border-left-color: " +
                            a +
                            ";border-bottom-right-radius: " +
                            i +
                            ";}\n.description {color : " +
                            r +
                            ";}"
                          );
                        })(),
                        {},
                        t.head
                      ),
                      t.body.appendChild(n),
                      i && u.canPrompt() && (x(e), u.incrementPromptViews());
                  },
                });
              }
            }
            function y() {
              var e = l.iframe.get("webpush-bubble");
              e && l.iframe.remove(e);
            }
            function x(e) {
              var t = m.optInNotificationContent.position.split("-"),
                n = { width: "380px", height: "116px" };
              l.css.getDocumentWidth() < w &&
                (((n = { width: "100%", height: "116px" })[t[0]] = "0px"),
                (n[t[1]] = "0px")),
                l.css.applyCss(e, n);
              var i = l.iframe.getDoc(e);
              l.addClass(
                l.queryOne(".webpush-bubble", i),
                "webpush-bubble-active"
              );
              var o,
                a,
                r = l.createElement(
                  "div",
                  ((o = m.appIcon
                    ? "<div class='image-container tablecell'><div class='main-img' align='center'><img class=\"image-img img-circle\" src='" +
                      m.appIcon +
                      "'/></div></div>"
                    : ""),
                  (a =
                    l.css.getDocumentWidth() < w
                      ? ""
                      : '<div class="we-beak"></div>'),
                  "<div class='wrapper'><div class=\"table content-table\"><div class='tablerow'>" +
                    o +
                    "<div id='webpush-prompt' class='container tablecell'><div class='description-container'><div class='description'>" +
                    m.optInNotificationContent.text +
                    '</div></div></div></div></div>\n<div class="button-group-custom clearfix"><button id="deny" class="button close" >' +
                    m.optInNotificationContent.denyText +
                    '</button><button id="allow" class="button" >' +
                    m.optInNotificationContent.allowText +
                    "</button></div>" +
                    a +
                    "</div>")
                );
              l.addClass(r, "webpush-prompt"),
                i.body.appendChild(r),
                l.css.applyCss(e, {
                  height: Math.max(116, l.css.getHeight(r)) + "px",
                }),
                s.publish(d.SYSTEM_CATEGORY_EVENT, d.EVENTS_WP_PROMPT_VIEW),
                s.bind(l.queryOne("#allow", i), "click", function () {
                  u.eventsCallbackHook("onWindowViewed"),
                    s.publish(
                      d.SYSTEM_CATEGORY_EVENT,
                      d.EVENTS_WP_PROMPT_ALLOWED
                    ),
                    _(),
                    E();
                }),
                s.bind(l.queryOne("#deny", i), "click", function () {
                  s.publish(d.SYSTEM_CATEGORY_EVENT, d.EVENTS_WP_PROMPT_DENIED);
                  var e = c.getForever();
                  (e.wp_status = d.WP_PERMISSION_DENIED),
                    (e.wp_dts = new Date().getTime()),
                    c.setForever(e),
                    E(),
                    m.reOptInDuration !== p && y();
                });
            }
            function E() {
              var e = l.iframe.get("webpush-bubble"),
                t = l.queryOne(".webpush-bubble-active", l.iframe.getDoc(e));
              if (t) {
                var n = m.optInNotificationContent.position.split("-"),
                  i = l.queryOne(".webpush-prompt", l.iframe.getDoc(e));
                l.remove(i), l.removeClass(t, "webpush-bubble-active");
                var o = { width: "48px", height: "48px" };
                (o[n[0]] = "20px"), (o[n[1]] = "20px"), l.css.applyCss(e, o);
              } else x(e);
            }
            function _() {
              S();
              var e = u.getContext();
              (e.image = m.childWindowContent.imageURL),
                (e.bg = m.childWindowContent.bgColor),
                (e.textColor = m.childWindowContent.textColor),
                (e.text = m.childWindowContent.text),
                (e.icon = m.appIcon),
                (e.hideSubscriptionMessage = m.hideSubscriptionMessage),
                (e.p13n = u.getPersonalizationContext()),
                (e.browser_name = n.browser),
                (e.browser_version = n.version),
                Z.open(
                  h +
                    "/subscribe?v=277#environment=" +
                    encodeURIComponent(u.base64Encode(a.stringify(e))),
                  "_blank",
                  "centerscreen,height=500,width=500"
                );
            }
            function S() {
              var t = u.getContext(),
                e = globalThis ? globalThis.localStorage : Z.localStorage;
              e.getItem(d.WP_AUTH_TOKEN_KEY) &&
                (t[d.WP_AUTH_TOKEN_KEY] = e.getItem(d.WP_AUTH_TOKEN_KEY)),
                r.debug("Sending context to embed frame", { payload: t });
              var n = l.iframe.get(b);
              n
                ? n.contentWindow.postMessage(a.stringify(t), "*")
                : l.iframe.create({
                    name: b,
                    src: h + "/embed?v=277#name=" + i.getName(),
                    onload: function (e) {
                      e.contentWindow.postMessage(a.stringify(t), "*");
                    },
                  });
            }
            e.exports = {
              ready: function (e) {
                var t = c.getForever();
                h = "https://" + (m = e).subDomain + ".webengagepush.com";
                var o = Z.location.origin + Z.location.pathname;
                o && (o = o.substr(0, 1e3)),
                  i.onMessage(h, "web-push", function (e) {
                    var t = c.getForever(),
                      n = a.parseJSON(e);
                    if (
                      (r.debug("Message received from push origin frame", {
                        payload: n,
                      }),
                      n.permission === d.WP_PERMISSION_DENIED ||
                        n.permission === d.WP_PERMISSION_DEFAULT)
                    )
                      (t.wp_status === d.WP_PERMISSION_GRANTED ||
                        t.interface_id) &&
                        (s.publish(
                          d.SYSTEM_CATEGORY_EVENT,
                          d.EVENTS_WP_OPT_OUT,
                          { source: "web-sdk" }
                        ),
                        u.eventsCallbackHook("onPushUnregistered"),
                        s.publish(
                          d.SYSTEM_CATEGORY_EVENT,
                          d.EVENTS_WP_UNREGISTER
                        ),
                        s.publish(
                          d.SYSTEM_CATEGORY_EVENT,
                          d.EVENTS_USER_DELETE_DEVICE,
                          {},
                          { interface_id: t.interface_id }
                        ),
                        delete t.interface_id),
                        u.ifRules.result &&
                          v(n.permission === d.WP_PERMISSION_DEFAULT);
                    else if (n.permission === d.WP_PERMISSION_GRANTED) {
                      y();
                      var i =
                        n.interfaceId ||
                        (n.endpoint && a.sha1(n.endpoint)) ||
                        null;
                      i
                        ? (t.interface_id
                            ? t.interface_id !== i &&
                              (s.publish(
                                d.SYSTEM_CATEGORY_EVENT,
                                d.EVENTS_WP_UNREGISTER
                              ),
                              s.publish(
                                d.SYSTEM_CATEGORY_EVENT,
                                d.EVENTS_USER_DELETE_DEVICE,
                                {},
                                { interface_id: t.interface_id }
                              ))
                            : s.publish(d.CHANNEL_WP_SUBSCRIBED),
                          (t.interface_id = i),
                          n.subscription &&
                            (u.eventsCallbackHook("onWindowAllowed"),
                            u.eventsCallbackHook("onPushRegistered"),
                            s.publish(
                              d.SYSTEM_CATEGORY_EVENT,
                              d.EVENTS_WP_REGISTER,
                              { subscription: n.subscription }
                            ),
                            s.publish(
                              d.SYSTEM_CATEGORY_EVENT,
                              d.EVENTS_USER_UPDATE,
                              {},
                              { opt_in_push: !0, opt_in_url: o }
                            )))
                        : (delete t.interface_id,
                          u.eventsCallbackHook("onWindowDenied"),
                          u.ifRules.result && v(!0));
                    }
                    (t.wp_status = n.permission), c.setForever(t);
                  }),
                  t.wp_status || S();
              },
              contextChange: function (e) {
                var t = c.getForever();
                e === d.EVENTS_NEW_SESSION &&
                  (delete t.wp_status,
                  m.reOptInDuration === f && delete t.wp_dts),
                  c.setForever(t),
                  S();
              },
              showOptin: function () {
                var e = c.getForever();
                e.wp_status === d.WP_PERMISSION_DEFAULT ||
                (e.wp_status === d.WP_PERMISSION_GRANTED && !e.interface_id)
                  ? S()
                  : e.wp_status === d.WP_PERMISSION_DENIED && v();
              },
              prompt: function () {
                var e = c.getForever();
                (e.wp_status === d.WP_PERMISSION_GRANTED && e.interface_id) ||
                  _();
              },
            };
          },
          {
            "../../../makeup/make-up-widget/sass/web-push/web-push-prompt.scss":
              "makeup/make-up-widget/sass/web-push/web-push-prompt.scss",
          },
        ],
        "webengage/webengage": [
          function (t, e, n) {
            "use strict";
            var i,
              o = t("webengage/properties"),
              d = t("webengage/util"),
              r = t("webengage/events"),
              a = t("webengage/async"),
              s = t("webengage/dom"),
              c = t("webengage/state"),
              l = t("webengage/storage"),
              g = t("webengage/ua"),
              u = t("webengage/tracker"),
              p = t("webengage/load"),
              f = t("webengage/weq"),
              b = t("webengage/rules"),
              w = t("webengage/backpatch"),
              m = t("webengage/targeting-events"),
              h = t("webengage/web-push"),
              v = t("webengage/logger"),
              y = t("webengage/callback-frame"),
              x = t("webengage/preview-selector");
            x.start, x.stop;
            (d.copy(X, { log: v, util: d, dom: s, state: c, webpush: h }),
            (function () {
              var t = "_we_debug_state_";
              function n() {
                if ("undefined" != typeof localStorage) {
                  var e = localStorage && localStorage.getItem(t);
                  e && "true" === e ? v.init("DEBUG") : v.init("WARN");
                }
              }
              function e(e) {
                "undefined" != typeof localStorage &&
                  (e
                    ? localStorage && localStorage.setItem(t, !0)
                    : localStorage && localStorage.removeItem(t),
                  n());
              }
              (e.init = n), (X.debug = e);
            })(),
            X.debug.init(),
            1 === X.is_spa) &&
              Z.history &&
              Z.history.pushState &&
              (!(function (n) {
                var t = n.pushState;
                n.pushState = function (e) {
                  return (
                    "function" == typeof n.onpushstate &&
                      n.onpushstate({ state: e }),
                    t.apply(n, arguments)
                  );
                };
                var i = n.replaceState;
                n.replaceState = function (e, t) {
                  return (
                    "function" == typeof n.onreplacestate &&
                      n.onreplacestate(e, t),
                    i.apply(n, arguments)
                  );
                };
              })(Z.history),
              (Z.onpopstate =
                history.onpushstate =
                history.onreplacestate =
                  function (e) {
                    r.happened("ready") &&
                      (v.debug({ msg: "URL CHANGED" }),
                      "aa131c7a" === X.getLicenseCode()
                        ? (i != $ && clearTimeout(i),
                          (i = setTimeout(function () {
                            X.reload(), (i = $);
                          }, 1e3)))
                        : setTimeout(function () {
                            X.reload();
                          }, 500));
                  }));
            var E = {
              init: function (t) {
                return (
                  v.debug({ msg: "WIDGET INIT", ctx: { options: t } }),
                  f.get("webengage.licenseCode") ||
                    (!X.__v || ("5.0" !== X.__v && "6.0" !== X.__v)
                      ? ((t = t || {}),
                        d.mapArray(
                          ["licenseCode", "language", "isDemoMode", "delay"],
                          function (e) {
                            t.hasOwnProperty(e) && X.options(e, t[e]);
                          }
                        ),
                        X.options("widgetVersion", "3.0"))
                      : (X.options("licenseCode", t),
                        X.options("widgetVersion", X.__v)),
                    V()),
                  X
                );
              },
              options: function (e, t) {
                f.set(e, t, "webengage");
              },
              onReady: function (e) {
                "function" === d.type(e) &&
                  (r.happened("ready")
                    ? e()
                    : r.subscribe("ready", d.guard(e, !0)));
              },
              onSessionStarted: function (t) {
                "function" === d.type(t) &&
                  r.subscribe("event.system", function (e) {
                    "visitor_new_session" === e && t();
                  });
              },
              screen: function (e, t) {
                1 === arguments.length &&
                  "object" === d.type(e) &&
                  ((t = e), (e = null)),
                  "string" === d.type(e) && X.options("screenName", e),
                  "object" === d.type(t) &&
                    (X.options("customData", t),
                    X.options("ruleData", t),
                    X.options("tokens", t));
              },
              render: function (e) {
                e &&
                  (!1 === e.showFeedbackByDefault &&
                    f.set("webengage.feedback.defaultRender", !1),
                  !1 === e.showSurveyByDefault &&
                    f.set("webengage.survey.defaultRender", !1),
                  !1 === e.showNotificationByDefault &&
                    f.set("webengage.notification.defaultRender", !1)),
                  _();
              },
              track: function (e, t) {
                var n,
                  i,
                  o = {};
                if (e && "string" === d.type(e))
                  if (t && "object" !== d.type(t))
                    v.error(
                      "webengage.track() second argument i.e. event attributes is not an object of key/value pairs"
                    );
                  else {
                    for (var a in (50 < e.length &&
                      (v.warn(
                        'webengage.track() event name "' +
                          e +
                          '" exceeds 50 character limit. Truncating to 50 character'
                      ),
                      (e = d.strunc(e, 50))),
                    t))
                      if (t.hasOwnProperty(a)) {
                        if ("" === d.trim(a)) {
                          v.warn(
                            "webengage.track() is passed an empty attribute name"
                          );
                          continue;
                        }
                        if (
                          ((n = t[a]),
                          "number" !== (i = d.type(n)) &&
                            "boolean" !== i &&
                            "string" !== i &&
                            "date" !== i &&
                            "object" !== i &&
                            "array" !== i)
                        ) {
                          v.warn(
                            'webengage.track() is passed value of unsupported type  "' +
                              i +
                              '" for attribute "' +
                              a +
                              '"',
                            { value: n }
                          );
                          continue;
                        }
                        if ("date" === i && isNaN(n)) {
                          v.warn(
                            'webengage.track() is passed an invalid date object "' +
                              i +
                              '" for attribute "' +
                              a +
                              '"',
                            { value: n }
                          );
                          continue;
                        }
                        50 < a.length &&
                          (v.warn(
                            'webengage.track() attribute name "' +
                              a +
                              '" exceeds 50 character limit. Truncating to 50 characters'
                          ),
                          (a = d.strunc(a, 50))),
                          "string" === i &&
                            1e3 < n.length &&
                            (v.warn(
                              'webengage.track() value of attribute "' +
                                a +
                                '" exceeds 1000 character limit. Truncating to 1000 characters'
                            ),
                            (n = d.strunc(n, 1e3))),
                          (o[a] = n);
                      }
                    r.publish("event.application", e, o);
                  }
                else
                  v.error(
                    "webengage.track() first argument i.e. event name is not a string"
                  );
              },
              reload: function () {
                if (r.happened("ready") || "reload.now" === X.__rs) {
                  v.debug({ msg: "WIDGET RELOAD" }),
                    X.feedback.clear(),
                    X.survey.clear(),
                    X.notification.clear(),
                    X.webPersonalization.clear(),
                    X.notificationInbox.clear();
                  var e = s.queryOne("webengagedata");
                  e && e.parentNode.removeChild(e),
                    "undefined" !== d.type(Z.webengage_fs_configurationMap) &&
                      (Z.webengage_fs_configurationMap = $),
                    r.reload(),
                    m.reload(),
                    u.reload(),
                    b.reload(),
                    s.iframe.reload(),
                    t("webengage/profile").reload(),
                    t("webengage/journey-cxr").stop(!0),
                    V();
                } else X.__rs = "reload.initiated";
              },
            };
            function _() {
              a.mapParallel(
                ["webPersonalization", "feedback", "survey", "notification"],
                function (e, t) {
                  !1 !==
                    (f.has("webengage." + e + ".defaultRender")
                      ? f.get("webengage." + e + ".defaultRender")
                      : f.get("webengage.defaultRender")) && X[e].render();
                }
              );
            }
            function S(e) {
              function t(e) {
                for (
                  var t = e.split("."), n = X, i = Z, o = 0;
                  o < t.length && void 0 !== n;
                  o++
                )
                  (n = (i = n)[t[o]]).parent = i;
                return n;
              }
              if (X.__queue && 0 < X.__queue.length) {
                for (var n = 0; n < X.__queue.length; n++) {
                  var i = X.__queue[n];
                  if (i && i[0]) {
                    var o = t(i[0]),
                      a = i[1];
                    o &&
                      "function" == typeof o &&
                      (e
                        ? o === e &&
                          ((X.__queue[n] = null), o.apply(o.parent, a))
                        : o.apply(o.parent, a));
                  }
                }
                e || (X.__queue = []);
              }
            }
            function C(e) {
              var t = K.createElement("webengagedata");
              K.body.insertBefore(t, null),
                s.css.createStyleNode(
                  "#webklipper-publisher-widget-container, #webklipper-publisher-widget-container * {overflow:visible; -webkit-box-sizing: content-box; -moz-box-sizing: content-box;  box-sizing: content-box; margin: 0; padding: 0; border: 0; font-size: 100%; font: inherit; vertical-align: baseline;}",
                  null,
                  t
                );
              var n = K.createElement("div");
              n.setAttribute("id", o.widgetContainerId),
                t.appendChild(n),
                (o.widgetContainer = n),
                v.debug({ msg: "WIDGET CONTAINER WEBENGAGEDATA" }),
                y.init(null, e);
            }
            function I(e) {
              l.init(e);
            }
            function T(e) {
              c.load(e);
            }
            function k(t) {
              if ("undefined" != typeof webengage_fs_configurationMap)
                return (
                  v.debug({
                    msg: "WIDGET CONFIG DATA FRAME",
                    ctx: { config: webengage_fs_configurationMap },
                  }),
                  t()
                );
              var e =
                  (c.getForever() && c.getForever().isGzip) ||
                  f.get("webengage.isGzip") ||
                  !1,
                n =
                  ("http:" == location.protocol ? "http:" : "https:") +
                  "//s3.amazonaws.com/" +
                  (e ? "webengage-zfiles" : "webengage-files") +
                  "/webengage/" +
                  f.get("webengage.licenseCode") +
                  "/v4.js?r=" +
                  Math.floor(new Date().getTime() / 6e4);
              p.script(n)(function (e) {
                "undefined" != typeof webengage_fs_configurationMap &&
                  v.debug({
                    msg: "WIDGET CONFIG DATA LOAD",
                    ctx: { config: webengage_fs_configurationMap },
                  }),
                  t(e);
              });
            }
            function A(t) {
              try {
                if (
                  "undefined" == typeof webengage_fs_configurationMap ||
                  !webengage_fs_configurationMap.config
                )
                  throw new Error(
                    'SDK config "webengage_fs_configurationMap" is undefined or improper'
                  );
                var e = webengage_fs_configurationMap,
                  n = !1;
                if (
                  ((e.sites !== $ && e.sites) ||
                    (e.domain !== $ && e.domain)) &&
                  !f.get("webengage.isDemoMode")
                ) {
                  var i = Z.location.host,
                    o = "",
                    a = [],
                    r = [];
                  for (var s in (i.match(/\:[\d]*$/) &&
                    ((o = i.substring(i.indexOf(":") + 1, i.length)),
                    (i = i.substring(0, i.indexOf(":")))),
                  e.sites || ((e.sites = {}), (e.sites[e.domain] = "DOMAIN")),
                  e.sites)) {
                    var c = s,
                      l = "";
                    if ("DOMAIN" === e.sites[s]) {
                      if (
                        (a.push(c),
                        c.match(/^www\./i) && (c = c.substring(4, c.length)),
                        c.match(/\:[\d]*$/) &&
                          ((l = c.substring(c.indexOf(":") + 1, c.length)),
                          (c = c.substring(0, c.indexOf(":")))),
                        i.match(new RegExp(d.escapeForRegExp(c) + "$", "gi")) &&
                          (!l || l === o))
                      ) {
                        n = !0;
                        break;
                      }
                    } else if (
                      "REGEXP" == e.sites[s] &&
                      (r.push(c), Z.location.href.match(c))
                    ) {
                      n = !0;
                      break;
                    }
                  }
                  if (!n) {
                    var g =
                      "WebEngage SDK is incorrectly configured. Provided license code is meant for use only on ";
                    throw (
                      (0 < a.length && (g += '"' + a.join('", "') + '"'),
                      0 < r.length &&
                        (0 < a.length && (g += " and "),
                        (g +=
                          'pages with URLs that matches following regular expression(s) "' +
                          r.join('", "') +
                          '"')),
                      g)
                    );
                  }
                }
              } catch (e) {
                return t(e);
              }
              t();
            }
            function O(e) {
              c.init(), e();
            }
            function N(e) {
              var t = parseInt(f.get("webengage.delay") || 0);
              t ? setTimeout(e, t) : e();
            }
            function P(n) {
              null == c.getForever().isGzip
                ? p.script("//z.webengage.co/gz.js")(function (e, t) {
                    e || c.setGZIPFlag(!0 === f.get("webengage.isGzip")),
                      v.debug({
                        msg: "WIDGET GZIP SUPPORT",
                        ctx: { isGzip: f.get("webengage.isGzip") },
                      }),
                      n(e, t);
                  })
                : n();
            }
            function D(e) {
              for (var t in webengage_fs_configurationMap.events)
                if (webengage_fs_configurationMap.events.hasOwnProperty(t)) {
                  var n = webengage_fs_configurationMap.events[t],
                    i = [t];
                  n && (n instanceof Array ? (i = i.concat(n)) : i.push(n)),
                    v.debug({
                      msg: "WIDGET TRIGGERS REGISTER",
                      ctx: { events: i },
                    }),
                    m.register.apply(null, i);
                }
              e();
            }
            function R(e) {
              t("webengage/profile").load(e);
            }
            function L(e) {
              d.copy(X, {
                notificationInbox: t("webengage/notification-inbox")(),
                webPersonalization: t("webengage/web-personalization")(),
                notification: t("webengage/notification")(),
                survey: t("webengage/survey")(),
                feedback: t("webengage/feedback")(),
              }),
                e();
            }
            function M(e) {
              var i =
                  f.get("webengage.customWidgetCode.ruleData") ||
                  f.get("webengage.ruleData") ||
                  {},
                o = f.get("webengage.licenseCode");
              a.mapParallel(
                webengage_fs_configurationMap.cwcRuleList || [],
                function (e, t) {
                  if (e.ruleCode && !b.execute(e.cwcEncId, e.ruleCode, i))
                    return t();
                  var n =
                    ("http:" == location.protocol ? "http:" : "https:") +
                    "//wsdk-files.webengage.com/webengage/" +
                    o +
                    "/" +
                    e.cwcEncId +
                    ".js?r=" +
                    e.lastModifiedTimestamp;
                  p.script(n)(function () {
                    v.debug({ msg: "WIDGET CWC", ctx: { id: e.cwcEncId } }),
                      t();
                  });
                },
                e
              );
            }
            function z(e) {
              var i = c.getForever().isGzip
                ? "webengage-zfiles"
                : "webengage-files";
              f.get("webengage.licenseCode");
              a.mapParallel(
                webengage_fs_configurationMap.apps || [],
                function (e, t) {
                  var n =
                    ("http:" == location.protocol ? "http:" : "https:") +
                    "//s3.amazonaws.com/" +
                    i +
                    "/appJS/" +
                    e.appEId +
                    ".js?r=";
                  p.script(n)(function () {
                    v.debug({ msg: "WIDGET APP", ctx: { id: e.appEId } }), t();
                  });
                },
                e
              );
            }
            function W(e) {
              function t(e) {
                try {
                  return sessionStorage.getItem(e);
                } catch (e) {
                  return null;
                }
              }
              function n(e, t) {
                try {
                  sessionStorage.setItem(e, t);
                } catch (e) {}
              }
              if (
                -1 < Z.location.search.indexOf("libraryScript=") ||
                "true" == t("webengage-library")
              ) {
                var i,
                  o = new RegExp("[\\?&]libraryScript=([^&#]*)").exec(
                    location.search
                  );
                null != o
                  ? n(
                      "webengage-library-script",
                      (i = decodeURIComponent(o[1]))
                    )
                  : t("webengage-library-script") &&
                    (i = t("webengage-library-script")),
                  n("webengage-library", "true"),
                  i &&
                    p.module(i)(function () {
                      v.debug({
                        msg: "WIDGET LIBRARY SCRITP",
                        ctx: { name: i },
                      }),
                        X.feedback.abort(),
                        X.survey.abort(),
                        X.notification.abort(),
                        n("webengage-library", "true"),
                        X.require("webengage/" + i);
                    });
              } else e();
            }
            function F(e) {
              return (
                v.debug({ msg: "WIDGET READY" }),
                X.webPersonalization.init(
                  f.get("webengage.licenseCode"),
                  webengage_fs_configurationMap
                ),
                X.notification.init(
                  f.get("webengage.licenseCode"),
                  webengage_fs_configurationMap
                ),
                X.survey.init(
                  f.get("webengage.licenseCode"),
                  webengage_fs_configurationMap
                ),
                X.feedback.init(
                  f.get("webengage.licenseCode"),
                  webengage_fs_configurationMap
                ),
                "function" === d.type(f.get("webengage.onReady")) &&
                  r.subscribe("ready", f.get("webengage.onReady")),
                u.ready(),
                (X.user = t("webengage/user")),
                S(),
                "reload.initiated" === X.__rs
                  ? ((X.__rs = "reload.now"), X.reload(), delete X.__rs)
                  : (r.publish("ready"),
                    r.desubscribe("ready"),
                    "3.0" !== f.get("webengage.widgetVersion") && _(),
                    h.init()),
                e()
              );
            }
            function U(n) {
              webengage_fs_configurationMap &&
              webengage_fs_configurationMap.GAEnabled
                ? (f.get("GA.universalAnalyticsFunction") &&
                    "function" ===
                      d.type(Z[f.get("GA.universalAnalyticsFunction")])) ||
                  "function" == typeof Z.ga ||
                  Z._gaq
                  ? p.script(
                      ("http:" == location.protocol ? "http:" : "https:") +
                        "//ssl.widgets.webengage.com/js/ga-integration.js?v=277"
                    )(function (e, t) {
                      v.debug({ msg: "WIDGET GA HELPER" }),
                        X.require("webengage/ga-integration").init(),
                        n();
                    })
                  : (v.error({
                      msg: "WIDGET GA ERROR | _gaq/ga undefined - not loading ga-callback-helper",
                    }),
                    n())
                : n();
            }
            function q(n) {
              webengage_fs_configurationMap &&
              "array" === d.type(webengage_fs_configurationMap.goals)
                ? p.module("conversion")(function (e, t) {
                    v.debug({ msg: "WIDGET CONVERSION HELPER" }),
                      (X.goals = X.require("webengage/conversion")),
                      X.goals.init(webengage_fs_configurationMap),
                      n();
                  })
                : n();
            }
            function j(e) {
              a.parallel([U, q], e);
            }
            function B(e) {
              a.mapSeries(
                e,
                function (e, t) {
                  try {
                    e(t);
                  } catch (e) {
                    t(e);
                  }
                },
                function (e) {
                  e &&
                    (v.error({ msg: e.message || e, ctx: { error: e } }),
                    r.publish("error", e));
                }
              );
            }
            function V() {
              f.get("webengage.licenseCode")
                ? B([C, I, T, k, A, O, N, P, D, R, L, M, z, W, j, F])
                : v.error({ msg: "WIDGET ERROR | no license code provided" });
            }
            (X.app = t("webengage/app-store")),
              "bot" === g.type ||
                (g.ie && g.version < 8) ||
                B([
                  function (e) {
                    s.onDocReady(function () {
                      v.debug({ msg: "WIDGET DOCUMENT READY" }), e();
                    });
                  },
                  function (e) {
                    !Array.prototype.indexOf ||
                    !Array.prototype.map ||
                    "undefined" == typeof JSON ||
                    !K.querySelectorAll ||
                    (g.ie && 8 === g.version)
                      ? p.script(
                          ("http:" == location.protocol ? "http:" : "https:") +
                            "//ssl.widgets.webengage.com/js/polyfill.js?v=277"
                        )(function () {
                          v.debug({ msg: "WIDGET POLYFILL" }),
                            X.require("webengage/polyfill"),
                            e();
                        })
                      : e();
                  },
                  function (e) {
                    var t = s.queryOne("webengage");
                    if (t && t.attributes) {
                      var n = t.attributes;
                      f.set("webengage.licenseCode", n.license.value),
                        f.set(
                          "webengage.language",
                          n.language ? n.language.value : ""
                        ),
                        f.set("webengage.widgetVersion", "2.0"),
                        n.feedbackButtonAlignment &&
                          f.set(
                            "webengage.feedback.alignment",
                            n.feedbackButtonAlignment.value
                          ),
                        n.feedbackExternalLinkId &&
                          f.set(
                            "webengage.feedback.externalLinkId",
                            n.feedbackExternalLinkId.value
                          );
                    }
                    e();
                  },
                  function () {
                    if (
                      (r.bind(Z, "beforeunload", function () {
                        X.windowUnloading = !0;
                      }),
                      w(),
                      d.copy(X, E),
                      "function" === d.type(Z.webengageWidgetInit) &&
                        Z.webengageWidgetInit(),
                      ("4.0" === f.get("webengage.widgetVersion") ||
                        "2.0" === f.get("webengage.widgetVersion")) &&
                        f.get("webengage.licenseCode"))
                    )
                      return V();
                    S(X.options), S(X.init);
                  },
                ]);
          },
          {},
        ],
        "webengage/weq": [
          function (e, t, n) {
            "use strict";
            var i = e("webengage/util"),
              o = Z._weq || {};
            function a(e, t, n) {
              e && (t = e + "." + t),
                ".customData" === t.substr(-11) ||
                ".ruleData" === t.substr(-9) ||
                ".tokens" === t.substr(-7)
                  ? (o[t] = i.copy(o[t] || {}, n))
                  : (o[t] = n);
            }
            var r = {
              has: function (e) {
                return o.hasOwnProperty(e);
              },
              get: function (e) {
                return o[e];
              },
              getSmart: function (e, t) {
                return o("webengage." + e + "." + t) || o("webengage." + t);
              },
              set: function (e, t, n) {
                "object" === i.type(e)
                  ? (function (e, t) {
                      for (var n in e)
                        e.hasOwnProperty(n) && null != e[n] && a(t, n, e[n]);
                    })(e, n)
                  : "string" == typeof e && a(n, e, t);
              },
              _weq: o,
            };
            t.exports = r;
          },
          {},
        ],
        "webengage/xpath": [
          function (e, t, n) {
            "use strict";
            var i = e("webengage/dom");
            var o = {
              getXPathElement: function (e) {
                var t = null;
                if (e && -1 < e.indexOf("|")) {
                  var n = e.split("|");
                  e = n[0] + "/@" + n[1];
                }
                e = e
                  .replace(/\[(\d+?)\]/g, ":nth-of-type($1)")
                  .replace(/\/{2}/g, "")
                  .replace(/\/+/g, " > ")
                  .replace(/^\s*> /, "")
                  .replace(/@/g, "")
                  .replace(/^\s+/, "");
                try {
                  t = i.queryOne(e);
                } catch (e) {}
                return t;
              },
              evaluateXPathQuery: function (e) {
                var t = o.getXPathElement(e);
                return t ? t.textContent : null;
              },
            };
            t.exports = o;
          },
          {},
        ],
        "makeup/make-up-widget/sass/web-push/web-push-prompt.scss": [
          function (e, t, n) {
            t.exports =
              ".button,.close,.wrapper{text-align:center}.button,.close:hover,.wrapper{text-decoration:none;cursor:pointer}.button,.close,.close:hover,.wrapper{cursor:pointer}a,abbr,acronym,address,applet,article,aside,audio,big,blockquote,body,canvas,caption,center,cite,code,dd,del,details,dfn,div,dl,dt,em,embed,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,input,ins,kbd,label,legend,li,mark,menu,nav,object,ol,output,p,pre,q,ruby,s,samp,section,small,span,strike,strong,sub,summary,sup,table,tbody,td,textarea,tfoot,th,thead,time,tr,tt,u,ul,var,video{margin:0;padding:0;border:0;font:inherit;vertical-align:baseline;font-family:'Open Sans',Arial,Helvetica,sans-serif}.button,.wrapper,body{font-weight:400}.container,.image-container,.main-img{vertical-align:middle}body{width:100%;height:100%;line-height:1.5;color:#1C2E3D;background-color:transparent;background-size:cover;margin:0;padding:0}*,:after,:before{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-font-smoothing:antialiased}:focus{outline-width:1px;outline-style:solid}::-webkit-scrollbar{display:none}body,head,html{font-size:13px}.button{color:#fff;background-color:#888;border-color:#888;padding:8px 14px;font-size:15px;border-radius:4px;border-style:solid;border-width:1px;min-width:90px;display:inline-block;white-space:nowrap}.button.focus,.button.hover,.button:focus,.button:hover{color:#fff;background-color:rgba(136,136,136,.9);border-color:rgba(136,136,136,.9);outline:0}.button.active,.button:active{-webkit-animation-name:hvr-push;animation-name:hvr-push;-webkit-animation-duration:.3s;animation-duration:.3s;-webkit-animation-timing-function:linear;animation-timing-function:linear;-webkit-animation-iteration-count:1;animation-iteration-count:1}.transparent{-ms-filter:'progid:DXImageTransform.Microsoft.Alpha(Opacity=0)';filter:alpha(opacity=0);-moz-opacity:0;-khtml-opacity:0;opacity:0}.image-container{height:100%;width:20%}.main-img{overflow:hidden}.main-img img{display:block;margin:0 auto;max-height:50px;max-width:50px}img{max-width:100%}.button-group-custom{width:100%;display:block}.button-group-custom .button{width:50%;border-radius:0}.button-group-custom .button:first-child,.button-group-custom .button:first-child+.button{border-radius:0}.table{display:table}.content-table{height:76px;width:100%;padding:10px;position:relative}.tablerow{display:table-row}.tablecell{display:table-cell}.wrapper{background:#add8e6;overflow:visible;width:100%;font-size:13px;margin:0;border-left-width:0;border-right-width:0;border-top-width:0;min-height:30px;outline:0}.close{margin:0 auto}.container{overflow:hidden;padding:0 10px}button{margin:0;padding:0;border:none;font:inherit;color:inherit;background:0 0;overflow:visible}button::-moz-focus-inner{padding:0;border:none}button:-moz-focusring{outline:dotted 1px}.description{padding:0;margin:0;text-align:left}.hide{display:none!important}.we-beak{position:absolute;width:0;height:0}";
          },
          {},
        ],
      },
      {},
      ["webengage/webengage"]
    );
})(window, document, webengage);
